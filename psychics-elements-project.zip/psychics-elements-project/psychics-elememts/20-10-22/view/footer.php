		
	</div><!-- Main Container end -->

	<!-- Make sure our library is available everywhere too -->
    <script>var base_url = "<?php echo URL::base(); ?>";</script>
    <script src="<?php echo URL::base(); ?>js/libs/jquery.js"></script>
    <script src="<?php echo URL::base(); ?>js/jqui/js/jquery-ui-1.10.4.custom.min.js"></script>
    <script src="<?php echo URL::base(); ?>js/libs/jquery.mask.min.js"></script>
    <script src="<?php echo URL::base(); ?>js/libs/auto_numeric.js"></script>
    <script src="<?php echo URL::base(); ?>bootstrap/js/bootstrap.min.js"></script>
    <script src="<?php echo URL::base(); ?>js/lib.js"></script>
    <script src="<?php echo URL::base(); ?>js/global.js"></script>
    <script src="<?php echo URL::base(); ?>js/psychics.js"></script>
    <script src="<?php echo URL::base(); ?>js/purchases.js"></script>
    <?php if(Request::initial()->controller() == 'Customers' OR (Request::initial()->controller() == 'Purchases' AND Request::initial()->action() == 'package')){ ?>
    	<script src="<?php echo URL::base(); ?>js/customers.js"></script>
    <?php } ?>
    <script src="<?php echo URL::base(); ?>js/testimonials.js"></script>
    <?php /*if(Request::initial()->controller() == 'Learn'){ ?>
    	<div class="hidden-xs">
    		<!-- This site is converting visitors into subscribers and customers with OptinMonster - http://optinmonster.com --><div id="om-k9oygaswo0ddnpte-holder"></div><script>var k9oygaswo0ddnpte,k9oygaswo0ddnpte_poll=function(){var r=0;return function(n,l){clearInterval(r),r=setInterval(n,l)}}();!function(e,t,n){if(e.getElementById(n)){k9oygaswo0ddnpte_poll(function(){if(window['om_loaded']){if(!k9oygaswo0ddnpte){k9oygaswo0ddnpte=new OptinMonsterApp();return k9oygaswo0ddnpte.init({u:"9403.188694",staging:0});}}},25);return;}var d=false,o=e.createElement(t);o.id=n,o.src="//a.optinmonster.com/app/js/api.min.js",o.onload=o.onreadystatechange=function(){if(!d){if(!this.readyState||this.readyState==="loaded"||this.readyState==="complete"){try{d=om_loaded=true;k9oygaswo0ddnpte=new OptinMonsterApp();k9oygaswo0ddnpte.init({u:"9403.188694",staging:0});o.onload=o.onreadystatechange=null;}catch(t){}}}};(document.getElementsByTagName("head")[0]||document.documentElement).appendChild(o)}(document,"script","omapi-script");</script><!-- / OptinMonster -->
    	</div>
    	<div class="visible-xs">
    		<!-- This site is converting visitors into subscribers and customers with OptinMonster - http://optinmonster.com --><div id="om-ba77cynn5vywf50k-holder"></div><script>var ba77cynn5vywf50k,ba77cynn5vywf50k_poll=function(){var r=0;return function(n,l){clearInterval(r),r=setInterval(n,l)}}();!function(e,t,n){if(e.getElementById(n)){ba77cynn5vywf50k_poll(function(){if(window['om_loaded']){if(!ba77cynn5vywf50k){ba77cynn5vywf50k=new OptinMonsterApp();return ba77cynn5vywf50k.init({u:"9403.189685",staging:0});}}},25);return;}var d=false,o=e.createElement(t);o.id=n,o.src="//a.optinmonster.com/app/js/api.min.js",o.onload=o.onreadystatechange=function(){if(!d){if(!this.readyState||this.readyState==="loaded"||this.readyState==="complete"){try{d=om_loaded=true;ba77cynn5vywf50k=new OptinMonsterApp();ba77cynn5vywf50k.init({u:"9403.189685",staging:0});o.onload=o.onreadystatechange=null;}catch(t){}}}};(document.getElementsByTagName("head")[0]||document.documentElement).appendChild(o)}(document,"script","omapi-script");</script><!-- / OptinMonster -->
    	</div>
    <?php }*/ ?>
    <!--
    <script src="<?php echo URL::base(); ?>js/libs/require.js"></script>
    <script src="<?php echo URL::base(); ?>js/main.js"></script>
	-->

	<div class="main_footer"><?php echo $footers; ?></div>

	<div class="clr"></div>

    <script type="text/javascript">
      (function() {
        var sa = document.createElement('script'); sa.type = 'text/javascript'; sa.async = true;
        sa.src = ('https:' == document.location.protocol ? 'https://cdn' : 'http://cdn') + '.ywxi.net/js/1.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(sa, s);
        })();
        var PDOPTS = PDOPTS || [];
        PDOPTS['disablefloat'] = 1;
        PDOPTS['disablefloathover'] = 1;
    </script>

    <?php if($enable_remarketing): ?>
		<div class="hidden-xs hidden-sm">
      <?php if(false): ?>
			<!-- begin olark code -->
			<script data-cfasync="false" type='text/javascript'>/*<![CDATA[*/window.olark||(function(c){var f=window,d=document,l=f.location.protocol=="https:"?"https:":"http:",z=c.name,r="load";var nt=function(){
			f[z]=function(){
			(a.s=a.s||[]).push(arguments)};var a=f[z]._={
			},q=c.methods.length;while(q--){(function(n){f[z][n]=function(){
			f[z]("call",n,arguments)}})(c.methods[q])}a.l=c.loader;a.i=nt;a.p={
			0:+new Date};a.P=function(u){
			a.p[u]=new Date-a.p[0]};function s(){
			a.P(r);f[z](r)}f.addEventListener?f.addEventListener(r,s,false):f.attachEvent("on"+r,s);var ld=function(){function p(hd){
			hd="head";return["<",hd,"></",hd,"><",i,' onl' + 'oad="var d=',g,";d.getElementsByTagName('head')[0].",j,"(d.",h,"('script')).",k,"='",l,"//",a.l,"'",'"',"></",i,">"].join("")}var i="body",m=d[i];if(!m){
			return setTimeout(ld,100)}a.P(1);var j="appendChild",h="createElement",k="src",n=d[h]("div"),v=n[j](d[h](z)),b=d[h]("iframe"),g="document",e="domain",o;n.style.display="none";m.insertBefore(n,m.firstChild).id=z;b.frameBorder="0";b.id=z+"-loader";if(/MSIE[ ]+6/.test(navigator.userAgent)){
			b.src="javascript:false"}b.allowTransparency="true";v[j](b);try{
			b.contentWindow[g].open()}catch(w){
			c[e]=d[e];o="javascript:var d="+g+".open();d.domain='"+d.domain+"';";b[k]=o+"void(0);"}try{
			var t=b.contentWindow[g];t.write(p());t.close()}catch(x){
			b[k]=o+'d.write("'+p().replace(/"/g,String.fromCharCode(92)+'"')+'");d.close();'}a.P(2)};ld()};nt()})({
			loader: "static.olark.com/jsclient/loader0.js",name:"olark",methods:["configure","extend","declare","identify"]});
			/* custom configuration goes here (www.olark.com/documentation) */
			olark.identify('8029-544-10-7350');/*]]>*/</script><noscript><a href="https://www.olark.com/site/8029-544-10-7350/contact" title="Contact us" target="_blank">Questions? Feedback?</a> powered by <a href="http://www.olark.com?welcome" title="Olark live chat software">Olark live chat software</a></noscript>
			<!-- end olark code -->
		<?php endif; ?>
    </div>
	<?php endif; ?>
</body>
</html>
