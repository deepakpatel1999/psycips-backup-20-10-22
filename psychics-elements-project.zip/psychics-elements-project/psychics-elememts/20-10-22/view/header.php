<!DOCTYPE html>
<html>
<head>
    <?php $session = Session::instance(); 

$main_URL = 'https://psychicelements.com/';
    ?>

    <title><?php echo $title; ?></title>
    <meta charset="utf-8" />
    <?php
    $acronym = 'staging';
    if ($acronym == 'staging')
        echo '<meta name=\'robots\' content=\'noindex,nofollow\' />';
    ?>
    <meta http-equiv="X-UA-Compatible" content="IE=100">
    <meta name="description" content="<?php echo $metaDescription; ?>">
    <meta name="viewport" content="width=device-width, user-scalable=yes">
    <?php if(Request::initial()->controller() == 'Learn' && Request::initial()->param('id') != ''): ?>
        <?php echo helper_functions::getLearnFaceBookImage(Request::initial()->param('id')); ?> 
    <?php endif; ?>

    <?php if(Request::initial()->controller() == 'Psychics' AND Request::initial()->action() == 'profile'){ ?>
        <meta property="og:image" content="<?php echo URL::base(); ?>uploaded/profilePictures/psychics/profilePic_<?php echo Request::initial()->param('id') ?>.jpg">
        <meta property="og:image:type" content="image/jpeg">
        <meta property="og:image:width" content="125">
        <meta property="og:image:height" content="114">
    <?php } ?>   

    <link rel="stylesheet" href="<?php echo URL::base(); ?>bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo URL::base(); ?>js/jqui/css/ui-lightness/jquery-ui-1.10.4.custom.min.css" />
    <link rel="stylesheet" href="<?php echo URL::base(); ?>css/newmain.css" />    
    <?php echo helper_functions::loadPageCss(); ?>
    <link rel="stylesheet" href="<?php echo URL::base(); ?>css/mobile_main.css" />
    <link rel="stylesheet" href="<?php echo URL::base(); ?>css/google-fonts.css" />
    <?php echo helper_functions::canonicalLink(); ?>

    <!--[if IE 8]>
    <link rel="stylesheet" href="<?php echo URL::base(); ?>css/ie8.css" />
    <![endif]-->
    <link rel="shortcut icon" type="image/png" href="<?php echo URL::base(); ?>img/favicon.ico" />

    <?php if($enable_remarketing){echo $mktHeadView;} ?>
</head>
<body>
    <?php if($enable_remarketing){echo $mktBodyView;} ?>

    <?php if(!in_array(Request::initial()->controller(), $noLinkControllers)){ ?>
        <div class="mobile_header visible-xs">
            <?php if($isLoggedIn){ ?>
                <div class="mobile_menu_toggler">
                    <a href="javascript:void(0);" class="toggle_mobile_menu"></a>
                    <a href="tel:<?php echo helper_functions::getPhoneNumber(); ?>" class="call">Call Now</a>
                    <div class="clearfix"></div>
                </div>
            <?php }else{ ?>
                <div class="mobile_menu_toggler atop">
                    <a href="javascript:void(0);" class="toggle_mobile_menu"></a>
                    <?php if(Request::initial()->action() != 'login'){ ?>
                        <!-- <a href="<?php echo URL::base(); ?>customers/login" class="log">Log In</a> -->
                    <?php } ?>
                    <a href="tel:<?php echo helper_functions::getPhoneNumber(); ?>" class="call">Call Now</a>
                    <div class="clearfix"></div>
                </div>
            <?php } ?>
        </div>

        <div class="mobile_menu visible-xs none">
            <div class="header">
                <div class="pull-left"><img src="<?php echo URL::base(); ?>img/white_logo.png" class="img-responsive" alt="Psychic Elements Logo" /></div>
                <a href="javascript:void(0);" class="untoggle_mobile_menu"><img src="<?php echo URL::base(); ?>img/icons/exit_mobile_menu.png" alt="Exit Mobile Menu" /></a>
                <div class="clearfix"></div>
            </div>
            <?php if($isLoggedIn){ ?>
                <div class="info">
                    <div class="name">Welcome <span><?php echo $firstName; ?></span></div>
                    <div class="meta bor">
                        <div class="global-balance-placeholder"></div>
                    </div>
                    <div class="meta">
                        <?php echo helper_functions::pst2timezone($localtime, $timezone, 'M d'); ?><br/>
                        <?php echo helper_functions::pst2timezone($localtime, $timezone, 'h:i a T'); ?>
                    </div>
                    <div class="clearfix"></div>
                </div>
            <?php } ?>
            <ul>
                <li><a href="<?php echo URL::base(); ?>">Home</a></li>
                <li><a href="https://psychicelements.com/psychic-listing/">All Psychics</a></li>
                <?php if(!$isLoggedIn){ ?>
                    <li><a href="https://offers.psychicelements.com/get-started-now?">Intro Offers</a></li>                
                <?php } ?>
                <li><a href="<?php echo URL::base(); ?>horoscope/<?php echo helper_functions::getHoroscope(); ?>">Horoscope</a></li>
                <li><a href="<?php echo URL::base(); ?>blog">Blog</a></li>
                <?php if($isLoggedIn){ ?>
                    <li><a href="<?php echo URL::base(); ?>customers" class="my_account">My Account</a></li>
                    <li><a href="<?php echo URL::base(); ?>customers/logout">Sign Out</a></li>
                <?php }else{ ?>
                    <li><a href="<?php echo URL::base(); ?>customers/login" class="my_account">Log In</a></li>
                <?php } ?>
            </ul>
        </div>
        
        <?php if(isset($one_time_pop_promo) AND $one_time_pop_promo){ // detection for the promo pop-up flow ?>
            <div id="has_promo_code" class="none"><?php echo $promo_code['code']; ?></div>
        <?php } ?>
    <?php } ?>

    <!-- Main Container of the site-->
    <div class="main_container<?php if($isLoggedIn AND !in_array(Request::initial()->controller(), $noLinkControllers)) echo ' atop'; ?>">
        <?php if(!is_null($session->get('customerId'))){ ?>
            <?php if(!in_array(Request::initial()->controller(), $noLinkControllers)){ ?>
                <div class="account_header hidden-xs">
                    <div class="pull-left name">Welcome Back <span><?php echo $firstName; ?></span></div>
                    <div class="pull-right opt">
                        <ul>
                            <li><span class="global-balance-placeholder"></span></li>
                            <li><span class="dot"></span></li>
                            <li><?php echo helper_functions::pst2timezone($localtime, $timezone, ' M d - g:ia T'); ?></li>
                            <li><span class="dot"></span></li>
                            <li><a href="<?php echo URL::base(); ?>customers/logout">Logout</a></li>
                        </ul>
                        <?php if(isset($promo_code)){ ?>
                            <div class="promo_note">Your promo code <?php echo $promo_code['code']; ?> is active.&nbsp;
                            <?php if(Request::initial()->action() != 'recharge'){ ?>
                                Go to <a href="<?php echo URL::base(); ?>customers/recharge">Recharge</a> to add <?php echo ($currentTier > 1) ? 'minutes' : 'dollars'; ?>.
                            <?php } ?>
                            </div>
                        <?php } ?>
                    </div>
                    <div class="clearfix"></div>
                </div>
            <?php } ?>
        <?php } ?>

        <?php if(Request::initial()->controller() == 'Landing14'){ ?>
            <div class="head14 hidden-xs">
                <a href="<?php echo URL::base(); ?>" class="logo"></a>
                <div class="pull-right">
                    <div class="csi">Best customer care 7 days a week</div>
                    <div class="call">Call us at <a href="tel:<?php echo helper_functions::getPhoneNumber(); ?>"><?php echo helper_functions::getPhoneNumber(true); ?></a></div>
                </div>
                <div class="clearfix"></div>
            </div>
        <?php } ?>
        
        <?php if(!in_array(Request::initial()->controller(), $noLinkControllers)){ ?>
            <div class="header hidden-xs">            
                <div class="pull-left">
                    <a href="<?php echo $main_URL; ?>" class="logo"></a>
                </div>
                <div class="pull-right links">
                    <div class="csi">Best customer care 7 days a week</div>
                    <div class="call_us">Call us at <a href="tel:<?php echo helper_functions::getPhoneNumber(); ?>" id="phone_number"><?php echo helper_functions::getPhoneNumber(true); ?></a></div>
                    <div class="clearfix"></div>
                    <a href="https://psychicelements.com/psychic-listing/">All Psychics</a>
                    <?php if(strpos(Request::initial()->controller(), 'Landing') === false){ ?>
                        <?php if(!$isLoggedIn){ ?>
                            <a href="https://offers.psychicelements.com/get-started-now?" class="middle">Intro Offer</a>
                        <?php } ?>
                    <?php } ?>
                    <?php if($isLoggedIn){ ?>
                        <a href="<?php echo URL::base(); ?>customers" class="my_account">My Account</a>
                    <?php }else{ ?>
                        <a href="<?php echo URL::base(); ?>customers/login" class="log_in">Log In</a>
                    <?php } ?>
                    <div class="clearfix"></div>
                    <ul class="top_links">
                        <li><a href="<?php echo URL::base(); ?>horoscope/<?php echo helper_functions::getHoroscope(); ?>">Horoscope</a></li>
                        <li><a href="javascript:void(0);" class="subscribe newsletter marg_none_impt">Newsletter Signup</a></li>
                        <li>
                            <a href="https://psychicelements.com/blog/" class="sub">Blog <span></span></a>
                            <!-- Blogs container -->
                            <div class="blog_menu<?php if(Request::initial()->controller() != 'Home') echo ' stif'; ?>">
                                <?php if(Request::initial()->controller() == 'Home'){ ?>
                                    <div class="description">
                                        <div class="title">Learn about<br/>Psychic Services</div>
                                        <div class="content">
                                            At Psychic Elements, we believe it’s important to be well informed so<br/>
                                            that you can confidently make decisions about your psychics and what<br/>
                                            kind of psychic reading is best for you. Within these pages you can learn<br/>
                                            the advantages of a phone psychic, what sort of psychic ability will help<br/>
                                            you the most, and the different psychic readings. This way, when you<br/>
                                            review our psychics you know how to choose the best psychic for your<br/>
                                            needs, and receive the best psychic reading you can.
                                        </div>
                                        <a href="<?php echo URL::base(); ?>blog" class="blog_link">Check out our Blog Section</a>
                                    </div>
                                <?php } ?>
                                <div class="blog_links">
                                    <div class="links_con marg_b">
                                        <div class="title">Subjects</div>
                                        <ul>
                                            <li><a href="<?php echo URL::base(); ?>love-psychics">Love Psychics</a></li>
                                            <li><a href="<?php echo URL::base(); ?>pet-psychics">Pet Psychics</a></li>
                                        </ul>
                                    </div>
                                    <div class="links_con marg_b">
                                        <div class="title">Tools</div>
                                        <ul>
                                            <li><a href="<?php echo URL::base(); ?>tarot-reading">Tarot Reading</a></li>
                                            <li><a href="<?php echo URL::base(); ?>angel-card-reading">Angel Card Reading</a></li>
                                            <li><a href="<?php echo URL::base(); ?>past-life-reading">Past Life Reading</a></li>
                                        </ul>
                                    </div>
                                    <div class="links_con marg_b">
                                        <div class="title">Abilities</div>
                                        <ul>
                                            <li><a href="<?php echo URL::base(); ?>clairvoyant">Clairvoyant Psychic</a></li>
                                            <li><a href="<?php echo URL::base(); ?>psychic-medium">Psychic Medium</a></li>
                                            <li><a href="<?php echo URL::base(); ?>psychic-empath">Psychic Empath</a></li>
                                        </ul>
                                    </div>
                                    <div class="links_con">
                                        <div class="title">Articles</div>
                                        <ul>
                                            <li><a href="<?php echo URL::base(); ?>california-psychic-reviews">Best Psychics in California</a></li>
                                            <li><a href="<?php echo URL::base(); ?>famous-psychics">Famous Psychics</a></li>
                                            <li><a href="<?php echo URL::base(); ?>free-psychic-readings">Free Psychic Readings</a></li>
                                            <li><a href="<?php echo URL::base(); ?>online-psychic-chat">Online Psychic Chat</a></li>
                                            <li><a href="<?php echo URL::base(); ?>online-psychic-test">Online Psychic Test</a></li>
                                            <li><a href="<?php echo URL::base(); ?>phone-psychic-readings">Phone Psychic Readings</a></li>
                                            <li><a href="<?php echo URL::base(); ?>psychic-line">Psychic Line</a></li>
                                            <li><a href="<?php echo URL::base(); ?>psychic-predictions">Psychic Predictions</a></li>
                                            <li><a href="<?php echo URL::base(); ?>spiritual-readings">Spiritual Readings</a></li>
                                        </ul>
                                    </div>
                                    <?php if(Request::initial()->controller() != 'Home'){ ?>
                                        <a href="<?php echo URL::base(); ?>blog" class="check_blog">Check out our Blog Section</a>
                                    <?php } ?>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="clearfix"></div>
            </div>
        <?php }else{ ?>

            <?php if(Request::initial()->controller() == 'Landingfreeapp' OR Request::initial()->controller() == 'Landingfree5tarot'){ ?>
                <div class="header hidden-xs">            
                    <div class="pull-left">
                        <div class="logo"></div>
                    </div>
                    <div class="pull-right links centered">
                        <?php if(strpos($_SERVER['REQUEST_URI'], 'landingfree5tarot') !== false){ ?>
                            <a href="tel:<?php echo helper_functions::getPhoneNumber(); ?>" class="simple"><?php echo helper_functions::getPhoneNumber(true); ?></a>
                        <?php } ?>
                        <div class="csi">Best customer care 7 days a week</div>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="header visible-xs">
                    <img src="<?php echo URL::base(); ?>img/header_logo.png" class="img-responsive">
                </div>
            <?php } ?>

        <?php } ?>
