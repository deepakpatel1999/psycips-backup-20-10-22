<?php defined('SYSPATH') or die('No direct access allowed.');

class Controller_Website extends Controller {
  var $session;
  var $showTemplate = true;
  var $config;
  var $isLoggedIn = false; 
  var $additionalJS = array();
  //var $title = 'Default Title Goes Here';

  public function before(/*$headerCode = '', $sidebar = true, $showTemplate = true*/) {
    // load config to use in all controllers
    $this->config = Kohana::$config->load('config');
    $firstName = "";
    // is secure https disabled?
    if (!isset($_SERVER['HTTPS']) AND $this->config['acronym'] == 'live') {
      // redirect to a secure connection
      HTTP::redirect(URL::base('https') . substr($_SERVER['REQUEST_URI'], 1));
    }

    // if maintenance mode
    if($this->config['maintenance_mode'] AND strpos($_SERVER['REQUEST_URI'], 'maintenance') === false AND empty($_POST['nimdaOrderKey'])){
        HTTP::redirect('maintenance');
    }


    // always start the session 
    $this->sess = Session::instance(); 

    // Initialize some models that we need 
    $this->model_psychics = new model_users_psychics();
    $this->model_customers = new model_users_customers();
    $this->model_channels = new model_channels();
    // promos 
    $this->model_promotionalcodes = new model_financials_promotionalCodes();

    // Check for ID 
    $authId = $this->sess->get('customerId');

    // We have to refresh this data on every single login :-(
    if(isset($authId) AND !is_null($authId) AND is_int($authId)){
      $cust = $this->model_customers->read($authId);
      // have they been deleted / signed out?
      if(is_null($cust) OR $cust['active'] == 0){
        $this->sess->delete('customerId');
        $this->sess->destroy();
        $this->sess = Session::instance();
      }
      // Load up their current tier 
      $this->sess->set('currentTier', $cust['tier']);

      // gets the firstname of the customer
      $firstName = $cust['firstName'];
    }

    // Recheck for authId in case customer has been forced out by nimdas
    $authId = $this->sess->get('customerId');
    $this->authId = $authId;

    // Determine if they are logged in or not?
    // If they are not logged in, redirect to login action
    if(!isset($authId) OR is_null($authId) OR !is_int($authId)){
      // They are not logged in, but they are guests. Proceed.
      $this->isLoggedIn = false;
      $this->currentTier = 1 ;
      $this->defaultMinutes = 20;
    } else {
      $this->isLoggedIn = true;
      $this->currentTier = $cust['tier'];
      // let's get default package accd. to tier
      switch($this->currentTier){
        case 1:
        case 9:
          $this->defaultMinutes = 20;
          break;
      }
    }

    // Savings for the DPM Packages
    $this->savings = array(165, 110, 55);

    // Let's see if session has any timezone information for us? 
    if(!is_null($this->sess->get('timezone'))){
      $this->timezone = $this->sess->get('timezone'); 
    } else {
      // let's use the default one 
      $this->timezone = 'America/Los_Angeles';
    }

    if((strtolower($this->request->controller())=='customers' OR strtolower($this->request->controller())=='purchases') AND strtolower($this->request->action())=='failure'){
      // Tracking
      $landing_url = $this->sess->get('landing_url'); // This can be null
      if(strpos($landing_url, 'landing10') !== false){
          $this->origin = 'landing10';      
      }elseif(strpos($landing_url, 'landing14') !== false){
          $this->origin = 'landing14';
      }elseif(strpos($landing_url, 'landing9') !== false){
          $this->origin = 'landing9';
      }else{
          $this->origin = 'default';
      }
    }    
    else{
      $this->origin = NULL;
    }

    //variables for marketing scripts
    $this->enableRemarketing = false;
    $this->mktHeadView = View::factory('marketing/head');
    $this->mktBodyView = View::factory('marketing/body');

    $this->mktHeadView = $this->mktHeadView->render();
    $this->mktBodyView = $this->mktBodyView->render();

    //variables for sticky banner
    $controller = $this->request->controller();
    
    // Get a Reading link
    $this->introductoryLink = '/introductory-offer/checkout';

    // are we sending the header?
    if (!$this->request->is_ajax()) {
      // let's process the cookie here...
      $this->processCookie();
    
      // on live enable it
      if($this->config['acronym'] == 'live'){
        $this->enableRemarketing=true;
      }
      
      if ($this->showTemplate) {
        // Here we should (possibly) check for session validity, log IP, check time zone, etc 
        // setup header view
        $view = View::factory('website/newHeader');
        //$view->set('headerCode', $headerCode);
        $view->set('controller', $this->request->controller());

        //$view->set('showTemplate', $this->showTemplate);
        $metaTags = helper_functions::metaTags();
        $current_url = '/'.str_replace(URL::base(), '', URL::site(Request::detect_uri()));
        
        // Check for the set title
        if(!isset($this->title)){
          $this->title = '';
          if(isset($metaTags[$current_url])) {
            if(!empty($metaTags[$current_url]['title'])) {
              $this->title = $metaTags[$current_url]['title'];
            }
          }
        }
        // Check for the set description
        if(!isset($this->metaDescription)){
          $this->metaDescription = '';
          if(isset($metaTags[$current_url])){
            if(!empty($metaTags[$current_url]['metaDescription'])) {
              $this->metaDescription = $metaTags[$current_url]['metaDescription'];
            }
          }
        }

        //show social follow flag
        $showSocialFollow = false;
        //list of controllers that social follow will show
        $actionsWithSocialFollow = array('home','learn','psychics','howitworks','horoscope');

        if(in_array(strtolower($controller), $actionsWithSocialFollow)){
          $showSocialFollow = true;
        }

        $view->set('title', $this->title); 
        $view->set('metaDescription', $this->metaDescription); 
        // log in control
        $view->set('isLoggedIn', $this->isLoggedIn);
        // time ?
        $view->set('localtime', date('h:i a', time()));
        // Expose the timezone nevertheless.
        $view->set('timezone', $this->timezone);
        // expose the config 
        $view->set('config', $this->config);
        
        $view->set('enable_remarketing',$this->enableRemarketing);
        $view->set('mktHeadView',$this->mktHeadView);
        $view->set('mktBodyView',$this->mktBodyView);
        $view->set('showSocialFollow',$showSocialFollow);
        $view->set('firstName',ucwords(strtolower($firstName)));
        $view->set('currentTier', $this->currentTier);
        $view->set('origin',$this->origin);
        
        // // promo link flow
        // if(!is_null($this->sess->get('one_time_pop_promo'))){
        //   if(!is_null($this->sess->get('promo_code'))){
        //     $promoCode = $this->model_promotionalcodes->getCodeByCode($this->sess->get('promo_code'));
        //     if(!is_null($promoCode)){
        //       // if no expiration and active?
        //       if(is_null($promoCode['expirationDate']) AND $promoCode['active'] == 1){
        //         // validate if the user haven't used up the code
        //         $appliedPromo = $this->model_promotionalcodes->checkAppliedCode($this->sess->get('customerId'), $promoCode['promotionalCodeId']);
        //         if(is_null($appliedPromo)){
        //           if($this->request->controller() != 'Psychics'){
        //             if($this->request->action() != 'recharge'){
        //               if(strpos(URL::site(Request::detect_uri()), 'purchases/package') === false){
        //                 // setup the session values
        //                 $view->set('promo_code', $promoCode);
        //               }
        //             }
        //           }
        //         }
        //       } else { 
        //         // is it active, cap hasn't been reached, and not yet expired?
        //         if($promoCode['active'] == 1 AND $promoCode['cap'] > $promoCode['count'] AND strtotime($promoCode['expirationDate']) > strtotime(date('Y-m-d'))){
        //           // validate if the user haven't used up the code
        //           $appliedPromo = $this->model_promotionalcodes->checkAppliedCode($this->sess->get('customerId'), $promoCode['promotionalCodeId']);
        //           if(is_null($appliedPromo)){
        //             // setup the session values
        //             $view->set('promo_code', $promoCode['code']);
        //           }
        //         }
        //       }
        //     }
        //   }
        // }
        // Set this to the view files if they exist. 
        if( !is_null($this->sess->get('one_time_pop_promo')) ){
          $view->set('one_time_pop_promo', $this->sess->get('one_time_pop_promo'));
        }
        if(!is_null($this->sess->get('promo_code'))){
          // load it up 
          $pr = $this->model_promotionalcodes->getCodeByCode($this->sess->get('promo_code'));
          $view->set('promo_code', $pr);
        }
        // remove LP9 data if customer roams around
        if(!in_array($this->request->controller(), array('Landing9','Purchases','Psychics','Customers')) AND !is_null($this->sess->get('landing_url'))){
          if(strpos($this->sess->get('landing_url'), 'landing9') !== false){
            $this->sess->set('landing_url', NULL);
          }
        }else{
          if(strpos($this->sess->get('landing_url'), 'landing9') !== false AND $this->request->controller() == 'Psychics' AND $this->request->action() != 'book'){
            $this->sess->set('landing_url', NULL);
          }
        }

        // if someone has came in from campaign but didn't push through
        $landingFreeControllers = array('Landingfreeapp', 'Landingfree5tarot');
        if(strpos($_SERVER['REQUEST_URI'], 'landingfreeapp') === false AND strpos($_SERVER['REQUEST_URI'], 'landingfree5tarot') === false ){
          if(!is_null($this->sess->get('campaign_info'))){
            $this->sess->delete('campaign_info');
          }
        }

        // controllers that don't have links
        $noLinkControllers = array('Promo', 'Landing14', 'Landingfreeapp', 'Landingfree5tarot');
        $view->set('noLinkControllers', $noLinkControllers);
        $view->set('acronym', $this->config['acronym']);
        
        // go
        echo $view->render();
      }
    }
  }

  public function after($footerJS = '') {
    // are we sending the footer?
    if (!$this->request->is_ajax()) {
      // save javascript to output in footer
      if ($footerJS) {
        //$footerJS = Helper_Function::jsPacker($footerJS);
      }

      if ($this->showTemplate) {
        // The Footer modular views
        $seals = View::factory('website/footers/seals')->render();
        $mainFooter = View::factory('website/footers/main')->render();
        // append now...
        $footers = '';
        // exclude seals footer on this Landing pages
        $exControllers = array('Home', 'Promo', 'Horoscope');
        if(!in_array($this->request->controller(), $exControllers)){
          $footers = $seals;
          if($this->request->controller() == 'Landing14' AND $this->request->action() == 'index'){
            $footers = '';
          }
          if($this->request->controller() == 'Landingfreeapp'){
            $footers = '';
          }
        }
        $footers .= $mainFooter;

        $view = View::factory('website/newFooter');
        // $view->set('footerJS', $footerJS);
        $view->set('showTemplate', $this->showTemplate);
        $view->set('name', 'Default Footer Name');
        // expose the config 
        $view->set('config', $this->config);
        $view->set('footers', $footers);
        $view->set('enable_remarketing', $this->enableRemarketing);

        echo $view->render();

      }
    }
  }

  /*
   * This saves the Cookie of a customer if the URL contains UTM
   */
  private function processCookie(){
    if(is_null($this->sess->get('customerId'))){
      // Return the UTM data according to request uri
      // $parsedUtmString = helper_functions::parseUtmString(URL::base().substr($_SERVER['REQUEST_URI'], 1, (strlen($_SERVER['REQUEST_URI'])-1)));
      $utm_data = helper_functions::parseUtmString($_SERVER['REQUEST_URI']);
      $http_referer = (isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : NULL);
      // Init session, already initiated 
      
      // Set Cookie expiration to a week
      Cookie::$expiration = Date::WEEK;

      // Put these value into the cookie, if not exists, starting with the cookie 
      if(is_null(Cookie::get('utm_url')) OR empty(Cookie::get('utm_url'))){
          // start by the raw data 
          Cookie::set('utm_url', $_SERVER['REQUEST_URI']);
          // at the end put the referer
          Cookie::set('utm_referer', $http_referer);
          // If we have a normal UTM value, put it in
          if (isset( $utm_data['utm_source']) AND !empty($utm_data['utm_source'])) {
              // the cookie is empty and we can put values into it 
              Cookie::set('utm_source', $utm_data['utm_source']);
              Cookie::set('utm_medium', $utm_data['utm_medium']);
              Cookie::set('utm_campaign', $utm_data['utm_campaign']);
          }
      } 

      // Now let's put these in for the session 
      if(is_null($this->sess->get('utm_url')) OR empty($this->sess->get('utm_url'))){
          // start by the raw data 
          $this->sess->set('utm_url', $_SERVER['REQUEST_URI']);
          // at the end put the referer
          $this->sess->set('utm_referer', $http_referer);
          // do we have normal utm values?
          if (isset( $utm_data['utm_source']) AND !empty($utm_data['utm_source'])) {
              // the Session is empty and we can put values into it 
              $this->sess->set('utm_source', $utm_data['utm_source']);
              $this->sess->set('utm_medium', $utm_data['utm_medium']);
              $this->sess->set('utm_campaign', $utm_data['utm_campaign']);
          }
      } 
      // at this point everything must be correctly set! 
      return false; 
    }
  }
}
