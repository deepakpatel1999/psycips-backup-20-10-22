<?php defined('SYSPATH') or die('No direct script access.');

class Controller_Customers extends Controller_Website {
    public function before() {
        $this->title = 'Default title goes here';
        switch ($this->request->action()){
            case 'index':
                $this->title = 'Customer - Account Overview';
                break;
            case 'forgotpassword':
                $this->title = 'Customer - Forgot Password';
                break;
            case 'resetpasswordsuccess':
                $this->title = 'Customer - Reset Password Verification';
                break;
            case 'resetpw':
                $this->title = 'Customer - Reset Password';
                break;
            case 'recharge':
                $this->title = 'Customer - Recharge Account';
                break;
            case 'promos':
                $this->title = 'Customer - Promos';
                break;
            case 'readings':
                $this->title = 'Customer - Readings';
                break;
            case 'payments':
                $this->title = 'Customer - Payments';
                break;
            case 'testimonials':
                $this->title = 'Customer - Testimonials';
                break;
            case 'info':
                $this->title = 'Customer - Personal Info';
                break;
            case 'cards':
                $this->title = 'Customer - Credit Cards';
                break;
            case 'signup':
                $this->title = 'Customer - Sign Up';
                break;
            case 'login':
                $this->title = 'Customer - Login';
                break;
            case 'signupfail':
                $this->title = 'Customer - Sign Up Fail';
                break;
            // arian's hook
            case 'exconfirmation':
            case '5confirmation':
            case 'confirmation':
                $session = Session::instance();
                $this->title = 'Customer - Confirmation';
                break;
            default:
                $this->title = 'Customers';
                break;
        }
        // initialize the model
        $this->model_customers = new model_users_customers();
        $this->model_callbacks = new model_calls_callbacks();
        $this->model_payments = new model_financials_payments();
        $this->model_nimdas = new model_users_nimdas();
        $this->model_paymentmethods = new model_financials_paymentmethods();
        $this->model_promotionalcodes = new model_financials_promotionalcodes();
        $this->model_loginattempts = new model_loginattempts();
        $this->model_newsletter = new model_apis_newsletter();
        
        // session is already started in parent controller, let's see if we are logged in already
        // this is important to handle AJAX functionality.
        parent::before();

        // Get the customer ID logged in
        $this->customerId = $this->sess->get('customerId');

        //actions that do require login
        $logInActions = array('index', 'refreshbalance', 'recharge', 'promos', 'ccrecharge', 'readings', 'cancelappointment', 'payments', 'testimonials', 'info', 'updateinfo', 'updatepassword', 'edit_card', 'add_card', 'cards', 'deleteCard', 'promo', 'selectPsychic', 'bookPsychic', 'bookConfirm', 'applyPromo', 'applyPromoToBalance');
        if(is_null($this->customerId) AND in_array($this->request->action(), $logInActions)){
            // Validate the intended page
            $mainCustomerPages = array('recharge', 'readings', 'payments', 'info', 'cards', 'promos');
            if(in_array($this->request->action(), $mainCustomerPages)){
                $this->sess->set('intendedDestination', $this->request->action());
            }
            // Redirect a not logged in customer to the log in page
            HTTP::redirect('/customers/login');
            return false;
        }

        //actions that dont require login
        $noLogInActions = array('log','login','signup','forgotpassword','resetpasswordsuccess','resetpw','signup','register','signupfail');
        if(!is_null($this->customerId) AND in_array($this->request->action(), $noLogInActions)){
            HTTP::redirect('/customers');
            return false;
        }

        // This is when accessing the customer failure page
        if(Request::initial()->action() == 'failure' AND is_null($this->sess->get('purchase_error_code'))){
            if($this->isLoggedIn){
                HTTP::redirect('/customers');
            }else{
                HTTP::redirect('');
            }
            return false;
        }

        // this is to destroy the timezone session changed detector
        if(!$this->request->is_ajax()){
            if(!is_null($this->sess->get('timezone_changed'))){
                $this->sess->delete('timezone_changed');
            }
            // if someone that is not logged in and checking the page out.
            if(!$this->isLoggedIn AND $this->request->action() == 'checktestimonials'){
                HTTP::redirect('');
                return false;
            }
        }

        // My Account links
        if($this->isLoggedIn AND !$this->request->is_ajax() AND strpos($this->request->action(), 'conf') === false AND strpos($this->request->action(), 'success') === false AND strpos($this->request->action(), 'testimonial') === false){
            echo View::factory('customers/account_links')->render();
        }
    }

    /**
     * Checks the user's session, if their are not logged in, redirect them to login page and stop execution.
     * @return [type] [description]
     */
    private function require_login(){
        // Check login status 
        if(is_null($this->customerId)){
            die('access denied, please login');
        }
        return false;
    }

    /**
     * Logs incoming customer data -- called on landing page 1 currently. Never breaks. 
     * @return [type] [description]
     */
    public function action_log(){
        // get it 
        $c_data = $this->request->post('c_data');
        // Let's see post
        $c_data_var = json_decode($c_data, true);
        if(count($c_data_var) > 0){
            // Let's clean it up...
            foreach($c_data_var as $cd_field => $cd_value ){
                $tmp = NULL; 
                if(is_array( $cd_value )){
                    $filter = array_filter($cd_value); // let's remove empty elements...
                    $tmp = implode('', $cd_value);
                } else {
                    $tmp = $cd_value;
                } 
                $c_data_arr[$cd_field] = $tmp; 
            }

            // who is sending this? 
            $c_data_arr['landingPage'] = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : null; 

            // set session the lp9 inputs
            if(strpos($c_data_arr['landingPage'], 'landing9') !== false){
                $landing9_inputs = array(
                    'firstName' => $c_data_arr['firstName'],
                    'bdayDate' => $c_data_arr['bday_date'],
                    'bdayMonth' => $c_data_arr['bday_month'],
                    'bdayYear' => $c_data_arr['bday_year'],
                    'email' => $c_data_arr['email']
                );
                $this->sess->set('landing9_inputs', $landing9_inputs);
            }

            // fix bday
            if(!array_key_exists('bday_year', $c_data_arr) OR !array_key_exists('bday_month', $c_data_arr) OR !array_key_exists('bday_date', $c_data_arr)){
                return false;
            }
            $c_data_arr['birthdate'] = $c_data_arr['bday_year'].'-'.$c_data_arr['bday_month'].'-'.$c_data_arr['bday_date'];
            // save it 
            @$this->model_customers->logPreCustomer($c_data_arr['firstName'], $c_data_arr['lastName'], $c_data_arr['cellphone'], $c_data_arr['birthdate'], $c_data_arr['email'], $c_data_arr['landingPage'], $c_data_arr['selected_package'], $c_data_arr['psychicId']);
            // save it to text too please !
            $c_data_arr['password'] = ''; 
            $c_data_arr['conf_password'] = ''; 
            $c_data_arr['createdAt'] = date('m/d/Y h:i:s a', time()); 
            $c_data = json_encode($c_data_arr);
            @file_put_contents(DOCROOT.'/uploaded/click_log.json', $c_data."\r\n", FILE_APPEND | LOCK_EX);
        }
        return false;
    }

    public function action_refreshbalance(){
        // authorized access only
        $this->require_login();

        // if there is a session variable, add that too
        if (session_status() !== PHP_SESSION_NONE AND isset($_SESSION['balance'])) {
            // read it 
            $c = $this->model_customers->read($this->sess->get('customerId'));
            // set session variables
            $this->sess->set('balance', $c['balance']);
            $this->sess->set('dpmsBalance', $c['dpmsBalance']);
            // prepare the response
            echo Helper_Functions::ajax_reply(true, json_encode(array('balance' => $c['balance'], 'dpmsBalance' => $c['dpmsBalance'])), 'Success');
            return true;
        }
        echo Helper_Functions::ajax_reply(false, '--');
        return false;
    }

    /**
     * Get the customerId from session and retrieve customer information based
     * on the said Id.
     */
    public function action_index() {
        // authorized access only
        $this->require_login();

        // View
        $view = View::factory('customers/index');

        // get customer data
        $customer = $this->model_customers->read($this->customerId);
        // let's validate if the session is still alive
        if(is_null($customer)){
            HTTP::redirect('');
        }

        // Last purchase record
        $lastPurchaseDate = 'No purchase yet.';
        if($customer['lastPurchaseDate'] !== false){
            $lastPurchaseDate = date('F d, Y', strtotime($customer['lastPurchaseDate']));
        }

        // featured psychics
        $featuredPsychics = $this->model_psychics->all(4, array('magic'));
        $featuredInfoboxes = array();
        // prepare the infoboxes
        if(count($featuredPsychics) > 0){
            foreach($featuredPsychics as $psychic){
                $infobox = View::factory('psychics/infoboxes/featured_small');
                $infobox->set('psychic', $psychic);
                // append
                $featuredInfoboxes[] = $infobox->render();
            }
        }

        // previously read with psychics that has no testimonial
        $previousCallbacks = $this->model_callbacks->allCallbacksWithNoTestimonials($this->customerId, 2);
        $previousInfoboxes = array();
        // prepare the infoboxes
        if(count($previousCallbacks) > 0){
            foreach($previousCallbacks as $callback){
                $infobox = View::factory('psychics/infoboxes/leave_feedback');
                $infobox->set('callback', $callback);
                // append
                $previousInfoboxes[] = $infobox->render();
            }
        }

        // Vars...
        $view->set('balance', $customer['balance'])
             ->set('dpmsBalance', intval($customer['dpmsBalance'] / 60))
             ->set('lastPurchase', $lastPurchaseDate)
             ->set('featuredInfoboxes', implode('', $featuredInfoboxes))
             ->set('previousInfoboxes', implode('', $previousInfoboxes));

        // go
        echo $view->render();
    }

    public function action_checkTestimonials() {

        $callbacks_with_no_testimonial = array();
        $callbacks = $this->model_callbacks->allCallbacksWithNoTestimonials($this->customerId, 10);
        foreach ($callbacks as $callback) {
            $callbacks_with_no_testimonial[] = array(
                'callbackId' => $callback['callbackId'],
                'psychicId'  => $callback['psychicId'],
                'readingDate' => $callback['scheduledTime']
            );
        }
        echo json_encode($callbacks_with_no_testimonial);
    }

    /**
     * Shows the recharge index page. That's it!
     * @return [type] [description]
     */
    public function action_recharge(){
        // authorized access only
        $this->require_login();

        // Load all the discounts + session
        $discounts = $this->model_promotionalcodes->allAutoRedeem(true);

        // we need customer details 
        $record = $this->model_customers->read($this->customerId);
        $savings = array();
        // If customer is tier 2
        switch($record['tier']){
            case 1:
                $tierTitle = 'Buy your minutes for up to <span class="off">85% off!</span>';
                $tierDesc = 'Just <span class="off">$1 per minute</span> for your first purchase up to 30 minutes! Stock up and save -- good for any psychic and they never expire!';
                $dollar_packages = $this->config['dpm_packages'];
                rsort($dollar_packages);
                $savings = $this->config['dpm_savings'];
                rsort($savings);               

                // check if the customer already claimed a 5 free promo
                $plus5Free = $this->model_promotionalcodes->freeMinuteClaim($this->customerId);

                $packages = View::factory('customers/recharge/tier1_index');
                $packages->set('plus5Free', $plus5Free);
                break;
            case 2:
                $tierTitle = 'Try Psychic Elements Again For Up To <span class="off">75% off!</span>';
                $tierDesc = 'Just $1.50 per minute for your second purchase up to 30 minutes! Stock up and save - good for any psychic and never expire!';
                $dollar_packages = $this->config['ss_packages'];
                $savings = $this->config['ss_savings'];
                rsort($savings);
                $packages = View::factory('customers/recharge/tier2_index');
                break;
            case 9:
                $tierTitle = 'PREPARE FOR A GREAT READING!';
                $tierDesc = 'Add money to your account so you can read with your psychics!';
                $dollar_packages=$this->config['normal_packages'];
                rsort($dollar_packages);
                $packages = View::factory('customers/recharge/tier9_index');
                break;
        }

        // Set the packages and savings
        $packages->set('packages', $dollar_packages)
                 ->set('savings', $savings)
                 ->set('discounts', $discounts);

        // load up the view 
        $view = View::factory('customers/recharge/index');
        //This is requested only once
        $view->set('tierTitle', $tierTitle)
             ->set('tierDesc', $tierDesc)
             ->set('packagesView', $packages->render());
        // fire
        echo $view->render();
    }

    public function action_promos(){
        $this->require_login();

        // the view
        $view = View::factory('customers/promos');

        // instantiation for the promos
        $promos = array();

        // customer data
        $customer = $this->model_customers->read($this->customerId);

        // promo packages
        $promoPackages = $this->config['promo_packages'];

        // if customer is tier 1, let's not allow them to purchase dollar packages
      //deepak 19/10/22//
        
        if($customer['tier'] > 1){
            if(count($promoPackages)){
                foreach($promoPackages as $pp){
                    // promo packages, dollars
                    $dollarPromo = $this->model_promotionalcodes->promoPackages('dollar-promo-'.$pp);
                    if($dollarPromo){
                        $dollarPromo['package'] = $pp;
                        $promos[] = $dollarPromo;
                    }

                    // promo packages, minutes
                    $minutePromo = $this->model_promotionalcodes->promoPackages('minute-promo-'.$pp);
                    if($minutePromo){
                        $minutePromo['package'] = $pp;
                        $promos[] = $minutePromo;
                    }
                }
            }
        }

        //end deepak 19/10/22//
        // dpm packages
        /*
        $dpmPromos = $this->config['dpm_promo_packages'];
        if(count($dpmPromos) > 0){
            // append "minute-" to every minute promo package
            $dpm_packages = array_map(function($val){ return 'minute-'.$val; }, $dpmPromos);
            $code_entry_minute_promos = $this->model_promotionalcodes->allCodeEntry($this->customerId, $dpm_packages);
            if(count($code_entry_minute_promos) > 0){
                // merge
                foreach($code_entry_minute_promos as $cemp){
                    if($this->model_promotionalcodes->checkValid($cemp)){
                        $cemp['package'] = explode('-', $cemp['requiredPackage'])[1];
                        $promos[] = $cemp;
                    }
                }
            }
        }
        */
        
        // vars
        $view->set('promos', $promos)
             ->set('promo_packages_excempt', $this->config['promo_packages_excempt']);

        echo $view->render();
    }

    /**
     * Provides the popup interface to use CC to recharge account
     * @return [type] [description]
     */
    public function action_ccrecharge() {
        // authorized access only
        $this->require_login();

        $amount = $this->request->post('amount');
        $action = $this->request->post('action');
        $viewport = $this->request->post('viewport');
        $origin = $this->request->post('origin');

        if(is_null($amount)){
            Helper_Functions::abort('No recharge amount selected');
        // give them the index if that's cool
        } else {
            // Grab the credit card details
            $cards = $this->model_paymentmethods->allByCustomer($this->customerId, 1);
            $record = $this->model_customers->read($this->customerId);
            $content = View::factory('paymentmethods/choose_method')
                    ->set('country', $record['country'])
                    ->set('amount', $amount)
                    ->set('action', (int)$action)
                    ->set('cards', $cards);

            // get customer tier
            $customerTier = $this->model_customers->getCurrentTier($this->customerId);
            // attach the promo code if any, look over autoRedeem + session 
            $discounts = $this->model_promotionalcodes->allAutoRedeem(true);
            // do we have this package?
            $promo_code = NULL; 
            // loop over discounts 
            foreach ($discounts as $disc) {
                // tier 9
                if($customerTier > 2){
                    // dollar promo discounts, identify the origin as well
                    if($origin == 'promos'){
                        if( $disc['requiredPackage'] == 'dollar-promo-'.$amount ){
                            $promo_code = $disc;
                            break;
                        }
                    }else{
                        if( $disc['requiredPackage'] == 'dollar-'.$amount ){
                            $promo_code = $disc;
                            break;
                        }
                    }
                    // minute promo discounts
                    if( $disc['requiredPackage'] == 'minute-promo-'.$amount ){
                        $promo_code = $disc;
                        break;
                    }
                }
                // tier 1 or lower
                if($customerTier < 2){
                    if( $disc['requiredPackage'] == 'minute-'.$amount ){
                        $promo_code = $disc;
                        break;
                    }
                }
            }
            $promo_package = false;
            // attach the promo code for all, we will assume that all promo falls for a dollar for a free minute
            if(!is_null($promo_code)){
                // tier 9
                $promo_package = $this->model_promotionalcodes->promoCodeRequiredPackage($this->customerId, 'dollar-'.$amount);
                if(strpos($promo_code['requiredPackage'], 'dollar-promo-') !== false){
                    $promo_package = $this->model_promotionalcodes->promoCodeRequiredPackage($this->customerId, 'dollar-promo-'.$amount);
                }
            }
            
            // attach it to the view never the less 
            $content->set('promoCode', $promo_code);
            $content->set('promoPackage', $promo_package);
            // other stuff
            if(!is_null($viewport) AND $viewport > 768){
                $pop = View::factory('website/popup');
                $pop->set('noLogo', true);
            }else{
                $pop = View::factory('website/mobile_popup');
            }

            $pop->set('title', 'Processing Payment')
                ->set('content', $content->render());

            echo $pop->render();
        }
    }

    /**
     * Loads the readings view for the time being , nothing more
     * @return [type] [description]
     */
    public function action_readings(){
        // authorized access only
        $this->require_login();

        // filters
        $offset = is_null($this->request->query('offset')) ? 0 : $this->request->query('offset');
        $reading_type = is_null($this->request->query('reading_type')) ? 'all' : $this->request->query('reading_type');;
        $period = is_null($this->request->query('period')) ? date('Y-m-d') : ( $this->request->query('period') == 'all' ? NULL : date('Y-m-d') );
        $human_period = is_null($this->request->query('period')) ? date('Y-m-d') : $this->request->query('period');

        // Load customer
        $record = $this->model_customers->read($this->customerId);
        // Load call and session data. This function fetched everything we need.
        $customer_calls = $this->model_callbacks->allBy($this->customerId, NULL, NULL, $period, NULL, NULL);
        // Initialize variables
        $calls_count = 0;
        $record_limit = 25;
        $_calls = array();
        // Let's fill them with data
        foreach ($customer_calls as $call) {
            // Upcoming readings are those who are 1. not attempted, 2. do not have session data, 3. have scheduledTime in future 4. not canceled
            if(in_array($reading_type, array('all', 'upcoming'))){
                if((int)$call['attempted'] == 0 AND (strtotime($call['scheduledTime']) > time()) AND $call['canceled'] == 0){
                    $call['reading_type'] = 'upcoming';
                    $_calls[] = $call;
                    $calls_count++;
                    continue;
                }
            }
            // previous readings are those who are 1. attempted, 2. have session data 3. have scheduledTime AND have a reason like call_ended in past or now
            if(in_array($reading_type, array('all', 'past'))){
                if((int)$call['attempted'] == 1 AND (strtotime($call['scheduledTime']) <= time()) AND $call['lastStatus'] == 'session_ended' ){
                    // here we should modify the call's financial data on an ad hoc basis. 
                    if($call['dpmsDebited'] > 0){
                        // add this to the call's expense
                        $call['amountDebited'] =+ round($call['dpmsDebited'] / 60.0, 2); 
                    }
                    $call['reading_type'] = 'past';
                    $_calls[] = $call;
                    $calls_count++;
                    continue;
                }else{
                    $call['reading_type'] = 'past';
                    $call['missed'] = TRUE;
                    $_calls[] = $call;
                    $calls_count++;
                }
            }
        }

        # slice the array according to pagination
        $calls = array_slice($_calls, $offset, $record_limit);

        # pagination
        $page_number = abs(count($_calls) / $record_limit);
        $pagination = '';
        if(count($_calls) > $record_limit){
            $pagination .= '<div class="pagination">';
            # record counter
            $start_offset = ($offset == 0) ? 1 : ($offset+1);
            $last_offset = ($offset + $record_limit) <= $calls_count ? ($offset + $record_limit) : $calls_count;
            $pagination .= '<div class="page_counter">Record/s <b>'.$start_offset.'</b> to <b>'.$last_offset.'</b> of <b>'.$calls_count.'</b> reading/s</div>';
            # previous
            if($offset != 0){
                $pagination .= '<a href="'.URL::base().'customers/readings?offset='.($offset-$record_limit).'&reading_type='.$reading_type.'&period='.$human_period.'"><<</a>';
            }
            for($p = 0; $p < $page_number; $p++){
                $page_offset = $p * $record_limit;
                $active_page = $offset == $page_offset ? TRUE : FALSE;
                if($active_page){
                    $pagination .= '<span>'.($p+1).'</span>';
                }else{
                    $pagination .= '<a href="'.URL::base().'customers/readings?offset='.$page_offset.'&reading_type='.$reading_type.'&period='.$human_period.'">'.($p+1).'</a>';
                }
            }
            # next
            if($offset < (($page_number-1) * $record_limit)){
                $pagination .= '<a href="'.URL::base().'customers/readings?offset='.($offset+$record_limit).'&reading_type='.$reading_type.'&period='.$human_period.'">>></a>';
            }
            $pagination .= '</div><div class="clearfix"></div>'; 
        }

        // Now we can safely go forward with this
        $view = View::factory('customers/readings');
        $view->set('customerId', $this->customerId)
             ->set('offset', $offset)
             ->set('reading_type', $reading_type)
             ->set('period', $human_period)
             ->set('calls_count', $calls_count)
             ->set('readings', $calls)
             ->set('mobile_readings', $_calls)
             ->set('pagination', $pagination)
             ->set('timezone', $this->sess->get('timezone'));

        // go
        echo $view->render();
    }

    /**
     * Loads the payments view, now loads the purchase history too ! YAY!
     * @return [type] [description]
     */
    public function action_payments() {
        // authorized access only
        $this->require_login();
        // Here we can get them all at once        
        $all_financial_data = $this->model_customers->allFinancialData($this->customerId);
        $timezone = $this->sess->get('timezone');
        $data = array();

        // it's already sorted, just needs pruning and conversion to customer's timezone
        foreach ($all_financial_data as &$fin_data) {
            $fin_data['createdAt'] = Helper_Functions::pst2timezone($fin_data['createdAt'], $timezone, 'M d, g:ia T'); 
        }

        // fire it up
        $view = View::factory('customers/payments')
            ->set('sorted_data', $all_financial_data)
            ->set('timezone', $this->sess->get('timezone'));
            
        // fire
        echo $view->render();
    }

    /**
     * Loads up the testimonials. Disabled for now
     * @return [type] [description]
     */
    public function action_testimonials() {
        // authorized access only
        $this->require_login();

        Helper_Functions::abort('unautorized access to testimonials.');
        //Not implemented yet
        return false;
        $record = $this->model_customers->read($this->customerId);
        $view = View::factory('customers/testimonials');

        echo $view->render();
    }

    /**
     * Loads the credit card information
     * @return [type] [description]
     */
    public function action_cards(){
        // authorized access only
        $this->require_login();

        // get the info
        $record = $this->model_customers->read($this->customerId);
        $cards = $this->model_paymentmethods->allByCustomer($this->customerId, 1);
        // prepare the view
        $countries = $this->config['countries'];
        $states = $this->config['states'];
        $customerStates = $this->config['states'];
        $customerTimezone = 'LIMITED_US';        
        if($record['country']==2){
            $customerStates=$this->config['provinces'];
            $customerTimezone = 'LIMITED_Canada';
        }        
        $view = View::factory('customers/creditcards')
            ->set('timezones', helper_functions::timezones($customerTimezone))
            ->set('customer', $record)
            ->set('customerstates', $customerStates)
            ->set('states', $states)
            ->set('countries', $countries)
            ->set('cards', $cards)
            ->set('paymentMethods', $this->model_paymentmethods->allByCustomer($this->customerId));

        echo $view->render();
    }

    /*
     * Deactivate a customer's CC
     */
    public function action_deleteCard(){
        $paymentMethodId = $this->request->post('paymentMethodId');
        $this->model_paymentmethods->delete($paymentMethodId);
    }

    /**
     * Loads the discount / promo module
     * @return [type] [description]
     */
    public function action_promo(){
        $promoCode = $this->request->post('promo_code');
        $viewport = $this->request->post('viewport');

        // view
        $view = View::factory('customers/promo_usage/select_action');

        // view port popup selection
        $pop = View::factory('website/mobile_popup');
        if($viewport > 768){
            $pop = View::factory('website/trans_popup');
        }

        // load the promo 
        $promo = $this->model_promotionalcodes->getCodeByCode($this->sess->get('promo_code'));

        // check the type 
        if(is_null($promo['requiredPackage'])){
            $promo_type = 1;
        } else {
            $promo_type = 2; // purchase required 
            // dig deeper 
            if(strpos($promo['requiredPackage'], 'dollar') !== false){
                $promo_type = 3; 
            }
            if(strpos($promo['requiredPackage'], 'minute') !== false){
                $promo_type = 4; 
            }
        }

        // give the promo type
        $view->set('promo_type', $promo_type)
             ->set('current_tier', $this->currentTier);        

        $pop->set('title', 'Coupon Activated')
            ->set('content', $view->render());

        // remove the pop-up so it won't show it anymore
        $this->sess->delete('one_time_pop_promo');

        echo $pop->render();
    }

    /**
     * Loads the Select Psychic for promo usage
     * @return [type] [description]
     */
    public function action_selectPsychic(){
        $viewport = $this->request->post('viewport');

        // view
        $view = View::factory('customers/promo_usage/select_psychic');

        // psychics
        $psychics = $this->model_psychics->all(3, array('magic'));
        $infoboxes = array();

        foreach($psychics as $psychic){
            $box = View::factory('psychics/infoboxes/promo');
            $box->set('psychic', $psychic)
                ->set('enums', helper_functions::mergedEnums($psychic));
            // append
            $infoboxes[] = $box->render();
        }

        $view->set('infoboxes', implode('', $infoboxes));

        // view port popup selection
        $pop = View::factory('website/mobile_popup');
        if($viewport > 768){
            $pop = View::factory('website/trans_popup');
        }

        $pop->set('title', 'Psychic Selection')
            ->set('content', $view->render());

        echo $pop->render();
    }
    /**
     * Loads the Book Psychic for promo usage
     * @return [type] [description]
     */
    public function action_bookPsychic(){
        $psychicId = $this->request->post('psychicId');
        $viewport = $this->request->post('viewport');

        // view
        $view = View::factory('customers/promo_usage/book_psychic');
        // psychic selected
        $psychic = $this->model_psychics->read($psychicId);
        $infobox = View::factory('psychics/infoboxes/promo_book');
        $infobox->set('psychic', $psychic)
                ->set('subjects', helper_functions::convertEnum($psychic['subjects'], 'subjects', true))
                ->set('tools', helper_functions::convertEnum($psychic['tools'], 'tools', true))
                ->set('abilities', helper_functions::convertEnum($psychic['abilities'], 'abilities', true));

        // customer
        $customer = $this->model_customers->read($this->customerId);

        // promo code
        $code = $this->sess->get('promo_code');
        $record = $this->model_promotionalcodes->getCodeByCode($code);
        // validate
        if(is_null($record)){
            echo helper_functions::ajax_reply(false, 'Promo Code is invalid!');
            return false;
        }
        
        // get the eligible rate for reading
        $max_duration_seconds = $this->model_callbacks->calc_max_duration($customer, $psychic);
        $max_duration_minutes = intval($max_duration_seconds / 60.0);

        // get the computation of additional minutes according to promo
        if($record['amount'] > 0.00){
            $psychic_rate = helper_functions::tier2rate($customer['tier'], $psychic['rate']);
            $max_duration_minutes += floor(($record['amount'] / $psychic_rate) * 60.0);            
        }else{
            $max_duration_minutes += $record['minutes'];
        }

        $view->set('cellphone', helper_functions::phoneNumberFormat($customer['cellphone'], 'n'))
             ->set('infobox', $infobox->render())
             ->set('max_duration_minutes', $max_duration_minutes)
             ->set('psychic', $psychic)
             ->set('customer', $customer)
             ->set('promoId', $record['promotionalCodeId']);

        // the pop-up view
        $pop = View::factory('website/mobile_popup');
        if($viewport > 768){
            $pop = View::factory('website/trans_popup');
        }

        $pop->set('title', 'Book a Call')
            ->set('content', $view->render());

        echo $pop->render();
    }

    /*
     * Apply the promo, this is when customer selects "Use Later" on the Promo redemption pop-up
     */
    public function action_applyPromo(){
        // request post
        $viewport = $this->request->post('viewport');
        // view
        $view = View::factory('customers/promo_usage/promo_applied');
        // customer data
        $customer = $this->model_customers->read($this->customerId);
        $balance = intval($customer['dpmsBalance'] / 60).' Promo Minutes + $'.$customer['balance'];
        // promo data
        $promo = $this->model_promotionalcodes->getCodeByCode($this->sess->get('promo_code'));
        // validate
        if(is_null($promo)){
            echo helper_functions::ajax_reply(false, 'Promo Code is invalid!');
            return false;
        }

        // Check to see if the promo is a purchase-bound promo 
        if(!is_null($promo['requiredPackage']) AND $promo['requiredPackage'] != 0){
            // just exit
            echo helper_functions::ajax_reply(false, 'This code requires a purchase.');
            return false;
        }

        // apply the promo
        $this->model_promotionalcodes->apply(0, $this->customerId, $promo['promotionalCodeId']);
        // apply which type rate should be applied
        $promoRate = ( $promo['amount'] > 0 ) ? '$'.$promo['amount'] : intval($promo['minutes']).' Free Minutes';

        // vars
        $view->set('balance', $balance)
             ->set('promoRate', $promoRate);

        // view port popup selection
        $pop = View::factory('website/mobile_popup');
        if($viewport > 768){
            $pop = View::factory('website/trans_popup');
        }

        $pop->set('title', 'Promo has been applied!')
            ->set('content', $view->render());

        // let's now delete the promo code session
        $this->sess->delete('promo_code');

        echo $pop->render();
    }

    /*
     * Action to when even with the promo code added the customer won't be book for a call due to insuficient minutes w/ a psychic
     */
    public function action_applyPromoToBalance(){
        $code = $this->model_promotionalcodes->getCodeByCode($this->sess->get('promo_code'));
        // validate the code
        if(is_null($code)){
            echo helper_functions::ajax_reply(false, 'Promo Code is invalid!', 'Promo Code is invalid!');
            return false;            
        }
        // Check to see if the promo is a purchase-bound promo 
        if(!is_null($code['requiredPackage']) AND $code['requiredPackage'] != 0){
            // just exit
            echo helper_functions::ajax_reply(false, 'This code requires a purchase.');
            return false;
        }
        // let's apply the promo to the balance
        $this->model_promotionalcodes->apply(0, $this->customerId, $code['promotionalCodeId']);

        echo helper_functions::ajax_reply(true, 'Promo Code applied');
        return true;
    }

    /*
     * Confirmed book with the Psychic
     */
    public function action_bookConfirm(){
        // request posts
        $psychicId = $this->request->post('psychicId');
        $viewport = $this->request->post('viewport');

        // customer data
        $customer = $this->model_customers->read($this->customerId);
        // psychic data
        $psychic = $this->model_psychics->read($psychicId);
        // promo data
        $promo = $this->model_promotionalcodes->getCodeByCode($this->sess->get('promo_code'));
        // validate
        if(is_null($promo)){
            echo helper_functions::ajax_reply(false, 'Promo Code is invalid!');
            return false;
        }

        // customer's new balance
        $newBalance = intval(($customer['dpmsBalance'] / 60)). ' Promo mins + $'.$customer['balance'];
        // customer's current balance
        if($promo['amount'] > 0){ // if its dollars
            $customer['balance'] = $current['balance'] - $promo['amount'];
        }else{ // if its minutes
            $customer['dpmsBalance'] = $customer['dpmsBalance'] - intval($promo['minutes'] * 60.0);
        }
        $currentBalance = intval($customer['dpmsBalance'] / 60.0). ' Promo mins + $'.$customer['balance'];

        // append some promo data
        $promo['rate'] = ( $promo['amount'] > 0 ) ? '$'.$promo['amount'] : intval($promo['minutes']).' Minutes';

        // the view
        $view = View::factory('customers/promo_usage/book_confirm');
        // vars
        $view->set('firstName', $customer['firstName'])
             ->set('redeemTime', date('g:i a T M. j, Y'))
             ->set('promo', $promo)
             ->set('currentBalance', $currentBalance)
             ->set('newBalance', $newBalance);

        // the pop-up view
        $pop = View::factory('website/mobile_popup');
        if($viewport > 768){
            $pop = View::factory('website/trans_popup');
        }

        $pop->set('title', 'Promo has been applied')
            ->set('content', $view->render());

        // let's now delete the promo code session
        $this->sess->delete('promo_code');

        echo $pop->render();
    }

    /**
     * Loads the info module, loads the credit card information too
     * @return [type] [description]
     */
    public function action_info(){
        // authorized access only
        $this->require_login();

        // get the info
        $record = $this->model_customers->read($this->customerId);
        
        // prepare variables
        $customerStates = $this->config['states'];
        $customerTimezone = 'LIMITED_US';        
        if($record['country'] == 2){
            $customerStates = $this->config['provinces'];
            $customerTimezone = 'LIMITED_Canada';
        }

        // prepare the view
        $view = View::factory('customers/info')
            ->set('timezones', helper_functions::timezones($customerTimezone))
            ->set('customer', $record)
            ->set('states', $customerStates)
            ->set('countries', $this->config['countries']);

        echo $view->render();
    }

    /**
     * Update account info, section 1 of customers/info
     * @return [type] [description]
     */
    public function action_updateInfo(){
        // authorized access only
        $this->require_login();
        // prepare $_POST vars
        $email = $this->request->post('email');
        $birthdate = $this->request->post('year').'-'.$this->request->post('month').'-'.$this->request->post('day');
        $address = $this->request->post('address');
        $city = $this->request->post('city');
        $country = $this->request->post('country');
        $state = $this->request->post('state');
        $zipcode = $this->request->post('zipcode');
        $timezone = $this->request->post('timezone');
        $receivePromotions = ( !is_null($this->request->post('subscribe')) ) ? 1 : 0;
        // prepare validation rules
        $validate = Validation::factory($this->request->post());
        $validate->rule('email', 'not_empty')
                 ->rule('email', 'email')
                 ->rule('month', 'not_empty')
                 ->rule('day', 'not_empty')
                 ->rule('year', 'not_empty')
                 ->rule('address', 'not_empty')
                 ->rule('city', 'not_empty')
                 ->rule('state', 'not_empty')
                 ->rule('zipcode', 'not_empty')
                 ->rule('timezone', 'not_empty');
        // validate the request
        if(!$validate->check()){
            $msg = $validate->errors('customers');
            echo Helper_Functions::ajax_reply(false, 'All fields are required', 'validation failed');
            return false;
        }

        // read in some values and ignore what's on the top
        $record = $this->model_customers->read($this->customerId);
        
        // so far alles gut!
        $update_user = $this->model_customers->update($this->customerId, $record['firstName'], $record['lastName'], $email, $record['cellphone'], $birthdate, $timezone, $address, $city, $state, $zipcode, $country, $record['active'], NULL, $receivePromotions);
        // send back a reply

        if($update_user) {
            // validate the EC if he/she still wants to be subscribe to the newsletter
            if($receivePromotions==1 && !$this->model_newsletter->existingNewsletterSubscription($email)){
                $this->model_newsletter->createNewsletterSubscription($email, $record['firstName'], $birthdate, $receivePromotions, date('Y-m-d H:i:s'), $this->customerId);
            }elseif($receivePromotions==0){
                $this->model_newsletter->deleteNewsletterSubscription($email);                
            }
            // change the session timezone NOW
            $this->sess->set('timezone', $timezone);
            echo Helper_Functions::ajax_reply(true, 'Successfully Updated');
        } else {
            echo Helper_Functions::ajax_reply(false, 'Email Already Exist!', 'Email Already Exist!');
        }

        return false;
    }

    /**
     * Update account password, section 2 of customers/info
     * @return [type] [description]
     */
    public function action_updatePassword(){
        // authorized access only
        $this->require_login();

        // get customer pass
        $customerPassword = $this->model_customers->getPassword($this->customerId);

        // password posts
        $current_password = $this->request->post('current_password');
        $new_password = $this->request->post('new_password');
        $confirm_password = $this->request->post('confirm_password');

        $validate = Validation::factory($this->request->post());
        $validate->rule('current_password', 'not_empty')
                 ->rule('new_password', 'not_empty')
                 ->rule('confirm_password', 'not_empty');

        // validate current password
        if(!is_null($customerPassword)){
            if($customerPassword['password'] != sha1($current_password)){
                echo helper_functions::ajax_reply(false, 'Current Password is wrong');
                return false;
            }
        }

        // check the new password inputs
        if($new_password != $confirm_password){
            echo helper_functions::ajax_reply(false, 'New and Confirm Password Not Same');
            return false;
        }else{
            // sanity check 
            if($validate->check()) {
                $update_pass = $this->model_customers->update_password($this->customerId, $current_password, $new_password);
                    $this->sess->set('toggleForm', '1');
                    $this->sess->set('customerErrors', $validate->errors('customers'));
                if($update_pass) {
                    echo Helper_Functions::ajax_reply(true, 'Password successfully updated.', 'success');
                } else {
                    echo Helper_Functions::ajax_reply(false, 'You have an entered an incorrect password');
                    return false;
                }
            }else{
                echo Helper_Functions::ajax_reply(false, 'All fields are required');
                return false;
            }
        }
    }

    public function action_edit_card() {
        // authorized access only
        $this->require_login();

        $view = View::factory('customers/templates/credit_card_input_details');
        $pop = View::factory('website/popup');
        $pop->set('content', $view->render());
        echo $pop->render();
    }

    public function action_add_card() {
        // authorized access only
        $this->require_login();

        $view = View::factory('customers/templates/credit_card_input_details');
        echo $view->render();
    }

    public function action_get_card() {

        $this->require_login();
        $data = array();

        if (!is_null($this->request->post('paymentMethodId'))) {
            $paymentMethodId = $this->request->post('paymentMethodId');
            $data = $this->model_paymentmethods->read($paymentMethodId);
        } 

        echo json_encode($data);
    }

    /**
     * Provides logout action
     */
    public function action_logout() {
        // remove the auth key
        $this->sess->delete('customerId');
        // remove the session completely
        $this->sess->destroy();
        // tell em
        HTTP::redirect(URL::base());
        // return false;
    }

    #####################################
    ###### NON LOGGED IN ACTIONS ########
    #####################################
    
    /**
     * Changes a user's timezone in the session. AJAX only.
     * @return [type] [description]
     */
    public function action_tzchange(){
        // get it
        $timezone = $this->request->post('timezone');
        // set it
        $this->sess->set('timezone', $timezone)
                   ->set('timezone_changed', true);
        echo Helper_Functions::ajax_reply(true, '', '');
        return true;
    }

    public function action_signup(){
    
        $view = View::factory('customers/sign_up');

        $view->set('countries', $this->config['countries'])
             ->set('states', $this->config['states'])
             ->set('defaultTimezone', $this->timezone)
             ->set('timezones', helper_functions::timezones('LIMITED_US'));

        echo $view->render();
    }

    /**
     * Displays the login modal / page, performs login, checks for already logged in.
     * @return [type] [description]
     */
    public function action_login() {
        $email = $this->request->post('email');
        $password = $this->request->post('password');
        $toPsychicsPage = ( !is_null($this->request->post('to_psychics_page')) ) ? true : false;
        $isPsychicsPage = ( trim($this->request->param('id')) == 'psychics' ) ? true : false; // checker if to redirect to psychics page or not
        // for the discount flow
        $promoCode = ( isset($_GET['promo']) ) ? $_GET['promo'] : NULL;
        $customerId = ( isset($_GET['cid']) ) ? $_GET['cid'] : NULL;
        // landing page promo
        $landing = ( isset($_GET['landing']) ) ? $_GET['landing'] : false;

        $showLoginText = false;

        // are we requesting the page?
        if(!is_null($email) AND !is_null($password)){
            // real login is happening. Let's do some sanitization first.
            // Load validation and prepare rules
            $validation = Validation::factory($this->request->post());
            $validation->rule('email', 'not_empty');
            $validation->rule('email', 'email');
            $validation->rule('password', 'not_empty');

            // prepare the response
            $resp = array('success' => NULL, 'message' => NULL, 'redirectURL' => NULL);

            // Validate fields
            if($validation->check()){
                // Query to fetch the email and password record match
                $customer = $this->model_customers->checkAuth($email, $password);

                // Check the response state
                if($customer == -1 OR is_null($customer)){
                    // redirect them back to login and say incorrect username password was provided
                    $resp['success'] = false;
                    $resp['message'] = 'Incorrect username / password';
                    $this->model_loginattempts->create($email, 'invalid_login');
                } else if($customer['active'] != 1){
                    // redirect them back to login and say incorrect username password was provided
                    $resp['success'] = false;
                    $resp['message'] = 'Account not active. Please contact Customer Care.';
                    $this->model_loginattempts->create($email, 'inactive_account_login');
                } else {
                    // Login found ! setup the session. INT id is another security check. Any manipulation on data should happen here.
                    $resp['success'] = true;
                    $resp['message'] = 'Logging you in...';
                    $resp['redirectURL'] = 'customers';
                    
                    // Update Last login
                    $this->model_loginattempts->create($email, 'successful_login');

                    // let's start the customer's session
                    $this->model_customers->doLogin($customer);

                    if($landing == false){
                        // let's check if the customer trying to use the promo is correct
                        if(!is_null($customerId) AND $customerId == $customer['customerId']){
                            // check the promo if already been used by the customer.
                            if(!is_null($this->request->post('promo'))){
                                // grab the promo details 
                                $promoCode = $this->model_promotionalcodes->getCodeByCode($this->request->post('promo'));
                                // if we have it 
                                if(!is_null($promoCode)){
                                    // Check promo validity here (exp date etc)
                                    if($this->model_promotionalcodes->checkValid($promoCode)){
                                        // validate if the user haven't used up the code
                                        $appliedPromo = $this->model_promotionalcodes->checkAppliedCode($customer['customerId'], $promoCode['promotionalCodeId']);
                                        if(is_null($appliedPromo)){
                                            // setup the session values
                                            $this->sess->set('promo_code', $promoCode['code']);
                                            $this->sess->set('one_time_pop_promo', true);
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Get the intended destination and redirect the user there
                    $intendedDestination = $this->sess->get('intendedDestination');
                    if (!is_null($intendedDestination)) {
                        // let's then delete the intended destination
                        $this->sess->delete('intendedDestination');
                        HTTP::redirect(URL::base().'customers/' . $intendedDestination);
                    } else {
                        // Let's check if where should else be redirected...
                        if($toPsychicsPage){
                            HTTP::redirect(URL::base().'psychics');
                        }else{
                            if($landing != false){
                                // let's apply the promo code
                                if(!is_null($this->request->post('promo'))){
                                    $promo = $this->model_promotionalcodes->getCodeByCode($this->request->post('promo'));
                                    // validate
                                    if(!is_null($promo['promotionalCodeId'])){
                                        // apply if okay
                                        if($this->model_promotionalcodes->apply(0, $customer['customerId'], $promo['promotionalCodeId'])){
                                            // redirect with the session, this will be used so we cannot let anyone go to this page
                                            $this->sess->set('landing_promo', true);
                                            HTTP::redirect(URL::base().$landing);
                                        }
                                    }
                                }
                            }
                            // let's say nothing's taken effect up until here
                            HTTP::redirect(URL::base().'customers');
                        }
                    }
                }
                // validation failed.
            } else {
                $resp['success'] = false;
                $resp['message'] = $validation->errors('customers');
            }
            // instantiate error message variables...
            $password = NULL;
            $error = NULL;

            $view = View::factory('customers/sign_in');
            if(!is_null($resp['success'])) {
                // validate response...
                if(is_array($resp['message'])) {
                    $email = (isset($resp['message']['email'])) ? $resp['message']['email'] : '';
                    $password = (isset($resp['message']['password'])) ? $resp['message']['password'] : '';
                }else {
                    $email = NULL;
                    $error = (isset($resp['message'])) ? $resp['message'] : '' ;
                }
            }
            $view->set('promoCode', $promoCode)
                 ->set('present', $showLoginText)
                 ->set('email', $email)
                 ->set('password', $password)
                 ->set('error', $error)
                 ->set('isPsychicsPage', $isPsychicsPage);
            echo $view->render();
        } else {            
            // instantiate error message variables...
            $email = NULL;
            $password = NULL;
            $error = NULL;

            $view = View::factory('customers/sign_in');
            $view->set('promoCode', $promoCode)
                 ->set('present', $showLoginText)
                 ->set('email', $email)
                 ->set('password', $password)
                 ->set('error', $error)
                 ->set('isPsychicsPage', $isPsychicsPage);
            echo $view->render();
        }
        // function ends, nothing happens here.
    }

    /*
     * Provides a page to a reset a customer's password
     */
    public function action_forgotpassword(){

        if($this->customerId) HTTP::redirect(URL::base().'customers');

        $view = View::factory('customers/forgot_password');

        if($this->request->post()){

            $validate = Validation::factory($this->request->post());
            $validate->rule('email', 'not_empty')
                ->rule('email', 'email');

            if(!$validate->check()){
                $view->set('errors', $validate->errors('customers'));
            }else{
                // Fetch Customer's ID by Email and read customer data
                $customer = $this->model_customers->getCustomerByEmail($this->request->post('email'));

                // Validate existence of the customer account
                if(!is_null($customer)){
                    // Validate Customer's active status
                    if($customer['active'] != 1){
                        $view->set('errors', 'Please contact Customer Care at ' . helper_functions::getPhoneNumber(true) . ' for assistance with your account.');
                    }else{
                        $about_model = new model_pages_about();

                        $this->model_loginattempts->create($this->request->post('email'), 'forgot_password');
                        // Prepare the email body
                        $link = URL::base().'customers/resetpw/'.strtotime(date('Y-m-d')).$customer['customerId'];

                        $body = View::factory('customers/email_reset_password');
                        $body->set('name', $customer['firstName'])
                             ->set('fromNimda', false)
                             ->set('link', $link);
                              
                        // Send email
                        helper_functions::sendEmail($customer['email'], 'Psychic Elements - Reset Password', $body->render());

                        // Save it on the communicationLog
                        $about_model->create($customer['customerId'], 'no-reply@psychicelements.com', $customer['email'], $customer['cellphone'], $customer['firstName'], $body->render());

                        $this->sess->set('password_reset', true);
                        HTTP::redirect(URL::base().'customers/resetpasswordsuccess');
                    }
                }else{
                    $view->set('errors', 'We were unable to find that email address in our system. Please double-check your email address or contact Customer Care at ' . helper_functions::getPhoneNumber(true) . ' and they\'ll be happy to help you sign into your account.');
                }
            }
        }

        echo $view->render();
    }

    /*
     * Provides a page when a customer has successfully reset his/her password
     */
    public function action_resetpasswordsuccess(){
        if(!$this->sess->get('password_reset')) HTTP::redirect(URL::base());

        $view = View::factory('customers/reset_password_success');
        $view->set('session', $this->sess);

        echo $view->render();
    }

    /*
     * Provides the reset password page
     */
    public function action_resetpw(){
        if($this->customerId) HTTP::redirect(URL::base().'customers');

        $expiration = $this->request->param('id');

        $date = substr($expiration, 0, (int)(strlen($expiration)-1));
        $customerId = substr($expiration, -5, 5);

        if($date < strtotime(date('Y-m-d'))){
            // Expired
            HTTP::redirect(URL::base());
        }else{
            $view = View::factory('customers/reset_password');

            $customer = $this->model_customers->read((int)$customerId);
            $view->set('customer', $customer);

            // If Confirm Password clicked
            if($this->request->post()){
                // Set up validations
                $validate = Validation::factory($this->request->post());
                $validate->rule('password', 'not_empty')
                         ->rule('conf_password', 'not_empty')
                         ->rule('conf_password', 'matches', array(':validation', 'conf_password', 'password'));

                // Validate the submission
                if(!$validate->check()){
                    $view->set('errors', $validate->errors('customers'));
                }else{
                    // Start the customer session
                    $this->model_customers->doLogin($customer);

                    // Password update
                    $this->model_customers->update_password($customer['customerId'], NULL, $this->request->post('conf_password'));

                    HTTP::redirect(URL::base().'customers');
                }
            }

            echo $view->render();
        }
    }

    public function action_checkemail(){
        $email = $this->request->post('email'); 
        if(is_null($email) OR empty($email)){
            echo helper_functions::ajax_reply(false, '', '');
            return false;
        }

        // Condition for Log in if to redirect to Our Psychics page
        $toPsychics = ($this->request->param('id') == 'psychics') ? ' psychics' : '';
        // if validated, check against the DB
        $customer = $this->model_customers->getCustomerByEmail($email);

        if(!is_null($customer)){
            echo helper_functions::ajax_reply(true, 'Email already exists in our system. <a href="'.URL::base().'customers/login/psychics">WHAT\'S THIS?</a>');
        } else {
            echo helper_functions::ajax_reply(false, '', '');
        }
    }

    public function action_checkcellphone(){
        $cellphone = $this->request->post('cellphone'); 
        $customerId = $this->request->post('customerId');
        if(is_null($cellphone) OR empty($cellphone)){
            echo helper_functions::ajax_reply(false, '', '');
            return false;
        }

        // Condition for Log in if to redirect to Our Psychics page
        $toPsychics = ($this->request->param('id') == 'psychics') ? ' psychics' : '';

        $cellphone = helper_functions::phoneCleanUp($this->request->post('cellphone'));
        // sane 
        $customer = $this->model_customers->getCustomerByCellphone($cellphone, $customerId);

        if(!is_null($customer)){
            echo helper_functions::ajax_reply(true, 'Phone number already exists in our system. <a href="'.URL::base().'customers/login/psychics">WHAT\'S THIS?</a>');
        } else {
            echo helper_functions::ajax_reply(false, '', '');
        }
    }

    public function action_checkaddress(){
        $address = $this->request->post('address');
        if(is_null($address) OR empty($address)){
            echo helper_functions::ajax_reply(false, '', '');
            return false;
        }

        // check on the customers table
        $customers = $this->model_customers->getByAddress($address);
        // check on payment methods
        $paymentMethods = $this->model_paymentmethods->getByAddress($address);
        // validate
        if($customers OR $paymentMethods){
            echo helper_functions::ajax_reply(true, 'Address already exists in our system. <a href="'.URL::base().'customers/login/psychics">WHAT\'S THIS?</a>');
            return true;
        }else{
            echo helper_functions::ajax_reply(false, '', '');
            return false;
        }
    }
    // this is a hook for Arian's marketing material to differentiate between new customers and existing customers purchase.
    public function action_exconfirmation(){
        $this->action_confirmation();
    }

    // This is for Arian's 5 minute free campaign confirmation
    public function action_5confirmation(){
        $this->action_confirmation();
    }

    // for when customer's sign up
    // Sign up processor
    public function action_register(){
        // variables for account Info
        $firstName = $this->request->post('firstName');
        $lastName = $this->request->post('lastName');
        $email = $this->request->post('email');
        $cellphone = helper_functions::phoneCleanUp($this->request->post('cellphone'));
        $bdayMonth = $this->request->post('bday_month');
        $bdayDate = $this->request->post('bday_date');
        $bdayYear = $this->request->post('bday_year');
        $birthdate = $bdayYear.'-'.$bdayMonth.'-'.$bdayDate;
        $subscribe = ( is_null($this->request->post('subscribe')) ) ? 0 : 1;
        $address = $this->request->post('address1');
        $city = $this->request->post('city');
        $country = $this->request->post('country');
        $state = $this->request->post('pp_state');
        $zipCode = $this->request->post('zipcode');
        $timezone = $this->request->post('timezone');
        // variables for account password
        $password = $this->request->post('password');
        $confPassword = $this->request->post('conf_password');
        // variables for credit card
        $ccMakePrimary = $this->request->post('cc_make_primary');
        $ccNumber = $this->request->post('ccnumber');
        $ccExpMonth = $this->request->post('date_expiration_month');
        $ccExpYear = $this->request->post('date_expiration_year');
        $cvv = $this->request->post('security_code');
        $ccGiftCard = $this->request->post('cc_giftcard');
        // variables for cc billing
        $sameCCAddress = $this->request->post('same_address');
        $ccAddress = $this->request->post('cc_address');
        $ccCity = $this->request->post('cc_city');
        $ccCountry = $this->request->post('cc_country');
        $ccState = $this->request->post('sel_states');
        $ccZip = $this->request->post('postal_code');
        // other values
        $landphone = NULL;
        $sendCall = 1;
        $signup_success = false;

        // SANITIZE
        // someone is trying to directly access it
        if(is_null($this->request->post())){
            HTTP::redirect('/');
        }

        // check for any customer session
        if($this->isLoggedIn){
            Helper_Functions::abort('You are not authorized to use this action. ERR_LOGGED_IN');
        }

        $me = 0; 
        // Is this a nimda?
        if(!is_null($this->sess->get('nimdaId'))){
            // deny access to them. only customers can register.
            helper_functions::abort('You are submitting an order in an incorrect way.');
        }

        // we will try to utilize try / catch statements to control errors
        try {
            /********************************************/
            /* Must Check Values */ 
            /********************************************/
            //check if name is valid
            if(helper_functions::nameValidator($firstName)==false OR helper_functions::nameValidator($lastName)==false){
                // if it's google just don't bother us 
                $r = @gethostbyaddr($_SERVER['REMOTE_ADDR']); 
                if(strpos($r, 'google.com')){
                    echo 'No google indexing please.';
                    return false;
                }
                unset($r);
                throw new Kohana_Exception('REG_INVALID_NAME');
            }
            // let's check some important values
            if(is_null($cellphone)){
                // if it's google just don't bother us 
                $r = @gethostbyaddr($_SERVER['REMOTE_ADDR']); 
                if(strpos($r, 'google.com')){
                    echo 'No google indexing please.';
                    return false;
                }
                unset($r);
                // others fail          
                throw new Kohana_Exception('REG_NO_CELL');
            }
            // Check the count of digits of Cellphone
            if(strlen($cellphone) != 10){
                // if it's google just don't bother us 
                $r = @gethostbyaddr($_SERVER['REMOTE_ADDR']); 
                if(strpos($r, 'google.com')){
                    echo 'No google indexing please.';
                    return false;
                }
                unset($r);
                throw new Kohana_Exception('REG_INVALID_CELL');
            }

            #############################
            ### User Registration #######
            #############################
               
            // Actually, let's see if this user already exists in our database with this email address or phone number.
            if($this->model_customers->exists($email, $cellphone)){
                // Exit 
                throw new Exception('C-Dupe', 1);
            } else {
                //adds user to newslettersubscribers
                $newsletter_model = new model_apis_newsletter();
                $checkExistingSubscription = $newsletter_model->existingNewsletterSubscription($email);                
                if($subscribe==1 && !$checkExistingSubscription){    
                    $newsletter_model->createNewsletterSubscription($email, $firstName, $birthdate, $subscribe, date('Y-m-d H:i:s'));
                }

                // Ready set go!
                $customerId = $this->model_customers->create($me, $firstName, $lastName, $email, $password, $cellphone, $landphone, $birthdate, $sendCall, $subscribe, $address, $city, $state, $country, $zipCode, $timezone);                
                
                // Check here for duplicate matches of name and birthday
                $matchFields = array('firstName' => $firstName, 'lastName' => $lastName, 'birthdate' => $birthdate);
                // Prepare the similar accounts, if any
                @$this->model_customers->duplicateMatches($matchFields, $customerId);
            }

            // Load up the customer for feature use.
            $customer = $this->model_customers->read($customerId);
            // log them in anyways, not that we don't have anything to fail.
            if($me == 0){
                $this->model_customers->doLogin($customer);
            }

            // Payment method is optional
            if(!empty($ccNumber) AND !is_null($ccNumber)){
                // Add the paymentMethod 
                $paymentMethods_model = new model_financials_paymentmethods();
                // Ready set go!
                if(!is_null($sameCCAddress) AND $sameCCAddress == 1){ // same address as info
                    $paymentMethodId = $paymentMethods_model->create($me, $customerId, $ccNumber, $ccExpYear, $ccExpMonth, $address, $zipCode, $city, $state, $country, 1, $cvv, $ccGiftCard);
                }else{
                    $paymentMethodId = $paymentMethods_model->create($me, $customerId, $ccNumber, $ccExpYear, $ccExpMonth, $ccAddress, $ccZip, $ccCity, $ccState, $ccCountry, 1, $cvv, $ccGiftCard);
                }
                // validate
                if($paymentMethodId == false){
                    throw new Exception('CC-F', 1);
                }
            }

            // all is cool
            $signup_success = true;
            // delete the intended session if present
            if(!is_null($this->sess->get('intendedDestination'))){
                $this->sess->delete('intendedDestination');
            }
        }catch(Exception $e){
            $error_code = $e->getMessage();
            $this->sess->set('purchase_error_code', $error_code);

            if(strpos($error_code, 'REG_') !== false){
                // This is a system error, we need to throw it out. 
                throw new Exception("Purchase controller has crashed: $error_code", 1);
            }else{
                // let's set up some error code description
                $error_message = 'Can\'t identify the error. Please contact Dev Team.';
                switch($error_code){
                    case 'C-Dupe':
                        $error_message = 'Duplicate Email or Cellphone.';
                        $error_message .= '('.$email.' - '.$cellphone.')';
                        break;
                    case 'CC-F':
                        $error_message = 'Credit Card cannot be processed.<br/><br/>';
                        $error_message .= '<b>Customer Details:</b><br/>';
                        $error_message .= 'Name: '.$firstName.' '.$lastName.'<br/>';
                        $error_message .= 'Email: '.$email.'<br/>';
                        $error_message .= 'Birthday: '.date('F d, Y', strtotime($birthdate)).'<br/>';
                        $error_message .= 'Cellphone: '.$cellphone.'<br/>';
                        $error_message .= 'Address: '.$address.', '.$city.', '.$state.', '.$country;
                        break;
                }
                // let's email the admins 
                $body = 'Hello CSR, <br/>'; 
                $body .= 'A customer registration has failed! <br/>';
                $body .= 'Error Code: <b>'.$error_code.'</b> <br/>';
                $body .= 'Error Description: '.$error_message.'<br/>';
                $body .= '<br/>Please contact Dev team if in need of any assistance.';
                // Send an email
                @Helper_Functions::emailAdmins('['.$error_code.'] A failed order has been detected.', $body);
                // we can do a soft redirect to customers panel based on a single condition.
                HTTP::redirect(URL::base().'customers/failure');
            }
            // this is mandatory here to exit
            return false;
        }
        
        // Redirect to Overview page
        HTTP::redirect(URL::base().'customers');
    }

    public function action_confirmation(){
        // authorized access only
        $this->require_login();

        // Prevent refresh 
        if(is_null($this->sess->get('purchase_success'))){
            if($this->sess->get('tier') == 2){
                HTTP::redirect(URL::base());
            } else {
                HTTP::redirect(URL::base().'customers/recharge');
            }
        }

        // Let's prepare the purchase data
        $purchase_data = $this->sess->get('purchase_data');
        $customerId = $purchase_data['customerId'];
        $psychicId = $purchase_data['psychicId'];
        $origin = $purchase_data['origin'];
        $appointmentId = $purchase_data['appointmentId'];
        $callbackId = $purchase_data['callbackId'];
        $paymentMethodId = $purchase_data['paymentMethodId'];
        $paymentId = $purchase_data['paymentId'];
		$tier = $this->model_customers->getCurrentTier($customerId, $paymentId);
        // this for the promo required package
        $promoCodeId = 0;
        if(isset($purchase_data['promotionalCodeId'])){
            $promoCodeId = $purchase_data['promotionalCodeId'];
        }
        // let's check if its from recharge page...
        $is_recharge = false;
        if(isset($purchase_data['recharge'])){
            $is_recharge = $purchase_data['recharge'];
        }

        // Read and Prepare...
        $customer = $this->model_customers->read($customerId); // Customer
        if(!$is_recharge){
            $psychic = $this->model_psychics->read($psychicId); // Psychic
        }
        // Callback
        $callbacks_model = new model_calls_callbacks();
        $callback = $callbacks_model->read($callbackId);
        // Payment Method
        $cardType = '';
        $cardEnding = '';
        if(!is_null($paymentMethodId)){
            $paymentMethods_model = new model_financials_paymentmethods();
            $card = $paymentMethods_model->read($paymentMethodId);
            switch($card['type']){
                case 'master':
                    $cardType = 'MC';
                    break;
                case 'visa':
                    $cardType = 'Visa';
                    break;
                case 'amex':
                    $cardType = 'AmEx';
                    break;
                default:
                    $cardType = strtoupper($card['type']);
            }
            $cardEnding = $card['lastFourDigits'];
        }
        // Payments
        $billedAmount = 0;
        if(!is_null($paymentId)){
            $payments_model = new model_financials_payments();
            $payment = $payments_model->read($paymentId);
            $billedAmount = $payment['amount'];
        }
        
        // Callback details
        $scheduledTime = $callback['scheduledTime'];
        if(!$is_recharge){
            // how long can this call be?
    		$minutes = $this->model_callbacks->calc_max_duration($customer, $psychic);
            $minutes = intval($minutes / 60.0);
		}

        $purchaseTime = helper_functions::pst2timezone($callback['createdAt'], $customer['timezone'], 'g:ia T n/j/Y'); // date('g:ia').' PST '.date('n/j/Y')

        // The main view and infobox
        $view = View::factory('purchases/confirmation');
        $infobox = View::factory('psychics/infoboxes/purchase_small');
       
        // check promo code
        if($promoCodeId != 0){
            $promo = $this->model_promotionalcodes->read($promoCodeId);
            $view->set('promo', $promo);
        }

        if(!$is_recharge){
            $infobox->set('psychic', $psychic)
                    ->set('enums', helper_functions::mergedEnums($psychic));
            $view->set('infobox', $infobox->render())
                 ->set('psychic', $psychic)
                 ->set('billed_minutes', $minutes)
                 ->set('minutes', $minutes);
        }

        //welcome message
        $message='';
        $landingPages= array('landing9','landing10');
        if(in_array($origin, $landingPages)){
            $message .= '<div class="marg_c">Welcome to Psychic Elements!</div>';
            $message .= '<div class="marg_b">'.(($callback['type'] == 0)?'Very soon, you will be receiving your callback from your psychic.':'Your appointment has been accepted and you will receive a call from us at the time specified below.').' Please make a note of your PIN number below and take a moment to check out the pre-reading tips so you can get the most from your experience. You will also receive an email receipt with this information for your records.</div>';
            $message .= '<div class="marg_c">We thank you for trusting us, and look forward to helping you in the future.</div>';
            $message .= '<div>Sincerely,<br/>Psychic Elements</div>';
        }
        else{
            $message .= '<p class="marg_c">Dear '.$customer['firstName'].',</p>';
            if($is_recharge){
                $event = 'promo has been successfully applied';
                if($billedAmount > 0){
                    $message .= '<div class="content">Your purchase has been successfully made! If you would like to get a reading, please click the button below to view our psychics.</div>';
                }else{
                    $message .= '<div class="content">Your promo has been successfully applied! If you would like to<br/>get a reading, please click the button below to view our psychics.</div>';
                }
                $message .= '<a href="'.URL::base().'customers">View My Account</a>';
            }
            else{
                $message .= '<p>Your '.(($callback['type'] == 0) ? 'callback' : 'appointment').' has been successfully '.(($callback['type'] == 0) ? 'set' : 'booked').' with your psychic. Please make note of your PIN number below and take a moment to check out the pre-reading tips so you can get the most from your experience. You will also receive an email receipt with this information for your records.</p>';
            }            
        }            
        $view->set('is_recharge', $is_recharge)
             ->set('cellphone', $customer['cellphone'])
             ->set('purchaseTime', $purchaseTime)
             ->set('cardType', $cardType)
             ->set('cardEnding', $cardEnding)
             // the view requires the customer and psychic information, also the callback
             ->set('customer', $customer)
             ->set('type', $callback['type']) // 0, 1 , false, true, null, true , '0', '1'
             ->set('appointmentId', $purchase_data['appointmentId'])
             ->set('scheduledTime', $scheduledTime)
             ->set('billed_amount', $billedAmount)
             ->set('pin', $customer['PIN'])
             ->set('timezone', $customer['timezone'])
             ->set('user_agent', $this->request->user_agent('mobile'))
             ->set('message', $message)
             ->set('landing_url',$origin);

        // Let's unset the variables now...
        $this->sess->delete('purchase_success');
        $this->sess->delete('purchase_data');

        echo $view->render();
    }

    public function action_statesData() {
        $countryId = $this->request->post('countryId');

        if($countryId==2){
            $options=$this->config['provinces'];
        }else{
            $options=$this->config['states'];
        }

        echo json_encode($options);
    }
    
    public function action_timezoneData(){
        $countryId = $this->request->post('countryId');

        switch($countryId){
            case 1:
                $country='LIMITED_US';
            break;
            case 2:
                $country='LIMITED_Canada';
            break;
            default:
                $country='US';
        }

        $options=helper_functions::timezones($country);
        echo json_encode($options);
    }

    public function action_failure(){
        if(is_null($this->sess->get('purchase_success'))){
            if($this->sess->get('tier') == 2){
                HTTP::redirect(URL::base());
            } else {
                HTTP::redirect(URL::base().'customers/recharge');
            } 
            return false;
        }

        // fire up the view
        $view = View::factory('customers/failure');

        // let's load up some data 
        $purchase_data = $this->sess->get('purchase_data');
        $error_code = $this->sess->get('purchase_error_code');

        if(is_null($this->sess->get('signup_success'))){
            $psychicId = $purchase_data['psychicId'];
            $psychic = $this->model_psychics->read($psychicId);
        }
        $customerId = $this->sess->get('customerId');
        $customer = $this->model_customers->read($customerId);

        if ($error_code == 'P-Unav-B' OR $error_code == 'P-Unav-C') {
            $paymentId = $purchase_data['paymentId'];
            $payment = $this->model_payments->read($paymentId);
            $paymentMethodId = $purchase_data['paymentMethodId'];
            $paymentMethod = $this->model_paymentmethods->read($paymentMethodId);

            $customerName = $customer['firstName'] . ' ' . $customer['lastName'];
            $psychicName = $psychic['nickName'] . ' ext ' . $psychic['psychicId'];
            $paymentDate = Helper_Functions::pst2timezone($payment['createdAt'], $customer['timezone'], 'F j, Y');
            $paymentTime = Helper_Functions::pst2timezone($payment['createdAt'], $customer['timezone'], 'g:ia T');
            $paymentAmount = '$' . number_format($payment['amount'], 2);
            $paymentInfo = $paymentMethod['type'] . ' ending in ' . $paymentMethod['lastFourDigits'];
        }

        // Let's set the error title and message accordingly...
        switch($error_code){
            case 'F-Promo':
                $title = 'Sorry, We Could Not Locate This Promotion';
                $message = 'This promotional code is not valid. Please call our customer care specialists at <a href="tel:'.helper_functions::getPhoneNumber().'">' . helper_functions::getPhoneNumber(true) . '</a> and we will be happy to help you get your reading.';
                break;
            case 'C-Promo':
                $title = 'Sorry, This Promotion Has Ended';
                $message = 'This promotional code is no longer valid. Please call our customer care specialists at <a href="tel:'.helper_functions::getPhoneNumber().'">' . helper_functions::getPhoneNumber(true) . '</a> and we will be happy to help you get your reading.';
                break;
            case 'CC-F':
                $title = 'Sorry, We Cannot Process Your Card';
                $message = 'Credit Card Is Not Acceptable. Please call our customer care specialists at <a href="tel:'.helper_functions::getPhoneNumber().'">' . helper_functions::getPhoneNumber(true) . '</a> and we will be happy to help you get your reading.';
                break;
            case 'PM-D':
                $title = 'Sorry, We Cannot Process Your Payment';
                $message = 'Credit Card Payment Was Denied. Please call our customer care specialists at <a href="tel:'.helper_functions::getPhoneNumber().'">' . helper_functions::getPhoneNumber(true) . '</a> and we will be happy to help you get your reading.';
                break;
            case 'PM-I':
                $title = 'Insufficient Funds';
                $message = 'It seems that you do not have sufficient funds in your account. Please call our customer care specialists at <a href="tel:'.helper_functions::getPhoneNumber().'">' . helper_functions::getPhoneNumber(true) . '</a> and we will be happy to help you get your reading.';
                break;
            case 'P-Unav-A': // No Payment
                $title = 'Sorry, but psychic ' . $psychic['nickName'] . ' is Unavailable.';
                $message = 'We\'re sorry, but '.$psychic['nickName'].' is no longer available for a callback. <br />Please choose 
                    another psychic on our search page (<a href="' . URL::base() . 'psychics">' . URL::base() . '/psychics</a>) 
                    or call ' . helper_functions::getPhoneNumber(true,$this->origin) . ' for customer care assistance.';
                break;
            case 'P-Unav-B': // First Time
                $title = 'Sorry, but Psychic ' . $psychic['nickName'] . ' is Unavailable';
                $message = '<p>Dear '.$customerName.',</p>
                     <p>Welcome to Psychic Elements!</p>
                     <p>
                     Your purchase information is below:
                     <ul>
                         <li>Purchase Date: '.$paymentDate.'</li>
                         <li>Purchase Time: '.$paymentTime.'</li>
                         <li>Purchase Amount: '.$paymentAmount.'</li>
                         <li>Payment Info: '.$paymentInfo.'</li>
                     </ul>
                     </p>
                     <p style="text-align: left;">
                         Unfortunately, '.$psychicName.' became unavailable. <br />Please choose another psychic on our
                         search page (<a href="'.URL::base().'psychics">'.URL::base().'psychics</a>) or call <a href="tel:'.helper_functions::getPhoneNumber().'">' . helper_functions::getPhoneNumber(true) . '</a> for customer care assistance.
                     </p>';

                break;
            case 'P-Unav-C': // Finalize
                $title = 'Sorry, but Psychic ' . $psychic['nickName'] . ' is Unavailable';
                $message = '<p>Dear '.$customerName.',</p>
                     <p>
                     Your purchase information is below:
                     <ul>
                         <li>Purchase Date: '.$paymentDate.'</li>
                         <li>Purchase Time: '.$paymentTime.'</li>
                         <li>Purchase Amount: '.$paymentAmount.'</li>
                         <li>Payment Info: '.$paymentInfo.'</li>
                     </ul>
                     </p>
                     <p style="text-align: left;">
                         Unfortunately, '.$psychicName.' became unavailable. <br />Please choose another
                         psychic on our search page (<a href="'.URL::base().'psychics">'.URL::base().'psychics</a>) or call <a href="tel:'.helper_functions::getPhoneNumber().'">' . helper_functions::getPhoneNumber(true) . '</a> for customer care assistance.
                     </p>';
                break;
            case 'PUR_NO_PURCHASE_ID':
                $title = 'We have already processed this order.';
                $message = ''; 
                break; 
            case 'PUR_SHORT_PURCHASE': 
                $title = 'Cannot book a callback for less than 5 minutes.'; 
                $message = ''; 
                break;
            default:
                $title = 'Sorry, We have encountered a system error.';
                $message = 'It seems that your account does not have sufficient funds. Please call our customer care specialists at <a href="tel:'.helper_functions::getPhoneNumber().'">' . helper_functions::getPhoneNumber(true) . '</a> and will be happy to help you get your reading.';
                $error_code = 'ERR_MISC';
        }
        // Prepare error variables
        $view->set('error_title', $title)
             ->set('error_message', $message)
             ->set('error_code', $error_code);

        // Delete unnecessary sessions now...
        if(!is_null($this->sess->get('signup_success'))){
            $this->sess->delete('signup_success');
        }
        $this->sess->delete('purchase_success');
        $this->sess->delete('purchase_error_code');

        echo $view->render();
    }

    public function action_testimonial()
    {
        $callbackId = base64_decode($this->request->param('id'));
        if(!is_null($callbackId)) {

            $view = View::factory('psychics/email_testimonial');

            if ($this->model_callbacks->hasTestimonial($callbackId)) {

                if ($this->isLoggedIn) {
                    $message = 'You\'ve already made a testimonial for this reading. <br /> Go to <a href="' . URL:: base() . '">My Account</a> ';
                } else {
                    $message = 'You\'ve already made a testimonial for this reading. <br /> Go to <a href="' . URL:: base() . '">home page</a> ';
                }

                $view->set('origin', '')
                    ->set('message', $message)
                    ->set('psychicId', null)
                    ->set('callbackId', null)
                    ->set('customerId', null)
                    ->set('readingDate', null);
            } else {
                $callback = $this->model_callbacks->read($callbackId);
                $view->set('origin', '')
                        ->set('psychicId', $callback['psychicId'])
                        ->set('callbackId', $callback['callbackId'])
                        ->set('customerId', $callback['customerId'])
                        ->set('readingDate', $callback['scheduledTime']);
            }

            echo $view->render();

        } else {
            echo 'Something went wrong';
        }
    }

    /*
    This function is a webhook for unsubscribers to Mailchimp Mailing lists
    */
    public function action_unsubscribe(){
        $post_data = $this->request->post();
        // validate a request post was passed
        if($post_data){
            // post validation
            if(!is_null($post_data['data'])){
                return false;
            }
            // validate unsubscriber email
            if(array_key_exists('email', $post_data['data'])){
                // unsubscribe
                $this->model_customers->unsubscribeToNewsletter($post_data['data']);                
            }
        }
    }

}
