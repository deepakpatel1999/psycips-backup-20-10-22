 <section id="footer-cta">
        <div class="container-area">
            <div class="cta-inner">
                <h3>Today You Get: FREE Lifetime " Email Horoscope Subscription" <br>
                    (a $99 Value)
                    Change 70% to 87%OFF
                </h3>
                <h1>Get Up To 87% Off</h1>
                <h2 style="margin-bottom: 0;">Best customer care 7 days a week</h2>
                <h2>Call Us - 888-777-1393</h2>
                <div class="cta-action">
                    <div class="btn-first">
                        <a class="btn-primary" href="https://offers.psychicelements.com/get-started-now">Book Your Reading Now!</a>
                    </div>
                    <div class="btn-second">
                        <a class="btn-primary" href="https://psychicelements.com/plans-pricing/">See plans & pricing</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="footer-main">
        <div class="container-area">
            <div class="footer-main-area">
                <div class="footer-widget first-widget">
                    <div class="intro-footer widget-inner">
                        <div class="footer-logo">
                            <img src="<?php echo URL::base(); ?>img/header_logo-1.png">
                            <div class="social-icon mobile-social">
                            <span class="icon-inner">
                                <a href="https://www.tiktok.com/@psychicelements.com?lang=en" class="icon-anchor">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="46" height="46" viewBox="0 0 46 46"
                                        fill="none">
                                        <g filter="url(#filter0_d_1075_300)">
                                            <circle cx="23" cy="22" r="19" fill="white"></circle>
                                        </g>
                                        <path
                                            d="M28.491 17.1716C28.3771 17.1128 28.2663 17.0482 28.1588 16.9783C27.8464 16.7717 27.5599 16.5283 27.3056 16.2534C26.6692 15.5253 26.4316 14.7866 26.344 14.2695H26.3476C26.2744 13.8402 26.3047 13.5625 26.3092 13.5625H23.411V24.7696C23.411 24.9201 23.411 25.0688 23.4046 25.2157C23.4046 25.234 23.4029 25.2509 23.4018 25.2706C23.4018 25.2787 23.4018 25.2871 23.4001 25.2955V25.3019C23.3695 25.704 23.2406 26.0924 23.0247 26.433C22.8088 26.7736 22.5125 27.0559 22.1619 27.2552C21.7964 27.4631 21.3831 27.5721 20.9627 27.5716C19.6123 27.5716 18.5179 26.4705 18.5179 25.1106C18.5179 23.7508 19.6123 22.6497 20.9627 22.6497C21.2183 22.6495 21.4723 22.6897 21.7154 22.7689L21.7189 19.8179C20.9811 19.7225 20.2315 19.7812 19.5175 19.9901C18.8035 20.1989 18.1406 20.5535 17.5704 21.0314C17.0709 21.4655 16.6509 21.9834 16.3294 22.5618C16.2071 22.7727 15.7455 23.6204 15.6896 24.996C15.6544 25.7768 15.8889 26.5858 16.0007 26.9201V26.9271C16.071 27.124 16.3435 27.7959 16.7875 28.3622C17.1456 28.8165 17.5686 29.2156 18.0429 29.5466V29.5396L18.05 29.5466C19.4531 30.5001 21.0087 30.4375 21.0087 30.4375C21.278 30.4266 22.1801 30.4375 23.2046 29.952C24.3408 29.4138 24.9877 28.6118 24.9877 28.6118C25.401 28.1327 25.7296 27.5866 25.9594 26.9971C26.2217 26.3077 26.3092 25.4808 26.3092 25.1504V19.2047C26.3444 19.2258 26.8127 19.5355 26.8127 19.5355C26.8127 19.5355 27.4873 19.968 28.5399 20.2496C29.2951 20.45 30.3125 20.4921 30.3125 20.4921V17.615C29.956 17.6536 29.2321 17.5411 28.491 17.1716V17.1716Z"
                                            fill="#737980"></path>
                                        <defs>
                                            <filter id="filter0_d_1075_300" x="0" y="0" width="46" height="46"
                                                filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                                                <feGaussianBlur stdDeviation="2"></feGaussianBlur>
                                            </filter>
                                        </defs>
                                    </svg> </a>
                            </span>
                            <span class="icon-inner">
                                <a href="https://www.facebook.com/psychicelements" class="icon-anchor">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="46" height="46" viewBox="0 0 46 46"
                                        fill="none">
                                        <g filter="url(#filter0_d_1075_301)">
                                            <circle cx="23" cy="22" r="19" fill="white"></circle>
                                        </g>
                                        <path
                                            d="M27 19.2457H23.9321V17.5644C23.9321 16.933 24.4346 16.7849 24.7865 16.7849H26.9469V14.0093L23.9675 14C20.6628 14 19.9124 16.0701 19.9124 17.3959V19.2457H18V22.1046H19.9124V30.2H23.9343V22.1065H26.6481L27 19.2457Z"
                                            fill="#737980"></path>
                                        <defs>
                                            <filter id="filter0_d_1075_301" x="0" y="0" width="46" height="46"
                                                filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                                                <feGaussianBlur stdDeviation="2"></feGaussianBlur>
                                            </filter>
                                        </defs>
                                    </svg> </a>
                            </span>
                            <span class="icon-inner custom-ic">
                                <a href="https://www.instagram.com/psychicelementscom/" class="icon-anchor">
                                <svg xmlns="http://www.w3.org/2000/svg" width="44" height="44" viewBox="0 0 44 44" fill="none">
                                <path d="M12.9375 0C5.83594 0 0 5.82813 0 12.9375V31.0625C0 38.1641 5.82813 44 12.9375 44H31.0625C38.1641 44 44 38.1719 44 31.0625V12.9375C44 5.83594 38.1719 0 31.0625 0H12.9375ZM12.9375 4H31.0625C36.0078 4 40 7.99219 40 12.9375V31.0625C40 36.0078 36.0078 40 31.0625 40H12.9375C7.99219 40 4 36.0078 4 31.0625V12.9375C4 7.99219 7.99219 4 12.9375 4ZM33.8125 8.375C32.8047 8.375 32 9.17969 32 10.1875C32 11.1953 32.8047 12 33.8125 12C34.8203 12 35.625 11.1953 35.625 10.1875C35.625 9.17969 34.8203 8.375 33.8125 8.375ZM22 10C15.3984 10 10 15.3984 10 22C10 28.6016 15.3984 34 22 34C28.6016 34 34 28.6016 34 22C34 15.3984 28.6016 10 22 10ZM22 14C26.4453 14 30 17.5547 30 22C30 26.4453 26.4453 30 22 30C17.5547 30 14 26.4453 14 22C14 17.5547 17.5547 14 22 14Z" fill="#818A91"/>
                                </svg> </a>
                            </span>
                            <span class="icon-inner custom-ic">
                                <a href="https://www.youtube.com/channel/UCyojhkUSVdxQVvgoE3N-ClQ" class="icon-anchor">
                                <svg xmlns="http://www.w3.org/2000/svg" width="40" height="32" viewBox="0 0 40 32" fill="none">
                                <path d="M39.164 4.372C38.704 2.652 37.348 1.296 35.628 0.836C32.508 4.17233e-07 20 0 20 0C20 0 7.492 4.17233e-07 4.372 0.836C2.652 1.296 1.296 2.652 0.836 4.372C-5.96046e-08 7.492 0 16 0 16C0 16 -5.96046e-08 24.508 0.836 27.628C1.296 29.348 2.652 30.704 4.372 31.164C7.492 32 20 32 20 32C20 32 32.508 32 35.628 31.164C37.35 30.704 38.704 29.348 39.164 27.628C40 24.508 40 16 40 16C40 16 40 7.492 39.164 4.372ZM16 21.196V10.804C16 10.034 16.834 9.554 17.5 9.938L26.5 15.134C27.166 15.518 27.166 16.482 26.5 16.866L17.5 22.062C16.834 22.448 16 21.966 16 21.196Z" fill="#818A91"/>
                                </svg> </a>
                            </span>
                            </div>
                        </div>
                        <div class="site-text">Made with &nbsp;<svg xmlns="http://www.w3.org/2000/svg" width="27"
                                height="20" viewBox="0 0 27 20" fill="none">
                                <path
                                    d="M13.5101 3.33688C13.9976 2.56045 14.6055 1.91751 15.3554 1.3781C18.1358 -0.621548 22.4375 -0.425397 24.9433 1.83851C26.9336 3.63656 27.4243 5.77242 26.6528 8.15619C26.0573 10.0006 24.9247 11.5916 23.5484 13.0518C21.3204 15.4138 18.611 17.2772 15.6856 18.9118C15.0376 19.2741 14.3741 19.6174 13.7106 19.9552C13.6119 20.0042 13.4329 20.0179 13.3403 19.9715C9.97672 18.2797 6.83221 16.3264 4.19686 13.7955C2.61689 12.2781 1.30847 10.6026 0.527745 8.64112C-0.120291 7.01471 -0.243726 5.37739 0.567862 3.77277C1.62323 1.68595 3.46551 0.408243 6.02062 0.0922226C9.23611 -0.302803 11.7295 0.773301 13.4267 3.23881C13.4453 3.26332 13.4638 3.28239 13.5101 3.33688Z"
                                    fill="#FF6363"></path>
                            </svg> <br>
                            in Los Angeles</div>
                        <div class="footer-content">
                            Introductory offers for new <br>customers only. You must be<br>
                            18 years of age or older to use<br> Psychic Elements. </div>
                    </div>
                </div>
                <div class="footer-widget tab-widget">
                    <h4 class="ser">Service <span class="caret"></span></h4>
                    <div class="link-footer widget-inner ser_toggle" style="display:none;">
                        <ul>
                            <li>
                                <a href="https://psychicelements.com/career/#">
                                    <span>Why Psychic Element</span>
                                </a>
                            </li>
                            <li>
                                <a href="https://psychicelements.com/how-it-work/">
                                    <span>How it works</span>
                                </a>
                            </li>
                            <li>
                                <a href="https://psychicelements.com/career/">
                                    <span>Our work</span>
                                </a>
                            </li>
                            <li>
                                <a href="https://psychicelements.com/plans-pricing/">
                                    <span>Pricing</span>
                                </a>
                            </li>
                            <li>
                                <a href="http://psychicelements.com/blog/">
                                    <span>Blog</span>
                                </a>
                            </li>
                            <li>
                                <a href="https://psychicelements.com/psychic-element-landing/">
                                    <span>Psychic Landing</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="footer-widget tab-widget">
                    <h4 class="recou">Resources <span class="caret"></span></h4> 
                    <div class="link-footer widget-inner recou_toggle" style="display:none;">
                        <ul>
                            <li>
                                <a href="https://app.psychicelements.com/horoscope/libra">
                                    <span>Horoscope</span>
                                </a>
                            </li>
                             <li><a href="javascript:void(0);" class="subscribe newsletter marg_none_impt">Newsletter Signup</a></li>
                            <li>
                                <a href="http://psychicelements.com/psychic-listing/">
                                    <span> All Psychics</span>
                                </a>
                            </li>
                            <li>
                                <a href="https://psychicelements.com/career/">
                                    <span>Career</span>
                                </a>
                            </li>
                            <li>
                                <a href="https://psychicelements.com/full-review/">
                                    <span>Customer Reviews</span>
                                </a>
                            </li>
                            <li>
                                <a href="http://psychicelements.com/privacy-policy-2/">
                                    <span>Privacy Policy</span>
                                </a>
                            </li>
                            <li>
                                <a href="http://psychicelements.com/terms-conditions/">
                                    <span>Terms &amp; Conditions</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="footer-widget tab-widget last-widget">
                    <h4>Connect Us</h4>
                    <div class="connect-footer widget-inner">
                        <div class="social-icon">
                            <span class="icon-inner">
                                <a href="https://www.tiktok.com/@psychicelements.com?lang=en" class="icon-anchor">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="46" height="46" viewBox="0 0 46 46"
                                        fill="none">
                                        <g filter="url(#filter0_d_1075_300)">
                                            <circle cx="23" cy="22" r="19" fill="white"></circle>
                                        </g>
                                        <path
                                            d="M28.491 17.1716C28.3771 17.1128 28.2663 17.0482 28.1588 16.9783C27.8464 16.7717 27.5599 16.5283 27.3056 16.2534C26.6692 15.5253 26.4316 14.7866 26.344 14.2695H26.3476C26.2744 13.8402 26.3047 13.5625 26.3092 13.5625H23.411V24.7696C23.411 24.9201 23.411 25.0688 23.4046 25.2157C23.4046 25.234 23.4029 25.2509 23.4018 25.2706C23.4018 25.2787 23.4018 25.2871 23.4001 25.2955V25.3019C23.3695 25.704 23.2406 26.0924 23.0247 26.433C22.8088 26.7736 22.5125 27.0559 22.1619 27.2552C21.7964 27.4631 21.3831 27.5721 20.9627 27.5716C19.6123 27.5716 18.5179 26.4705 18.5179 25.1106C18.5179 23.7508 19.6123 22.6497 20.9627 22.6497C21.2183 22.6495 21.4723 22.6897 21.7154 22.7689L21.7189 19.8179C20.9811 19.7225 20.2315 19.7812 19.5175 19.9901C18.8035 20.1989 18.1406 20.5535 17.5704 21.0314C17.0709 21.4655 16.6509 21.9834 16.3294 22.5618C16.2071 22.7727 15.7455 23.6204 15.6896 24.996C15.6544 25.7768 15.8889 26.5858 16.0007 26.9201V26.9271C16.071 27.124 16.3435 27.7959 16.7875 28.3622C17.1456 28.8165 17.5686 29.2156 18.0429 29.5466V29.5396L18.05 29.5466C19.4531 30.5001 21.0087 30.4375 21.0087 30.4375C21.278 30.4266 22.1801 30.4375 23.2046 29.952C24.3408 29.4138 24.9877 28.6118 24.9877 28.6118C25.401 28.1327 25.7296 27.5866 25.9594 26.9971C26.2217 26.3077 26.3092 25.4808 26.3092 25.1504V19.2047C26.3444 19.2258 26.8127 19.5355 26.8127 19.5355C26.8127 19.5355 27.4873 19.968 28.5399 20.2496C29.2951 20.45 30.3125 20.4921 30.3125 20.4921V17.615C29.956 17.6536 29.2321 17.5411 28.491 17.1716V17.1716Z"
                                            fill="#737980"></path>
                                        <defs>
                                            <filter id="filter0_d_1075_300" x="0" y="0" width="46" height="46"
                                                filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                                                <feGaussianBlur stdDeviation="2"></feGaussianBlur>
                                            </filter>
                                        </defs>
                                    </svg> </a>
                            </span>
                            <span class="icon-inner">
                                <a href="https://www.facebook.com/psychicelements" class="icon-anchor">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="46" height="46" viewBox="0 0 46 46"
                                        fill="none">
                                        <g filter="url(#filter0_d_1075_301)">
                                            <circle cx="23" cy="22" r="19" fill="white"></circle>
                                        </g>
                                        <path
                                            d="M27 19.2457H23.9321V17.5644C23.9321 16.933 24.4346 16.7849 24.7865 16.7849H26.9469V14.0093L23.9675 14C20.6628 14 19.9124 16.0701 19.9124 17.3959V19.2457H18V22.1046H19.9124V30.2H23.9343V22.1065H26.6481L27 19.2457Z"
                                            fill="#737980"></path>
                                        <defs>
                                            <filter id="filter0_d_1075_301" x="0" y="0" width="46" height="46"
                                                filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                                                <feGaussianBlur stdDeviation="2"></feGaussianBlur>
                                            </filter>
                                        </defs>
                                    </svg> </a>
                            </span>
                            <span class="icon-inner custom-ic">
                                <a href="https://www.instagram.com/psychicelementscom/" class="icon-anchor">
                                <svg xmlns="http://www.w3.org/2000/svg" width="44" height="44" viewBox="0 0 44 44" fill="none">
                                <path d="M12.9375 0C5.83594 0 0 5.82813 0 12.9375V31.0625C0 38.1641 5.82813 44 12.9375 44H31.0625C38.1641 44 44 38.1719 44 31.0625V12.9375C44 5.83594 38.1719 0 31.0625 0H12.9375ZM12.9375 4H31.0625C36.0078 4 40 7.99219 40 12.9375V31.0625C40 36.0078 36.0078 40 31.0625 40H12.9375C7.99219 40 4 36.0078 4 31.0625V12.9375C4 7.99219 7.99219 4 12.9375 4ZM33.8125 8.375C32.8047 8.375 32 9.17969 32 10.1875C32 11.1953 32.8047 12 33.8125 12C34.8203 12 35.625 11.1953 35.625 10.1875C35.625 9.17969 34.8203 8.375 33.8125 8.375ZM22 10C15.3984 10 10 15.3984 10 22C10 28.6016 15.3984 34 22 34C28.6016 34 34 28.6016 34 22C34 15.3984 28.6016 10 22 10ZM22 14C26.4453 14 30 17.5547 30 22C30 26.4453 26.4453 30 22 30C17.5547 30 14 26.4453 14 22C14 17.5547 17.5547 14 22 14Z" fill="#818A91"/>
                                </svg> </a>
                            </span>
                            <span class="icon-inner custom-ic">
                                <a href="https://www.youtube.com/channel/UCyojhkUSVdxQVvgoE3N-ClQ" class="icon-anchor">
                                <svg xmlns="http://www.w3.org/2000/svg" width="40" height="32" viewBox="0 0 40 32" fill="none">
                                <path d="M39.164 4.372C38.704 2.652 37.348 1.296 35.628 0.836C32.508 4.17233e-07 20 0 20 0C20 0 7.492 4.17233e-07 4.372 0.836C2.652 1.296 1.296 2.652 0.836 4.372C-5.96046e-08 7.492 0 16 0 16C0 16 -5.96046e-08 24.508 0.836 27.628C1.296 29.348 2.652 30.704 4.372 31.164C7.492 32 20 32 20 32C20 32 32.508 32 35.628 31.164C37.35 30.704 38.704 29.348 39.164 27.628C40 24.508 40 16 40 16C40 16 40 7.492 39.164 4.372ZM16 21.196V10.804C16 10.034 16.834 9.554 17.5 9.938L26.5 15.134C27.166 15.518 27.166 16.482 26.5 16.866L17.5 22.062C16.834 22.448 16 21.966 16 21.196Z" fill="#818A91"/>
                                </svg> </a>
                            </span>
                        </div>
                        <div class="card-image">
                            <img src="<?php echo URL::base(); ?>img/card-img.png">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="copyright-section">
        <div class="container-area">
            <p>Copyright © 2022 All rights reserved</p>
        </div>
    </div>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <!-- <script src="<?php echo URL::base(); ?>jquery.min.js"></script> -->
    <!-- <script src="<?php echo URL::base(); ?>bootstrap.min.js"></script> -->
  <!--   <script> 
        $(document).ready(function(){
          $(".footer-widget h4").click(function(){
            $(".link-footer").slideToggle("slow");
          });
        });
        </script> -->



        <!-- old footer data -->
<!-- <script src="<?php echo URL::base(); ?>js/newJquery/jquery.min.js"></script> -->
   <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.5/jquery.min.js"></script>

<script>
$(document).ready(function(){
  $('.recou').click(function(){
    $('.recou_toggle').toggle();
  });
});
</script>
<script>
$(document).ready(function(){
  $('.ser').click(function(){
    $('.ser_toggle').toggle();
  });
});
</script>
        <script src="<?php echo URL::base(); ?>js/libs/jquery.min.js"></script>
        

          <script>var base_url = "<?php echo URL::base(); ?>";</script>
    <script src="<?php echo URL::base(); ?>js/libs/jquery.js"></script>
    <script src="<?php echo URL::base(); ?>js/jqui/js/jquery-ui-1.10.4.custom.min.js"></script>
    <script src="<?php echo URL::base(); ?>js/libs/jquery.mask.min.js"></script>
    <script src="<?php echo URL::base(); ?>js/libs/auto_numeric.js"></script>
    <script src="<?php echo URL::base(); ?>bootstrap/js/bootstrap.min.js"></script>
    <script src="<?php echo URL::base(); ?>js/lib.js"></script>
    <script src="<?php echo URL::base(); ?>js/global.js"></script>
    <script src="<?php echo URL::base(); ?>js/psychics.js"></script>
    <script src="<?php echo URL::base(); ?>js/purchases.js"></script>
    <?php if(Request::initial()->controller() == 'Customers' OR (Request::initial()->controller() == 'Purchases' AND Request::initial()->action() == 'package')){ ?>
        <script src="<?php echo URL::base(); ?>js/customers.js"></script>
    <?php } ?>
    <script src="<?php echo URL::base(); ?>js/testimonials.js"></script>

</body>
<grammarly-desktop-integration data-grammarly-shadow-root="true"></grammarly-desktop-integration>

</html>