<!DOCTYPE html>
<!-- saved from url=(0064)https://bootstrapdocs.com/v3.2.0/docs/examples/navbar-fixed-top/ -->
<html lang="en">

<head>
  <?php $session = Session::instance(); ?>

  <title><?php echo $title; ?></title>
  <meta charset="utf-8" />
  <?php
  $acronym = 'staging';
  if ($acronym == 'staging')
    echo '<meta name=\'robots\' content=\'noindex,nofollow\' />';
  ?>
  <meta http-equiv="X-UA-Compatible" content="IE=100">
  <meta name="description" content="<?php echo $metaDescription; ?>">
  <meta name="viewport" content="width=device-width, user-scalable=yes">
  <?php if(Request::initial()->controller() == 'Learn' && Request::initial()->param('id') != ''): ?>
  <?php echo helper_functions::getLearnFaceBookImage(Request::initial()->param('id')); ?> 
<?php endif; ?>

<?php if(Request::initial()->controller() == 'Psychics' AND Request::initial()->action() == 'profile'){ ?>
  <meta property="og:image" content="<?php echo URL::base(); ?>uploaded/profilePictures/psychics/profilePic_<?php echo Request::initial()->param('id') ?>.jpg">
  <meta property="og:image:type" content="image/jpeg">
  <meta property="og:image:width" content="125">
  <meta property="og:image:height" content="114">
<?php } ?>   

<link rel="stylesheet" href="<?php echo URL::base(); ?>bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo URL::base(); ?>css/main_new.css">
<link rel="stylesheet" href="<?php echo URL::base(); ?>js/jqui/css/ui-lightness/jquery-ui-1.10.4.custom.min.css" />
<link rel="stylesheet" href="<?php echo URL::base(); ?>css/main.css" />   
<link rel="stylesheet" href="<?php echo URL::base(); ?>css/newmain.css" />  
<?php echo helper_functions::loadPageCss(); ?>
<link rel="stylesheet" href="<?php echo URL::base(); ?>css/mobile_main.css" />
<link rel="stylesheet" href="<?php echo URL::base(); ?>css/google-fonts.css" />
<?php echo helper_functions::canonicalLink(); ?>

    <!--[if IE 8]>
    <link rel="stylesheet" href="<?php echo URL::base(); ?>css/ie8.css" />
  <![endif]-->
  <link rel="shortcut icon" type="image/png" href="<?php echo URL::base(); ?>img/favicon.ico" />

                <div class="clearfix"></div>
  <?php if($enable_remarketing){echo $mktHeadView;} ?>
</head>

<body data-new-gr-c-s-check-loaded="14.1081.0" data-gr-ext-installed="">

  <!-- Fixed navbar -->
  <header>
    <div class="navbar navbar-default navbar-fixed-top" role="navigation">
      <div class="container-area">
        <div class="header-container">
          <div class="header-inner">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse"
              data-target=".navbar-collapse">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <div class="brand-image">
              <a href="https://app.fitupp.com"><img
                src="<?php echo URL::base(); ?>img/header_logo-1.png" alt=""></a>
                <div class="brand-badge"><a href="https://docs.google.com/forms/d/e/1FAIpQLSdXGMzBo97M74qKxdZFMdICIxAJY5-TbVUWhp5nE1S3Ra_YxQ/viewform" target="_blank">We're hiring?</a></div>
              </div>
            </div>
          </div>
          <div class="navbar-collapse collapse in" data-toggle="collapse" data-target=".navbar-collapse">
            <div class="close" data-toggle="collapse" data-target=".navbar-collapse">
              <a href="#">
                <svg viewPort="0 0 12 12" version="1.1" xmlns="http://www.w3.org/2000/svg">
                  <line x1="1" y1="11" x2="11" y2="1" stroke="black" stroke-width="2" />
                  <line x1="1" y1="1" x2="11" y2="11" stroke="black" stroke-width="2" />
                </svg>
              </a>
            </div>
            <ul class="nav navbar-nav navbar-right">
              <li class="active"><a href="https://psychicelements.com/psychic-listing/">Select A
              Psychic</a></li>


              <li><a href="https://psychicelements.com/plans-pricing/">Pricing</a>
              </li>

              <li><a href="https://psychicelements.com/full-review/">Customer
              Reviews</a></li>

              <li><a href="https://psychicelements.com/blog/">Blog</a></li>

              <li class="Login_menu"><a href="https://app.fitupp.com/customers/login">Login</a></li>

              <li class="action-btn"><a target="_blank" href="https://offers.psychicelements.com/get-started-now">Get a Reading</a></li>

              <li class="btn-primary"><a href="#">Customer Support 888-777-1393</a></li>
            </ul>
          </div>


        </div>
      </div>
    </div>
  </header>
