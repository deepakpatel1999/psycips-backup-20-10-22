
<div class="account_container">
    <div class="recharge_container">
        <form method="post" class="expandable_form" action="">
        	<input type="hidden" id="origin" name="origin" value="promos">
            <div class="recharge_tier_text visible-xs">
                <div class="title">SELECT A PROMO AND PREPARE FOR A GREAT READING!</div>
            </div>
            <div class="package_selection promos">
            	<?php for($p=0; $p < count($promos); $p++){ ?>
            		<?php if(isset($promos[$p])){ ?>
            			
            			<div class="package_price has_promo" id="<?php echo $promos[$p]['package']; ?>">
							<div class="price promo">
								<div class="hidden-xs">
									<div>$<?php echo number_format($promos[$p]['package'], 2); ?></div>
									<?php if(in_array($promos[$p]['package'], $promo_packages_excempt)){ ?>
										<div class="sm_marg_tb text">for</div>
									<?php }else{ ?>
										<div class="sm_marg_tb text">+ free</div>
									<?php } ?>
									<div>
									<?php
									if($promos[$p]['amount'] > 0){
										echo '$'.number_format($promos[$p]['amount'], 2);
									}else{
										echo intval($promos[$p]['minutes']).' mins';
									}
									?>
									</div>
									<div class="promo_code hidden-xs">
										<div class="lbl">Use code:</div>
										<div class="code"><?php echo $promos[$p]['code']; ?></div>
										<?php if(!is_null($promos[$p]['expirationDate'])){ ?>
											<div class="exp">Expires on <?php echo date('m-d-Y', strtotime($promos[$p]['expirationDate'])); ?></div>
										<?php } ?>
									</div>
								</div>
								<div class="visible-xs">
									<div class="smr_marg_b">
										<?php
										$promo_value = intval($promos[$p]['minutes']).' mins';
										if($promos[$p]['amount'] > 0){
											$promo_value = '$'.number_format($promos[$p]['amount'], 2);
										}
										?>
										$<?php echo number_format($promos[$p]['package'], 2); ?> <span class="text"><?php echo in_array($promos[$p]['package'], $promo_packages_excempt) ? 'for' : '+ free'; ?></span> <?php echo $promo_value; ?>
									</div>
									<div class="mobile_promo">
										<span class="lbl">Use code:</span>
										<span class="code"><?php echo $promos[$p]['code']; ?></span>
										<div class="clearfix"></div>
										<?php if(!is_null($promos[$p]['expirationDate'])){ ?>
											<div class="exp">Expires on <?php echo date('m-d-Y', strtotime($promos[$p]['expirationDate'])); ?></div>
										<?php } ?>
									</div>
								</div>
							</div>
						</div>
            			
					<?php } ?>
            	<?php } ?>
            </div>

            <div class="recharge_tier_text">
                <div class="title hidden-xs">SELECT A PROMO AND PREPARE FOR A GREAT READING!</div>
                <?php if(count($promos) > 0){ ?>
                	<input type="button" class="action_button customer-recharge-by-package" data-amount="" value="Continue" />
                <?php }else{ ?>
                	<a href="<?php echo URL::base(); ?>psychics" class="action_button">Continue</a>
                <?php } ?>
            </div>
            <div class="clearfix"></div>
        </form>
    </div>
</div>