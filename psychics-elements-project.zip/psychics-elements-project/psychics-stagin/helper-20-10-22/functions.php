<?php defined('SYSPATH') or die('No direct access allowed.');

require DOCROOT.'vendor/autoload.php';

use \DrewM\MailChimp\MailChimp;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

class Helper_Functions {
    /*
     * Loads the CSS for a specific page / controller
     */
    public static function loadPageCss(){
        $css = '';
        switch(Request::initial()->controller()){
            case 'Home':
                $css = '<link rel="stylesheet" href="'.URL::base().'css/home.css" />';
                break;
            case 'Landing9':
                $css = '<link rel="stylesheet" href="'.URL::base().'css/home.css" />';
                $css .= '<link rel="stylesheet" href="'.URL::base().'css/landing9.css" />';
                break;
            case 'Psychics':
                $css = '<link rel="stylesheet" href="'.URL::base().'css/psychics.css">';
                break;
            case 'Horoscope':
                $css = '<link rel="stylesheet" href="'.URL::base().'css/horoscope.css">';
                break;
            case 'About':
            case 'Faq':
                $css = '<link rel="stylesheet" href="'.URL::base().'css/company.css">';
                break;
            case 'Learn':
                $css = '<link rel="stylesheet" href="'.URL::base().'css/learn.css">';
                break;
            case 'Landingfreeapp':
                $css = '<link rel="stylesheet" href="'.URL::base().'css/landingfreeapp.css">';
                break;
        }
        $css .= '<link rel="stylesheet" href="'.URL::base().'css/myaccount.css" />';
        // If our page is a landing page, load respective style...
        if(strpos(Request::initial()->controller(), 'Landing') !== false){
            // Check the CSS of the LP if exists...
            if(file_exists('./css/'.strtolower(Request::initial()->controller()).'.css')){
                $css .= '<link rel="stylesheet" href="'.URL::base().'css/'.strtolower(Request::initial()->controller()).'.css" />';
            }
        }
        return $css;
    }
    /*
     * This is used to interpret to web spiders that the given page should be treated as though it were a copy of the URL 
     */
    public static function canonicalLink(){
         // Psychic Appointment
        if(Request::initial()->controller() == 'Psychics' AND Request::initial()->action() == 'book'){
            if(strpos($_SERVER['REQUEST_URI'], 'introductory-offer') !== false OR strpos($_SERVER['REQUEST_URI'], 'landing14') !== false OR strpos($_SERVER['REQUEST_URI'], 'landing9') !== false){
                return '<link rel="canonical" href="'.URL::base().'psychics/book/'.Request::initial()->param('id').'" />';
            }
        }
        // Psychics page
        if(strpos($_SERVER['REQUEST_URI'], 'psychics/') !== false){
            return '<link rel="canonical" href="'.URL::base().'psychics" />';
        }
        // For Horoscope pages
        if(Request::initial()->controller() == 'Horoscope'){
            return '<link rel="canonical" href="'.URL::base().'" />';
        }
        // For this specific Psychic checkout page
        if(strpos($_SERVER['REQUEST_URI'], 'landing14/checkout/1060') !== false){
            return '<link rel="canonical" href="'.URL::base().'landing14/checkout" />';
        }
        if(strpos($_SERVER['REQUEST_URI'], 'landing14/?tel=8887771393')){
            return '<link rel="canonical" href="'.URL::base().'landing14" />';
        }
        // Intro Offer Checkout
        if(strpos($_SERVER['REQUEST_URI'], 'introductory-offer/checkout') !== false){
            return '<link rel="canonical" href="'.URL::base().'landing14/checkout/'.Request::initial()->param('id').'" />';
        }        
    }

    public static function datatables_search($search_value, $records) {
        if ($search_value != '') {
            $pattern = '~' . preg_quote($_GET['search']['value']) . '~i';
            $records = array_filter($records, function($record) use($pattern) {
                $columns = array_keys($record);
                foreach ($columns as $column) {
                    if (!is_array($record[$column])) {
                        if (preg_match($pattern,  $record[$column])) {
                            return $record;
                        } 
                    }
                }
                return null;
            });
        }
        return $records;
    }

    public static function logEntry($msg, $logFilePath = 'logs/system.log'){
        $str = '['. date("F j, Y, g:i:s a"). '] |'.helper_functions::getIP().'| '; 
        $str .= $msg; 
        $str .= PHP_EOL;
        file_put_contents(APPPATH.$logFilePath, $str, FILE_APPEND);
    }

    ###########################
    #### Polling Utilities ####
    ###########################
    
    public static function add_notify($title, $message, $type = NULL){
        // stamp with current time, but every 5 seconds refresh. 
        //$json_line = json_encode(array('title' => $title, 'text' => $text, 'type' => $type, 'uniqId' => uniqId())). PHP_EOL;
        // put this in file 
        //$filename = APPPATH.'/logs/'.intval(time() / 5).'.poll'; // int value, circulated every 5 seconds. 
        //file_put_contents($filename, $json_line, FILE_APPEND);
        // @DB::insert('vocetis_polls', array('title', 'message', 'type'))->values(array($title, $message, $type))->execute();
        $data = array(
                'uniqId' => uniqid('msg'),
                'title' => $title,
                'message' => $message,
                'type' => $type
            );

        // Send it off asynch
        @exec("php ".APPPATH."drone.php '".base64_encode(json_encode($data))."' > /dev/null &"); // no $output

        return false;
    }
    
    public static function dailyQuote(){
        $sql = 'SELECT * FROM dailyQuotes ORDER BY RAND() LIMIT 1';
        $result = DB::query(Database::SELECT, $sql)->execute()->current();
        return '<span style="color: #000; font-family: \'Roboto\', sans-serif;  font-weight: 300; line-height: 1.625;">'.$result['quote'].'</span> &nbsp;<span style="font-weight: 600; font-style: italic; color: #474747; font-size: 10px; ">'.$result['person'].'</span>';
    }

    public static function array_orderby() {
        $args = func_get_args();
        $data = array_shift($args);
        foreach ($args as $n => $field) {
            if (is_string($field)) {
                $tmp = array();
                foreach ($data as $key => $row)
                    $tmp[$key] = $row[$field];
                $args[$n] = $tmp;
            }
        }
        $args[] = &$data;
        call_user_func_array('array_multisort', $args);
        return array_pop($args);
    }

    /*********** Time zone modification ***********/
    
    /*
     * Returns an selection of options for Timezones according to country
     * @param string $country - Country to show Timezones
     */
    public static function timezones($country = 'US'){
        /*foreach($timezone_identifiers as $timezone_identifier) {
           $options .= '<option value="'.$timezone_identifier.'" '. ($timezone_identifier == 'America/Los_Angeles' ? 'selected="selected"' : '') .' >'.str_replace(array('America/', '_'), array('', ' '), $timezone_identifier).'</option>';
        }*/
        switch($country) {
            case 'LIMITED_US':
                return array_reverse(array(
                'America/New_York' => 'Eastern',
                'America/Chicago' => 'Central',
                'America/Denver' => 'Mountain',
                'America/Phoenix' => 'Mountain no DST',
                'America/Los_Angeles' => 'Pacific',
                'America/Anchorage' => 'Alaska',
                'America/Adak' => 'Hawaii',
                'Pacific/Honolulu' => 'Hawaii no DST',
                ));
            break;
            case 'LIMITED_Canada':
                return array_reverse(array(
                'America/St_Johns' => 'Newfoundland',
                'America/Blanc-Sablon' => 'Atlantic',
                'America/New_York' => 'Eastern',
                'America/Chicago' => 'Central',
                'America/Denver' => 'Mountain',
                'America/Phoenix' => 'Mountain no DST',
                'America/Los_Angeles' => 'Pacific'                  
                ));
            break;
            default:
                return DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $country);;
            break;
        }           
    }
    
    public static function timezoneName($php_timezone){
        $timezones = array_merge(helper_functions::timezones('LIMITED_US'),helper_functions::timezones('LIMITED_Canada'));
        if(array_key_exists($php_timezone,$timezones)){
            return $timezones[$php_timezone];
        }
            return str_replace(array('_'), array(' '), $php_timezone);

    }
    public static function pst2timezone($pst_time, $php_timezone, $format = 'M d, g:ia T'){
        $date = new DateTime($pst_time);
        if(empty($php_timezone) OR is_null($php_timezone)){
            $php_timezone = 'America/Los_Angeles';
        }
        $date->setTimeZone(new DateTimeZone($php_timezone));
        return $date->format($format);
    }

    /*
     * Change the timezone of a selected time to PST according to timezone filtered.
     * @param datetime $time - Time to convert
     * @param string $timezone - The Timezone originated
     * @param string $format - Format of the time to return
     * @return datetime
     */
    public static function timezone2pst($time, $timezone, $format = 'H:i:s'){
        // set the timezone according to the filter
        $converted_time = new DateTime($time, new DateTimeZone($timezone));
        // change it now to PST/PDT
        $our_time = $converted_time->setTimezone(new DateTimeZone('America/Los_Angeles'));
        return $our_time->format($format);
    }

    public static function sec2min($seconds){
        $minutes = floor($seconds / 60);
        $seconds = $seconds % 60;
        return $minutes.' min '.$seconds.' sec';
    }

    /**
     * Uploads a file and saves it to the file system.
     * @param  file $image             uploaded file from PHP
     * @param  string $uploadPath        master path to host the file, like uploaded/profilePictures
     * @param  string $upload_identifier minor parth to host the file, like nimdas
     * @param  int $objectId          id of corresponding image, 1
     * @param  string $prefix         prefix may apply differently according to function usage
     * @return string                    final file name for the database
     */
    public static function save_image($image, $uploadPath, $upload_identifier, $objectId, $prefix = 'profilePic_') {
        if (
            ! Upload::valid($image) OR
            ! Upload::not_empty($image) OR
            ! Upload::type($image, array('jpg', 'jpeg', 'png', 'gif')))
        {
            return FALSE;
        }

        $directory = DOCROOT . $uploadPath . $upload_identifier;
        if($prefix != 'profilePic_') $directory = DOCROOT . $uploadPath;
        // Upload::$default_directory = 'uploaded/profilePictures';

        if ($file = Upload::save($image, NULL, $directory))
        {
            // $filename = strtolower(Text::random('alnum', 20)).'.jpg';
            $filename =  $prefix . $objectId . '.jpg';
            $image = Image::factory($file);

            // Check if the image being uploaded is for Psychic or Not
            if($prefix == 'profilePic_'){
                $image->resize(200, 200, Image::AUTO)
                      ->save($directory.$filename);
            }else{
                $image->save($directory.$filename);
                
                // Resize the image if the width is greater than 940px
                list($width, $height, $type, $attr) = getimagesize($directory.$filename);
                if($width > 940){
                    $image->resize(940, NULL, Image::AUTO)
                          ->save($directory.$filename);
                }
            }
            
            // Delete the temporary file
            unlink($file);

            return $upload_identifier.$filename;
        }

        return false;
    }

    /*
     * Returns the Psychic Rate according to tier and customer session
     * @param decimal $rate - Psychic Rate
     * @param int $tier - Customer Tier
     */
    public static function psychicRate($rate, $tier, $free5 = NULL){
        if(!is_null($free5)){
            return '<span class="red">5 Minutes Free</span>';
        }
        if($tier == 9){
            return '<span class="red">$'.number_format($rate, 2).' /min</span>';
        }
        return '<strike>$'.number_format($rate, 2).'</strike> <span class="red">$'.number_format(self::tier2rate($tier, $rate), 2).' /min</span>';
    }

    /**
     * Converts rates based on tiers (experimental, To be removed)
     * @param  [type] $tier [description]
     * @param  [type] $rate [description]
     * @return [type]       [description]
     */
    public static function tier2rate($tier, $rate){
        switch ($tier) {
            case 0:
                return 0.00;
                break;
            case 1: 
                return 1.00;
                break;
            case 2: 
                return 1.50;
                break;
            // normal 
            case 9: 
                return $rate;
                break;
            default:
                throw new Exception("No such rate", 1);
                break;
        }
    }

    /*
     * Returns a more optimized image instead of using the original uploaded image
     * @param int $id - ID of the User Role
     * @param string $role - User Role
     * @param int $width - Width in pixel to produce on crop
     * @param int $height - Height in pixel to produce on crop
     * @return [type] [description]
     */
    public static function profilePicCropper($id, $role, $width, $height){
        $imageFile = DOCROOT.'uploaded/profilePictures/'.$role.'/profilePic_'.$id.'.jpg';
        $uploadPath = DOCROOT.'uploaded/profilePictures/'.$role.'/';
        $fileName = 'profilePic_'.$width.'x'.$height.'_'.$id.'.jpg'; 
        $newImageFile = $uploadPath.$fileName;

        if(file_exists($imageFile)){
            // Crop and Save if cropped image doesn't exist
            if(!file_exists($uploadPath.$fileName)){
                $image = Image::factory($imageFile);

                /* $width, $height, $type, $attr */
                list($w, $h, $t, $a) = getimagesize($imageFile);
                    
                $image->resize($width, $height, Image::INVERSE)
                      ->save($newImageFile);

                // Crop and Save new Image
                $image->crop($width, $height)
                      ->save($newImageFile);
            }

            return '/uploaded/profilePictures/'.$role.'/'.$fileName;
        }else{
            return '/uploaded/profilePictures/picture_thumb.jpg';
        }
    }

    /*
     * Kohana Email Factory - Swiftmailer plugin
     * Sends email based from provided parameters
     * @param string $to - The email of the person to receive it
     * @param string $subject - The subject / title of the email
     * @param string $body - The message/content of the email
     * @param array - Files to be attached
     */
     public static function sendEmail($to, $subject, $body, $attachment = NULL){
        // Get the config'd Email for No Reply
        $config = Kohana::$config->load('config');
        // Prepend subject
        if($config['acronym'] != 'live' and $config['acronym'] != 'staging'){
            $subject = '('.$config['acronym'].') '. $subject;
        }
        
        // $config['acronym'] ='live';
        // if($config['acronym'] != 'live'){
        //    print_r('expression'); die;
        //     $subject = '('.$config['acronym'].') '. $subject;
        // }
           
        // catch all for non-live email receivers.
        if($config['acronym'] != 'live' and $config['acronym'] != 'staging'){
            // let them know that this is catched email 
            $subject = '[ +catchall+ ] '. $subject;
            // prep the receiver
            $to = array();
            foreach ($config['catchall_emails'] as $email) {
                array_push($to, $email);
            }
        } 
        // debug code
        if(ANOOSH_DEBUG){
            $to = 'anoosh@webcook.net';
        }

        $to = 'vaibhav.mangoit@gmail.com';
        $mail = new PHPMailer;
        $mail->isSMTP(); 
        $mail->SMTPDebug = 0; 
        $mail->Host = "smtp.gmail.com"; 
        $mail->Port = 587; 
        $mail->SMTPSecure = 'tls'; 
        $mail->SMTPAuth = true;
        $mail->Username = 'notification@psychicelements.com';
        $mail->Password = 'dpcElements2022!';
        $mail->setFrom('notification@psychicelements.com', 'Psychic Elements Notifications');
        if(!is_null($attachment)){
            if(is_array($attachment)){
                if(count($attachment) > 0){
                    foreach($attachment as $a){
                        $mail->addAttachment($a);
                    }
                }
            }else{
                $mail->addAttachment($attachment);
            }
        }
        $mail->addAddress($to, '');
        $mail->Subject = $subject;
        $mail->msgHTML($body);
        $mail->send();

        // Prep the email 
        // $email = Email::factory();
        // $email->to($to)
        //       ->from($config['notification']['email'], $config['notification']['name'])
        //       ->subject($subject)
        //       ->message($body, 'text/html');
              
              // var_dump($attachment); die;
        //If there is an attachment
        // if(!is_null($attachment)){
        //     if(is_array($attachment)){
        //         if(count($attachment) > 0){
        //             foreach($attachment as $a){
        //                 $email->attach_file($a);
        //             }
        //         }
        //     }else{
        //         $email->attach_file($attachment);
        //     }
        // }
            // $email->send();
    }

    /*
     * Kohana Email Factory - Swiftmailer plugin
     * Sends email based from provided parameters
     * @param string $subject - The subject / title of the email
     * @param string $body - The message/content of the email
     * @param boolean admins_only -- where should the message go?
     */
    public static function emailAdmins($subject, $body, $include_admins = false, $include_anoosh = false, $include_developers = false){
        // Get the config'd Email for Admins
        $config = Kohana::$config->load('config');
        // are we live? 
        if($config['acronym'] != 'live'){
            $subject = '('.$config['acronym'].') '. $subject;
        }

        // load the list
        $email_list = $config['agent_emails'];
        if ($include_admins) { $email_list[] = $config['admin_emails']; }
        if ($include_developers) { $email_list[] = $config['developer_emails']; }

        //flatten array
        $result = array();
        array_walk_recursive($email_list, function($a) use (&$result) { $result[] = $a;  });
        $email_list = $result;

        if(ANOOSH_DEBUG){
            $email_list = array('anoosh@webcook.net');
        }

        if($include_anoosh === true){
            $email_list[] = 'anoosh@webcook.net';
        }

        // Prepare the email
        //$email = Email::factory();
        $mail = new PHPMailer;
        $mail->isSMTP();

        // if this is not live, send to catcher 
        if($config['acronym'] != 'live'){
            // let them know that this is catched email 
            $subject = '[ +catchall+ ] '. $subject;
            // prep the receiver
            foreach ($config['catchall_emails'] as $e) {
                $e = 'vaibhav.mangoit@gmail.com';
                $mail->addAddress($e, '');
            }
        } else {
            // load up addresses 
            foreach ($email_list as $e) {
                $e = 'vaibhav.mangoit@gmail.com';
                $mail->addAddress($e, '');
            }               
        }

  //    // proceed normally.
  //    $email->from($config['error']['email'], $config['error']['name'])
        //       ->subject($subject)
        //       ->message($body, 'text/html'); 
        // // don't fail 
        // $email->send();

        $mail->SMTPDebug = 2; 
        $mail->Host = "smtp.gmail.com"; 
        $mail->Port = 587; 
        $mail->SMTPSecure = 'tls'; 
        $mail->SMTPAuth = true;
        $mail->Username = 'notification@psychicelements.com';
        $mail->Password = 'dpcElements2022!';
        $mail->setFrom('notification@psychicelements.com', 'Psychic Elements Notifications');
       
        $mail->Subject = $subject;
        $mail->msgHTML($body);
        //$mail->send();
    }

    /*
    * Kohana Email Factory - Swiftmailer plugin
    * Sends email based from provided parameters
    * @param string $subject - The subject / title of the email
    * @param string $body - The message/content of the email
    * @param boolean $include_developers -- where should the message go?
    */
    public static function emailOnlyAdmins($subject, $body, $include_developers = false){
        // Get the config'd Email for Admins
        $config = Kohana::$config->load('config');
        // are we live?
        if($config['acronym'] != 'live'){
            $subject = '('.$config['acronym'].') '. $subject;
        }

        // load the list
        $email_list = $config['admin_emails'];
        if ($include_developers) { $email_list[] = $config['developer_emails']; }

        //flatten array
        $result = array();
        array_walk_recursive($email_list, function($a) use (&$result) { $result[] = $a;  });
        $email_list = $result;

        // Prepare the email
       // $email = Email::factory();
        $mail = new PHPMailer;
        $mail->isSMTP();

        // if this is not live, send to catcher
        if($config['acronym'] != 'live'){
            // let them know that this is catched email
            $subject = '[ +catchall+ ] '. $subject;
            // prep the receiver
            foreach ($config['catchall_emails'] as $e) {
                 $e = 'vaibhav.mangoit@gmail.com';
                $mail->addAddress($e, '');
            }
        } else {
            // load up addresses
            foreach ($email_list as $e) {
                $e = 'vaibhav.mangoit@gmail.com';
                $mail->addAddress($e, '');
            }
        }

        // proceed normally.
        $mail->setFrom('notification@psychicelements.com', 'Psychic Elements Notifications');
       
        $mail->Subject = $subject;
        $mail->msgHTML($body);
        $mail->send();
    }


    /**
     * Return the designated color for a status
     */
    public static function getStatusColor($status)
    {

        $statusColors = array(
            'grey', 'green', 'red', 'blue', 'red'
        );

        return $statusColors[$status];
    }

    /**
     * Sends SMS using plivo account to people on this platform
     * @param  [type]  $body        [description]
     * @param  boolean $admins_only [description]
     * @return [type]               [description]
     */
    public static function smsAdmins($title = null, $body, $admins_only = false){
        $config = Kohana::$config->load('config');
        // are we live? 

        if($config['acronym'] != 'live' AND $config['acronym'] != 'staging'){
            // just don't send anything if we aren't
            return false;
        }
        
        // initialize plivo account 
        require_once Kohana::find_file('plivo', 'plivo');
        // start plivo client 
        
        $plivo_client = new plivo\RestAPI(PLIVO_AUTH_ID, PLIVO_AUTH_TOKEN);


        // start sms sending, send to all the team. Ronnie: 13107093020
        $to = '18189415577';
        // $to = '919691139359';
        
        // send to anoosh if on debug only

    /*
        if(ANOOSH_DEBUG){
            $to = '13107339236';
        }
    */  

        // this is our plivo number
        $from = '18189217320';
        // Send a message
        $params = array(
            'src' => "$from",
            'dst' => "$to",
            'text' => $body . " Don't reply to this message.",
            'type' => 'sms',
            );
        // send it 
        $response = $plivo_client->send_message($params);

        // Also send a notification on nimda
        $title = is_null($title) ? '' : $title;
        @helper_functions::add_notify($title, $body, 'success');

        // bye
        return false;
    }

    /**
     * Loads all the enums into a nice array
     * @return [type] [description]
     */
    public static function getAllEnums(){
        // lazy load models
        $abilities_model = new model_enums_abilities();
        $subjects_model = new model_enums_subjects();
        $tools_model = new model_enums_tools();
        $readingstyles_model = new model_enums_readingstyles();

        // query the database and put them back into the thing
        $abs = $abilities_model->all()->as_array('abilityId', 'name');
        $sus = $subjects_model->all()->as_array('subjectId', 'name');
        $tos = $tools_model->all()->as_array('toolId', 'name');
        $res = $readingstyles_model->all()->as_array('readingStyleId', 'name');
        // done.
        return array($abs, $sus, $tos, $res);
    }

    /*
     * Returns the string name of the enum
     * @param $id - ID of the Enum
     * @param $enum - string name of the enum
     * @return [type] [description]
     */
    public static function getEnumNamebyId($id, $enum){
        $abilities_model = new model_enums_abilities();
        $subjects_model = new model_enums_subjects();
        $tools_model = new model_enums_tools();

        switch($enum){
            case 'abilities':
                $result = $abilities_model->read($id);
                break;
            case 'subjects':
                $result = $subjects_model->read($id);
                break;
            default: // Tools
                $result = $tools_model->read($id);
        }

        if(count($result) > 0) return $result['name'];

        return null;
    }

    /*
         * Returns name Days of the week
     */
    public static function getAllDays(){
        return array('Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun');
    }

    /**
     * Temporary All Status of Availability
     * @return [type] [description]
     */
    public static function getAllStatus(){
        return array(
                0 => array(
                    'name' => 'Request Me',
                    'className' => 'offline'
                    ),
                1 => array(
                        'name' => 'Available',
                        'className' => 'available'
                    ),
                // This is used solely for the sorting issue
                11 => array(
                        'name' => 'Available',
                        'className' => 'available'
                    ),
                2 => array(
                        'name' => 'On Break', 
                        'className' => 'away'
                    ),
                3 => array(
                        'name' => 'On Call',
                        'className' => 'oncall'
                    ),
            );
    }

    /*
     * Returns the element according to the Key Status
     * @param int $status - the temporary key of 1-3 for status
     * @param string $key - the index of the element based on the $status
     */
    public static function getStatus($status, $key){
        $stat = self::getAllStatus();
        if(!isset($stat[$status][$key])){
            return NULL;    
        }
        return $stat[$status][$key];
    }

    /*
     * Returns a Nimda's Vocetis Availability on human readable status
     */
    public static function getVocetisStatus($status){
        $availability = array(
            0 => 'Offline',
            1 => 'Online',
            2 => 'Busy'
        );
        return $availability[$status];
    }

    /**
     * Checks for a file having a name and return the filename, else the placeholder image is returned
     * @param  string $filename the filename (can be empty)
     * @return string           the file path.
     */
    public static function getProfilePicture($filename){
        return (empty($filename))?'/uploaded/profilePictures/picture_thumb.jpg':'/uploaded/profilePictures/'.$filename;
    }

    /**
     * Checks for a file having a name and return the filename, else the placeholder image is returned
     * @param  string $filename the filename (can be empty)
     * @return string           the file path.
     */
    public static function getImageBanner($filename){
        return !empty($filename) ? '/uploaded/banners/'.$filename : '';
    }

    /**
     * Converts an array of ENUM values to their respective string representations and formats them.
     * @param  arary $selectedItems enum values
     * @param  string $type          type of enum
     * @return string                formatted string of enum text.
     */
    public static function convertEnum($selectedItems, $type, $as_array = false){
        if(empty($selectedItems)){
            return ' -'; 
        }
        // proceed.
        list($abs, $sus, $tos) = self::getAllEnums();
        // grep the relevant objects
        switch ($type) {
            case 'abilities':
                $filtered = array_intersect_key($abs, array_flip($selectedItems));
                break;
            case 'subjects':
                $filtered = array_intersect_key($sus, array_flip($selectedItems));
                break;
            case 'tools':
                $filtered = array_intersect_key($tos, array_flip($selectedItems));
                break;              
        }
        // comma in between and go
        if($as_array){
            return array_values($filtered);
        } else {
            return implode(', ', array_values($filtered));  
        }
    }

    /*
     * Returns an array of merged Psychic Enums, only limits 3 items
     */
    public static function mergedEnums($psychic){
        $enums = array();
        if(!empty($psychic['subjects'])){
            $subjects = self::convertEnum($psychic['subjects'], 'subjects', true);
            $enums[] = $subjects[0];
        }
        if(!empty($psychic['tools'])){
            $tools = self::convertEnum($psychic['tools'], 'tools', true);
            $enums[] = $tools[0];
        }
        if(!empty($psychic['abilities'])){
            $abilities = self::convertEnum($psychic['abilities'], 'abilities', true);
            $enums[] = $abilities[0];
        }
        
        return $enums;
    }

    /**
     * Converts an emitted error code to user readable text
     * @param  [type] $err_code [description]
     * @return [type]           [description]
     */
    public static function convert_error_code($err_code){
        // load the error database 
        $error_db = array(
                # Model: PaymentMethods 
                'PE_PM_UNSUPPORTED_CC' => 'This Credit Card is not supported.',
                'PE_PM_CC_EXISTS' => 'Credit Card exists in our system.',
                'PE_PM_ANET_FAILED_CC' => 'Gateway rejected the Credit Card.',
                'PE_PM_ANET_FAILED_SH' => 'Gateway rejected this billing address.',
                'PE_PM_GATEWAY_DISABLED' => 'Gateway is disabled.',
                'PE_PM_DB_FAILED' => 'Database failed card registration.',
                'PE_PM_CC_EXISTS_SELF' => 'Credit Card in use by this customer. Try to update the card.',
                'PE_PM_CC_EXISTS_OTHERS' => 'Credit Card in use by other customer, flag this account.',
            );
        if(isset($error_db[$err_code])){
            return $error_db[$err_code];
        } else {
            throw new Exception("No such error code.", 1);
        }
    }

    /*
     * Returns an array index according to card type, can be an image or text
     */
    public static function cardType($cardType, $index = 'desc'){
        $data = array();
        switch ($cardType) {
            case 'visa':
                $data['desc'] = 'Visa';
                $data['card_pic'] = URL::base().'img/myaccount/visa.jpg';
                break;
            case 'master':
                $data['desc'] = 'Master';
                $data['card_pic'] = URL::base().'img/myaccount/mastercard.jpg';
                break;
            case 'disc':
                $data['desc'] = 'Discover';
                $data['card_pic'] = URL::base().'img/myaccount/discover.jpg';
                break;
            case 'amex':
                $data['desc'] = 'AMEX';
                $data['card_pic'] = URL::base().'img/myaccount/amex.jpg';
                break;
            default:
                $data['desc'] = 'Paypal';
                $data['card_pic'] = URL::base().'img/myaccount/pp.jpg';
        }
        return $data[$index];
    }

    /**
     * Checks for the lock file, determines if we are on the night mode
     * @return boolean [description]
     */
    public static function is_nightmode(){
        return file_exists(DOCROOT.'/uploaded/nightmode_active.lock');
    }

    /**
     * Checks against the DB for unique id, will return false if it's a duplicate submission
     * @return boolean [description]
     */
    public static function is_unique_purchase($uniquePurchaseId){
        $number = DB::select(array(DB::expr('COUNT(*)'), 'unique_ids'))->from('purchaseLogs')->where('landing_url','=',$uniquePurchaseId)->execute()->current();
        $number = $number['unique_ids'];
        return ($number < 1) ? true : false;
    }

    /**
     * Extension to PHP to correctly break the MySQL returned GROUP_CONTAC statements
     * @param  string $delimeter delimiter, such as ,
     * @param  string $input     input, such as 1,2,3
     * @return mixed            REAL empty array on fail, legal legit array on success
     */
    public static function mysql_explode($delimeter, $input){
        $ret = explode($delimeter, $input);
        // sanity check 
        if(empty($ret) OR empty($ret[0])){
            return array();
        }
        return $ret;
    }

    public static function jsRedirect($url){
        $script = '
        <script>
          setTimeout(function() {
            window.location.href =\''.URL::site($url).'\';
          },2000);
        </script>
        ';
        return $script;
    }

    /**
     * @brief Fancy prints a multidimentional array (hash) to HTML output. You need to echo out the results. [Anoosh <3]
     */
    public static function prettyprint($arr) {
        $retStr = '<ul>';
        if (is_array($arr)){
          foreach ($arr as $key=>$val){
            if (is_array($val)){
              $retStr .= '<li>' . $key . ' => ' . self::prettyprint($val) . '</li>';
            }else{
              $retStr .= '<li>' . $key . ' => ' . $val . '</li>';
            }
          }
        }
        $retStr .= '</ul>';
        return $retStr;
    }

    // Aborts the code execution in extereme circumstances
    public static function abort($msg = NULL){
        echo '</br></br><span style="color: red;">We have encountered an error. Please contact our customer care. ERR_CODE: ABR08</span></br></br>';
        echo $msg; 
        die();
    }


    public static function ajax_reply($success = false, $message = 'incorrect call', $error = 'error message', $redirectLink = NULL, $details = NULL){
        return json_encode(array('success' => $success, 'message' => $message, 'error' => $error, 'redirectLink' => $redirectLink, 'details' => $details));
    }

    public static function zodiac_sign($date = "") {
        $zodiac[356] = "Capricorn";
        $zodiac[326] = "Sagittarius";
        $zodiac[296] = "Scorpio";
        $zodiac[266] = "Libra";
        $zodiac[235] = "Virgo";
        $zodiac[203] = "Leo";
        $zodiac[172] = "Cancer";
        $zodiac[140] = "Gemini";
        $zodiac[111] = "Taurus";
        $zodiac[78]  = "Aries";
        $zodiac[51]  = "Pisces";
        $zodiac[20]  = "Aquarius";
        $zodiac[0]   = "Capricorn";
        if (!$date) $date = time();
        $dayOfTheYear = date("z",$date);
        $isLeapYear = date("L",$date);
        if ($isLeapYear && ($dayOfTheYear > 59)) $dayOfTheYear = $dayOfTheYear - 1;
        foreach($zodiac as $day => $sign) if ($dayOfTheYear > $day) break;
        return $sign;
    }


    /*
     * Returns the Client IP
     */
    public static function getIP(){
        $ipAddress = '';
        if (getenv('HTTP_CLIENT_IP')) {

            $ipAddress = getenv('HTTP_CLIENT_IP');

        }else if(getenv('HTTP_X_FORWARDED_FOR')){

            $ipAddress = getenv('HTTP_X_FORWARDED_FOR');

        }else if(getenv('HTTP_X_FORWARDED')){

            $ipAddress = getenv('HTTP_X_FORWARDED');

        }else if(getenv('HTTP_FORWARDED_FOR')){

            $ipAddress = getenv('HTTP_FORWARDED_FOR');

        }else if(getenv('HTTP_FORWARDED')){

           $ipAddress = getenv('HTTP_FORWARDED');

        }else{

            $ipAddress = getenv('REMOTE_ADDR');
        }

        return $ipAddress;
    }

    /**
     * Creates a pin from birthdate universally 
     * @param  string $birthdate MySQL style, 1930-10-01
     * @return string            1001
     */
    public static function birthdate2pin($birthdate){
        // Get the values 
        list($yyyy, $mm, $dd) = explode('-', $birthdate);
        return $mm . $dd;
    }

    /**
     * Check if string is json 
     * @param  [type]  $string [description]
     * @return boolean         [description]
     */
    public static function isJson($string) {
        json_decode($string);
        return (json_last_error() == JSON_ERROR_NONE);
    }

    /*
     * Returns a cleaned up phone number
     * @param string $phone - landline, cellphone number
     */
    public static function phoneCleanUp($phone){
        return preg_replace('/[^0-9]/', '', $phone);
    }

    /* Cleanup - Whitespaces, spaces */
    public static function cleanUp($str){
        return preg_replace('/\s+/', '', $str);
    }

    public static function formatPhone($phone){
        $numbers_only = preg_replace("/[^\d]/", "", $phone);
        return preg_replace("/^1?(\d{3})(\d{3})(\d{4})$/", "($1) $2-$3", $numbers_only);
    }

    /*
     * Returns the Card Type
     * @param int $ccNumber - Credit Card Number
     * @return string
     */
    public static function creditCardType($creditCardNumber){
        $type = 'visa';
        if (preg_match('/^5[1-5][0-9]{5,}$/', $creditCardNumber)) {
            //MasterCard
            $type = 'master';
        } else if (preg_match('/^3[47][0-9]{5,}$/', $creditCardNumber)) {
            // AMEX
            $type = 'amex';
        }
        return $type;
    }

    public static function creditCartTypeByCode($code){

        switch (strtoupper($record['type'])) {
        case 'VISA':
            $card_type = 'Visa Card';
            break;
        case 'MASTER':
            $card_type = 'MasterCard';
            break;
        case 'AMEX':
            $card_type = 'American Express';
            break;
        case 'DINERS':
            $card_type = 'Diners Card';
            break;
        case 'DISC':
            $card_type = 'Discovery Card';
            break;
        case 'JCB':
            $card_type = 'JCB Card';
            break;
        default:
            throw new Exception("No such card!", 1);
            break;
        }
        return $card_type;
    }

    public static function convertCreatedBy($me, $legend = false){

        $lookup = array(
            // System tools 
            -3 => 'Perl script, defunct',
            -2 => 'Perl script prebill correction, defunct',
            -1 => 'Tiered Payment System',
            0 => 'Self (customer)'
        );

        $nimda = ($legend && $me > 0) ? ' (nimda)': '';

        if (!isset($lookup[$me])) {

            $sql = 'SELECT firstName FROM nimdas n WHERE nimdaId = :nimdaId';
            $results = DB::query(Database::SELECT, $sql)
                ->bind(':nimdaId', $me)->execute(Database::instance())->current();

            if (isset($results['firstName'])) {
                return $results['firstName'] . $nimda;
            }

            return 'Unknown';

        } else {
            return $lookup[$me] . $nimda;
        }
    }

    public static function metaTags() {
        return array(
            '/' => array(
              'title' => 'Simply the best online psychic readings available anywhere - Psychic Elements',
              'metaDescription' => 'At Psychic Elements we offer authentic psychic reading. Our psychics are carefully evaluated and selected to help you with the best information to enhance your life. Try our introductory offer for only $1/min.'
            ),
            '/customers/signup' => array(
              'title' => 'Sign Up - Psychic Elements',
              'metaDescription' => ''
            ),
            '/psychics' => array(
              'title' => 'Our Psychics - Psychic Elements',
              'metaDescription' => 'Select a qualified psychic for your best psychic reading.'
            ),
            '/psychics/index/love-relationships' => array(
              'title' => 'Psychic Readings - Love and Relationship Psychics - Psychic Elements',
              'metaDescription' => 'Our psychics can assist you with your love & relationship questions. Enjoy our introductory offer today.'
            ),
            '/psychics/index/life-questions' => array(
              'title' => 'Psychic Readings - Psychics for Life Questions - Psychic Elements',
              'metaDescription' => 'Our psychics can assist you with your life questions. Enjoy our introductory offer today.'
            ),
            '/psychics/index/tarot-readers' => array(
              'title' => 'Psychic Readings - Tarot Readers - Psychic Elements',
              'metaDescription' => 'Our tarot readers can assist you with your love & relationship questions. Enjoy our introductory offer today.'
            ),
            '/psychics/index/friends-family' => array(
              'title' => 'Psychic Readings - Friends and Family Psychics - Psychic Elements',
              'metaDescription' => 'Our psychics can assist you with your friends & family questions. Enjoy our introductory offer today.'
            ),
            '/psychics/index/psychic-mediums' => array(
              'title' => 'Psychic Readings - Psychic Mediums - Psychic Elements',
              'metaDescription' => 'Our psychic mediums can assist you with your love & relationship questions. Enjoy our introductory offer today.'
            ),
            '/howitworks' => array(
              'title' => 'How Psychic Reading Works! Psychic Elements',
              'metaDescription' => ''
            ),
            '/horoscope' => array(
              'title' => 'Free Horoscope - Psychic Elements',
              'metaDescription' => 'Enjoy our free daily, weekly, & monthly Horoscope & love Horoscope.'
            ),
            '/learn' => array(
              'title' => 'About Psychic Readings - Psychic Elements',
              'metaDescription' => ''
            ),              
            '/about/privacy_policy' => array(
              'title' => 'Privacy Policy - Psychic Elements',
              'metaDescription' => ''
            ),
            '/about/contact_us' => array(
              'title' => 'Contact Us - Psychic Elements',
              'metaDescription' => ''
            ),
            '/about/satisfaction_guaranteed' => array(
              'title' => 'Satisfaction Guaranteed - Psychic Elements',
              'metaDescription' => ''
            ),
            '/about/terms_conditions' => array(
              'title' => 'Terms & Conditions - Psychic Elements',
              'metaDescription' => 'Psychic Elements\' terms and conditions'
            ),
        );
    }

    public static function isTopPsychic($psychicId = null) {

        $sql = 'SELECT psychicId FROM 
            (SELECT p.psychicId, (((IF(p.internalScore = 0, 1, p.internalScore) * 10) + SUM(rating)) 
            + (10 + COUNT(*))) rating FROM testimonials INNER JOIN psychics p 
            ON p.psychicId = testimonials.psychicId
            GROUP BY psychicId ORDER BY rating DESC LIMIT 1) topPsychic 
            WHERE psychicId =:psychicId';

        $results = DB::query(Database::SELECT, $sql)
            ->bind(':psychicId', $psychicId)
            ->execute(Database::instance())
            ->current();

        if (!is_null($results['psychicId'])) 
        {
            return '<img src="' . URL::base() . 'img/top-psychic.png" alt="Top Psychic" title="Top Psychic" />';
        }

        return null;
            
    }

    /* Returns the emblem / ribbon "Staff Pick" on a infobox
     * @param int $staffPick - staffPick of a Psychic
     */
    public static function isFeatured($featured = 0, $star = false){
        if($featured != 0){
            if($star){
                return '<div class="star_emblem"> Featured Psychic</div>';
            }
            return '<div class="emblem featured"></div>';
        }
        return null;
    }

    /* Returns the emblem / ribbon "Staff Pick" on a infobox
     * @param int $staffPick - staffPick of a Psychic
     */
    public static function isStaffPick($staffPick = 0, $star = false){
        if($staffPick != 0){
            if($star){
                return '<div class="star_emblem"> Staff Pick</div>';
            }
            return '<div class="emblem staff_pick"></div>';
        }
        return null;
    }

    /*
     * Subscribe a customer to a mailing list
     * @param string $email - Subscriber's email
     * @param string $listId - Mailing list ID on Mailchimp
     * @param array $opts - The variables to merge with the subscriber
     */
    public static function subscribeToMailchimp($email = NULL, $listId = NULL, $vars = array()){
        if(is_null($email) OR is_null($listId)){
            return NULL;
        }
        $mc_api_key = defined('MC_API_KEY') ? MC_API_KEY : '';
        $mc_instance = new Mailchimp_Core();
        $mc_instance->MCAPI($mc_api_key);
        // subscribe to the list provided
        $mc_instance->listSubscribe($listId, $email, $vars, 'html', false, true);
    }

    /*
     * Update subscriber to a mailing list or else, subscribe if the update is false
     * @param string $email - Subscriber's email
     * @param string $listId - Mailing list ID on Mailchimp
     * @param array $opts - The variables to merge with the subscriber
     */
    public static function updateSubscriberOnMailchimp($email = NULL, $listId = NULL, $vars = array()){
        if(is_null($email) OR is_null($listId)){
            return NULL;
        }
        $mc_api_key = defined('MC_API_KEY') ? MC_API_KEY : '';
        $mc_instance = new Mailchimp_Core();
        $mc_instance->MCAPI($mc_api_key);
        // subscribe to the list provided
        $success = $mc_instance->listUpdateMember($listId, $email, $vars, 'html', true);
        // the subscriber might not yet be on the list
        if(!$success){
            self::subscribeToMailchimp($listId, $email, $vars);
        }
    }

    /*
     * Unsubscribe a customer to a mailing list
     * @param string $email - Subscriber's email
     * @param string $listId - Mailing list ID on Mailchimp
     */
    public static function unsubscribeOnMailchimp($email = NULL, $listId = NULL){
        if(is_null($email) OR is_null($listId)){
            return NULL;
        }
        $mc_api_key = defined('MC_API_KEY') ? MC_API_KEY : '';
        $mc_instance = new Mailchimp_Core();
        $mc_instance->MCAPI($mc_api_key);
        // unsubscribe to the list provided
        $mc_instance->listUnsubscribe($listId, $email);
    }

    /**
     * Sends the horoscope Newsletter
     * @param $sign - zodiac sign (group) to send to
     * @param $content - content of newsletter
     * @param $template - name of mailchimp template 
     * @param $directory - name of mailchimp directory 
     *
     */
    public static function mcSend($list_id, $sign, $content, $template_name, $directory, $lc = false) {

        $config = Kohana::$config->load('config');

        //$mc_api_key = defined('MC_API_KEY') ? MC_API_KEY : "";
        $mc_api_key = '73f63ded0a6a05984ad01b58cbebddea-us7';
        $mc_list_id = !empty($list_id) ? $list_id : ""; // defined('MC_LIST_NAME') ? MC_LIST_NAME : "";

        // prepare the core
        $mc_instance = new MailChimp($mc_api_key);

        // get template
        $templates = $mc_instance->get('templates', ['count' => 500]); // Get the available email templates
        // Loop through the templates until template_name is found
        $template = null;
        $template_key = array_search($template_name, array_column($templates['templates'], 'name'));
        if($template_key !== false){
            $template = $templates['templates'][$template_key];
        }

        if (is_null($template)) {
            echo $template_name; 
            return false;
        }

        // get folder to put it
        $folders = $mc_instance->get('campaign-folders', ['count' => 100]);
        $folder = null;
        $folder_key = array_search($directory, array_column($folders['folders'], 'name'));
        if($folder_key !== false){
            $folder = $folders['folders'][$folder_key];
        }

        if (is_null($folder)) {
            echo $directory;
            return false;   
        }

        // type regular
        $type = 'regular';

        // Assign the options for the campaign
        // $opts['list_id'] = $mc_list_id;
        $opts['subject_line'] = $content['html_sign'] . ' Horoscope for ' . $content['html_day'] . ', ' . $content['html_date'];
        $opts['reply_to'] = $content['from_email']; // 'horoscope@psychicelements.com'; 
        $opts['from_name'] = $content['from_name']; // 'Psychic Elements Horoscope Newsletter';
        $opts['template_id'] = $template['id'];
        $opts['folder_id'] = $folder['id'];
        // $opts['tracking'] = array('opens' => true, 'html_clicks' => true, 'text_clicks' => false);                 
        $opts['authenticate'] = true;
        // $opts['analytics'] = array('google'=>'my_google_analytics_key');
        $opts['title'] = $content['html_sign'] . ' Horoscope for ' . $content['html_day'] . ', ' . $content['html_date'];
        // others
        $content['sign'] = $content['html_sign'];
        // lc template
        if($lc){
            $content['sign2'] = $content['html_sign'];
            $content['sign_date'] = $content['html_sign_date'];
            $content['weeklymonthlylink'] = $content['html_weeklymonthlylink'];
        }
        $content['day'] = $content['html_day'];
        $content['date'] = $content['html_date'];
        $content['sign_symbol'] = $content['html_sign_symbol'];
        $content['description'] = $content['html_description'];
        // banner
        $content['html_banner'] = '<img align="center" alt="" src="https://gallery.mailchimp.com/90001a922172bab68d240d866/images/dc91a65b-39ab-484c-994c-af3bedc8724d.jpg" width="600" style="max-width:640px; padding-bottom: 0; display: inline !important; vertical-align: bottom;" class="mcnImage">';

        // Place the content
        $_content = $content;
        // zodiac
        $zodiac = trim(str_replace(' ', '', (($lc) ? $sign : strtolower($sign))));

        // Set the group to send to
        if($lc){
            if(in_array(strtolower($sign), ['leo', 'aquarius'])){
                $segmentId = NULL;
                // get all segments
                $segments = $mc_instance->get('lists/'.$list_id.'/segments');
                // validate
                if(count($segments['segments']) > 0){
                    // loop through the segments
                    foreach($segments['segments'] as $segment){
                        if($segment['name'] == $sign.' - Daily Horoscope'){
                            // apply id
                            $segmentId = $segment['id'];
                            break;
                        }
                    }
                }
                // validate segment id
                $segment_opts = [];
                if(!is_null($segmentId)){
                    $segment_opts = [
                        'saved_segment_id' => $segmentId,
                    ];
                }
            }else{
                $segment_opts = [
                    'match' => 'all',
                    'conditions' => [
                        // zodiac
                        [
                            'condition_type' => 'SelectMerge',
                            'op' => 'is',
                            'field' => 'ZODIAC',
                            'value' => $zodiac
                        ],
                        // horoscope frequency
                        [
                            'condition_type' => 'SelectMerge',
                            'op' => 'is',
                            'field' => 'HFREQ',
                            'value' => 'Daily'
                        ]
                    ]
                ];
            }
        }else{
            $segment_opts = [
                'match' => 'all',
                'conditions' => [
                    // zodiac
                    [
                        'condition_type' => 'TextMerge',
                        'op' => 'is',
                        'field' => 'ZODIAC',
                        'value' => $zodiac
                    ],
                    // horoscope frequency
                    [
                        'condition_type' => 'SelectMerge',
                        'op' => 'is',
                        'field' => 'HFREQ',
                        'value' => 'Daily'
                    ]
                ]
            ];
        }

        // Create the campaign
        $errorCampaign = 0;
        // $campaignId = $mc_instance->campaignCreate($type, $opts, $_content, $segment_opts);
        $request_body = [
            'type' => $type,
            'recipients' => [
                'list_id' => $list_id,
                'segment_opts' => $segment_opts
            ],
            'settings' => $opts,
            'tracking' => [
                'opens' => true,
                'html_clicks' => true,
                'text_clicks' => false
            ]
        ];
        // prepare campaign creation
        $campaign = $mc_instance->post('campaigns', $request_body);
        // validate
        if(isset($campaign['id'])){
            // echo "Campaign Created: $sign\n";
            // prepare contents
            $put_contents = [
                'template' => [
                    'id' => $template['id'],
                    'sections' => $_content
                ]
            ];
            // put contents
            $patch_content = $mc_instance->put('campaigns/'.$campaign['id'].'/content', $put_contents);
            // validate
            if(isset($patch_content['plain_text'])){
                $mc_instance->post('campaigns/'.$campaign['id'].'/actions/send');
                echo "Campaign Created and Set to Send: $sign\n";
            }else{
                $errorCampaign++;
            }
        }else{
            $errorCampaign++;
        }

        // check any error
        if($errorCampaign > 0){
            echo "Unable to Create New Campaign: $sign";
            echo "\n\tCode=".$mc_instance->errorCode;
            echo "\n\tMsg=".$mc_instance->errorMessage."\n";

            Log::instance()->add(Log::NOTICE, "Unable to create new campaign \t
                            Code=".$mc_instance->errorCode."\n\tMsg=".$mc_instance->errorMessage."\n");
        }
    }

    /**
     * Sends the horoscope Newsletter
     * @param $sign - zodiac sign (group) to send to
     * @param $content - content of newsletter
     * @param $template - name of mailchimp template 
     * @param $directory - name of mailchimp directory 
     *
     */
    public static function mailchimpSend($list_id, $sign, $content, $template_name, $directory, $ec_nc = false) {

        $config = Kohana::$config->load('config');

        $mc_api_key = defined('MC_API_KEY') ? MC_API_KEY : "";
        $mc_list_id = !empty($list_id) ? $list_id : ""; // defined('MC_LIST_NAME') ? MC_LIST_NAME : "";

        // prepare the core
        $mc_instance = new MailChimp($mc_api_key);

        // if ec and nc
        if($ec_nc){ // identify if this is PE list group for EC or NC
            // define here statically the EC / NC customers
            $ecnc = ['Existing', 'Non-existing'];
            foreach($ecnc as $en){
                // get groups
                $groups = $mc_instance->get('lists/'.$list_id.'/interest-categories', ['count' => 50]);
                $customers_group = []; // will contain the array group value of the EC/NC data
                foreach ($groups['categories'] as $g) {
                    // Horoscope
                    if (strtolower($g['title']) == 'zodiac sign' || strtolower($g['title']) == 'horoscopes') {
                        $groups = $g;
                    }
                    // Customers
                    if (strtolower($g['title']) == 'customers') {
                        $customers_group = $g;
                    }
                }

                // Horoscope Group - Interests
                $sign_group_ids = [];
                $sign_interests = $mc_instance->get('lists/'.$list_id.'/interest-categories/'.$groups['id'].'/interests', ['count' => 50]);
                if(isset($sign_interests['interests']) AND count($sign_interests['interests']) > 0){
                    foreach($sign_interests['interests'] as $interest){
                        if(strtolower($interest['name']) == strtolower($sign)){
                            $sign_group_ids[] = $interest['id'];
                            break;
                        }
                    }
                }

                // Customer Group - Interests
                $customer_group_ids = [];
                $customer_interests = $mc_instance->get('lists/'.$list_id.'/interest-categories/'.$customers_group['id'].'/interests', ['count' => 50]);
                if(isset($customer_interests['interests']) AND count($customer_interests['interests']) > 0){
                    foreach($customer_interests['interests'] as $interest){
                        if(strtolower($interest['name']) == strtolower($en)){
                            $customer_group_ids[] = $interest['id'];
                            break;
                        }
                    }
                }

                // Sanity checks
                if (is_null($groups)) return false; // Sanity check
                if (is_null($customers_group)) return false; // Sanity check

                $templates = $mc_instance->get('templates', ['count' => 500]); // Get the available email templates
                // Loop through the templates until template_name is found
                $template = null;
                $template_key = array_search($template_name, array_column($templates['templates'], 'name'));
                if($template_key !== false){
                    $template = $templates['templates'][$template_key];
                }

                if (is_null($template)) {
                    echo $template; 
                    return false;
                }

                $folders = $mc_instance->get('campaign-folders', ['count' => 100]);
                $folder = null;
                $folder_key = array_search($directory, array_column($folders['folders'], 'name'));
                if($folder_key !== false){
                    $folder = $folders['folders'][$folder_key];
                }

                if (is_null($folder)) {
                    echo $folder;
                    return false;   
                }

                $type = 'regular';

                // Assign the options for the campaign
                // $opts['list_id'] = $mc_list_id;
                $opts['subject_line'] = $content['html_sign'] . ' Horoscope for ' . $content['html_day'] . ', ' . $content['html_date'];
                $opts['reply_to'] = $content['from_email']; // 'horoscope@psychicelements.com'; 
                $opts['from_name'] = $content['from_name']; // 'Psychic Elements Horoscope Newsletter';
                $opts['template_id'] = $template['id'];
                $opts['folder_id'] = $folder['id'];
                // $opts['tracking'] = array('opens' => true, 'html_clicks' => true, 'text_clicks' => false);                 
                $opts['authenticate'] = true;
                // $opts['analytics'] = array('google'=>'my_google_analytics_key');
                $opts['title'] = $content['html_sign'] . ' Horoscope for ' . $content['html_day'] . ', ' . $content['html_date'].' ('.$en.' customers)';
                // others
                $content['sign'] = $content['html_sign'];
                $content['day'] = $content['html_day'];
                $content['date'] = $content['html_date'];
                $content['sign_symbol'] = $content['html_sign_symbol'];
                $content['description'] = $content['html_description'];
                
                // check the header banner to use
                $content['html_banner'] = ($en == 'Existing') ? '<img align="center" alt="" src="https://gallery.mailchimp.com/90001a922172bab68d240d866/images/dc91a65b-39ab-484c-994c-af3bedc8724d.jpg" width="600" style="max-width:640px; padding-bottom: 0; display: inline !important; vertical-align: bottom;" class="mcnImage">' : '<img align="center" alt="" src="https://gallery.mailchimp.com/90001a922172bab68d240d866/images/eeee378e-ba09-4bbd-80d8-3640d5469278.jpg" width="600" style="max-width:640px; padding-bottom: 0; display: inline !important; vertical-align: bottom;" class="mcnImage">';

                // Place the content
                $_content = $content;

                // Set the group to send to
                $segment_opts = [
                    'match' => 'all',
                    'conditions' => [
                        // dropdown
                        [
                            'condition_type' => 'Interests',
                            'op' => 'interestcontains',
                            'field' => 'interests-'.$groups['id'],
                            'value' => $sign_group_ids
                        ],
                        // checkboxes
                        [
                            'condition_type' => 'Interests',
                            'op' => 'interestcontains',
                            'field' => 'interests-'.$customers_group['id'],
                            'value' => $customer_group_ids
                        ]
                    ]
                ];

                // Create the campaign
                $errorCampaign = 0;
                // $campaignId = $mc_instance->campaignCreate($type, $opts, $_content, $segment_opts);
                $request_body = [
                    'type' => $type,
                    'recipients' => [
                        'list_id' => $list_id,
                        'segment_opts' => $segment_opts
                    ],
                    'settings' => $opts,
                    'tracking' => [
                        'opens' => true,
                        'html_clicks' => true,
                        'text_clicks' => false
                    ]
                ];
                // prepare campaign creation
                $campaign = $mc_instance->post('campaigns', $request_body);
                // validate
                if(isset($campaign['id'])){
                    // prepare contents
                    $put_contents = [
                        'template' => [
                            'id' => $template['id'],
                            'sections' => $_content
                        ]
                    ];
                    // put contents
                    $patch_content = $mc_instance->put('campaigns/'.$campaign['id'].'/content', $put_contents);
                    // validate
                    if(isset($patch_content['plain_text'])){
                        $mc_instance->post('campaigns/'.$campaign['id'].'/actions/send');
                        echo 'sending';
                    }else{
                        $errorCampaign++;
                    }
                }else{
                    $errorCampaign++;
                }

                // check any error
                if($errorCampaign > 0){
                    echo "Unable to Create New Campaign!";
                    echo "\n\tCode=".$mc_instance->errorCode;
                    echo "\n\tMsg=".$mc_instance->errorMessage."\n";

                    Log::instance()->add(Log::NOTICE, "Unable to create new campaign \t
                                    Code=".$mc_instance->errorCode."\n\tMsg=".$mc_instance->errorMessage."\n");
                }
            }
        }else{
            $groups = $mc_instance->listInterestGroupings($mc_list_id); // Get the 'Horoscope List' list
            foreach ($groups as $g) {
                // Horoscope
                if (strtolower($g['name']) == 'zodiac sign' || strtolower($g['name']) == 'horoscopes') {
                    $groups = $g;
                    break;
                }
            }

            if (is_null($groups)) {
                echo $groups;
                return false;
            }

            $templates = $mc_instance->templates(); // Get the available email templates

            // Loop through the templates until template_name is found
            $template = null;
            foreach ($templates['user'] as $t) {
                if (strtolower($t['name']) == strtolower($template_name)) {
                    $template = $t;
                    break;
                }
            }

            if (is_null($template)) {
                echo $template; 
                return false;
            }

            $folders = $mc_instance->folders();
            $folder = null;
            foreach ($folders as $f) {
                if (strtolower($f['name']) == strtolower($directory)) {
                    $folder = $f;
                    break; 
                }
            }

            if (is_null($folder)) {
                echo $folder;
                return false;   
            }

            $type = 'regular';

            // Assign the options for the campaign
            $opts['list_id'] = $mc_list_id;
            $opts['subject'] = $content['html_sign'] . ' Horoscope for ' . $content['html_day'] . ', ' . $content['html_date'];
            $opts['from_email'] = $content['from_email']; // 'horoscope@psychicelements.com'; 
            $opts['from_name'] = $content['from_name']; // 'Psychic Elements Horoscope Newsletter';
            $opts['template_id'] = $template['id'];
            $opts['folder_id'] = $folder['folder_id'];
            $opts['tracking'] = array('opens' => true, 'html_clicks' => true, 'text_clicks' => false);
             
            $opts['authenticate'] = true;
            // $opts['analytics'] = array('google'=>'my_google_analytics_key');
            $opts['title'] = $content['html_sign'] . ' Horoscope for ' . $content['html_day'] . ', ' . $content['html_date'];

            // Place the content
            $_content = $content;

            // Set the group to send to
            $segment_opts = array(
                'match' => 'all',
                'conditions' => array(
                    array(
                        'field' => 'interests-' . $groups['id'], 
                        'op' => 'one', 
                        'value' => $sign
                    )
                )
            );

            // Create the campaign
            $campaignId = $mc_instance->campaignCreate($type, $opts, $_content, $segment_opts);

            // Error checking
            if ($mc_instance->errorCode){
                echo "Unable to Create New Campaign!";
                echo "\n\tCode=".$mc_instance->errorCode;
                echo "\n\tMsg=".$mc_instance->errorMessage."\n";

                Log::instance()->add(Log::NOTICE, "Unable to create new campaign \t
                                Code=".$mc_instance->errorCode."\n\tMsg=".$mc_instance->errorMessage."\n");
            } else {
                
                echo 'sending';
                // Send the campaign
                $mc_instance->campaignSendNow($campaignId);
            }
        }


    }

    /**
     * Retrieve the zodiac symbol and birth date range based on the given sign
     * @param sign - zodiac sign in words
     */
    public static function getZodiacSignInfo($sign) {

        $sign = strtolower($sign);

        $zodiacs = array(
            'aries' => array( 'symbol' => '<img src="https://psychicelements.com/img/horoscope/aries.png" style="width: 203px;" />', 'date' => '3/21 - 4/20' ),
            'taurus' => array( 'symbol' => '<img src="https://psychicelements.com/img/horoscope/taurus.png" style="width: 203px;" />', 'date' => '4/21 - 5/21' ),
            'gemini' => array( 'symbol' => '<img src="https://psychicelements.com/img/horoscope/gemini.png" style="width: 203px;" />', 'date' => '5/22 - 6/21' ),
            'cancer' => array( 'symbol' => '<img src="https://psychicelements.com/img/horoscope/cancer.png" style="width: 203px;" />', 'date' => '6/22 - 7/22' ),
            'leo' => array( 'symbol' => '<img src="https://psychicelements.com/img/horoscope/leo.png" style="width: 203px;" />', 'date' => '7/23 - 8/22' ),
            'virgo' => array( 'symbol' => '<img src="https://psychicelements.com/img/horoscope/virgo.png" style="width: 203px;" />', 'date' => '8/23 - 9/22' ),
            'libra' => array( 'symbol' => '<img src="https://psychicelements.com/img/horoscope/libra.png" style="width: 203px;" />', 'date' => '9/23 - 10/22' ),
            'scorpio' => array( 'symbol' => '<img src="https://psychicelements.com/img/horoscope/scorpio.png" style="width: 203px;" />', 'date' => '10/23 - 11/21' ),
            'sagittarius' => array( 'symbol' => '<img src="https://psychicelements.com/img/horoscope/sagittarius.png" style="width: 203px;" />', 'date' => '11/22 - 12/21' ),
            'capricorn' => array( 'symbol' => '<img src="https://psychicelements.com/img/horoscope/capricorn.png" style="width: 203px;" />', 'date' => '12/22 - 1/19' ),
            'aquarius' => array( 'symbol' => '<img src="https://psychicelements.com/img/horoscope/aquarius.png" style="width: 203px;" />', 'date' => '1/20 - 2/19' ),
            'pisces' => array( 'symbol' => '<img src="https://psychicelements.com/img/horoscope/pisces.png" style="width: 203px;" />', 'date' => '2/20 - 3/20' )
        );

        if (array_key_exists($sign, $zodiacs)) {
            return $zodiacs[$sign];
        } else {
            return array('symbol' => '', 'date' => '');
        }

    }

    /*
     * This gets the Phone Number according to the $key and formats it to something like this (000) 000-0000
     * @param string $key - Key index of the phone number
     */
    public static function getPhoneNumber($format = NULL, $landing_page = NULL){

        // let's see where we are coming from.
        //switch (strtolower(Request::initial()->controller())) {
        switch ($landing_page) {
            case 'landing9':
                //$phone = '8552470571';
                break;
            case 'landing10':
                $phone = '8552472617';
                break;
            default:
                // this is mojo lingo / 
                $phone = '8887771393';
                // temporarily switch all phones to VO
                //$phone = '8552472617';
                break;
        }
        // we're doing this for the landing15
        if(strpos($_SERVER['REQUEST_URI'], 'landing15') !== false){
            $phone = '8555053412';
        }
        $local_sess = Session::instance();

        // Lets look into the cookie for utm_url 
        $utm_url = NULL; 
        // check cookie first 
        if(!is_null(Cookie::get('utm_url')) AND !empty(Cookie::get('utm_url'))){
            // use the cookie for observation 
            $utm_url = Cookie::get('utm_url');
        } elseif(!is_null($local_sess->get('utm_url')) AND !empty($local_sess->get('utm_url'))) {
            // check session next 
            $utm_url = $local_sess->get('utm_url');
        }

        // do we have a channel pertaining to this? 
        $channel_model = new model_channels();
        // get the phone, might be null!
        $channel_phone = $channel_model->phoneByChannel($utm_url);
        if(!is_null($channel_phone)){
            // let's use this if not empty
            $phone = $channel_phone;
        }

        // landing promo number
        if(!is_null($local_sess->get('landing_promo'))){
            $phone = '8668559469';
        }

        // cleans the phone number WHY?
        $phone = preg_replace('/[^0-9]/', '', $phone);

        //formats the phonenumber
        if($format === true){       
            // process it in an american way.
            $phone = substr($phone,0,3)."-".substr($phone,3,3)."-".substr($phone,6);
        }
        
        return $phone;
    }

    public static function getBusinessHours($noBreak = true){
        $config = Kohana::$config->load('config');
        $businessHours = $config['business_hours'];
        $humanReadableSchedule = '';

        foreach($businessHours as $bh){
            $humanReadableSchedule .= $bh['days'].': '.date('ga', strtotime($bh['from'])).' - '.date('ga T', strtotime($bh['to'])).( $noBreak ? '<br/>' : '' );
        }

        return $humanReadableSchedule;
    }

    public static function getLearnFaceBookImage($id){
        $tag = "";
        $dir = 'img/learn/'.$id;
        if(is_dir($dir)){
              $files = scandir($dir);
              $finfo = new finfo(FILEINFO_MIME);
              foreach ($files as $file) {
                  if (!in_array($file,array(".",".."))){
                      $type = $finfo->file($dir.'/'.$file);
                    
                      $tag.= '<meta property="og:image" content="'.URL::base().$dir.'/'.$file.'">';
                $tag.= '<meta property="og:image:type" content="'.$type.'">';
              }                 
              }
          }
          return $tag;
    }
    
    public static function nameValidator($string){
            
            if(strlen(trim($string))<=0){
                return false;
            }
            //check for speecial character
            else if(preg_match('/[^a-zA-Z., ]/', trim($string))){
                return false;
            }
            //check for length if 2
            else if(strlen(preg_replace('/[^a-zA-Z ]/','', trim($string)))<2){
                return false;
            }
            else{
                return true;
            }           
    }

    public static function phoneNumberFormat($phoneNumber, $format = null) {

        if (strlen($phoneNumber) != 10) return $phoneNumber;

        switch ($format) {
            case 'n': // no format, but sub-divide it
                return substr($phoneNumber, 0, 3) . ' ' . substr($phoneNumber, 3, 3) . ' ' . substr($phoneNumber, 6); 
                break;
            case 'u': //us-formatted: (xxx) yyy-wwuu note the spacing 
                return '(' . substr($phoneNumber, 0, 3) . ') ' . substr($phoneNumber, 3, 3) . '-' . substr($phoneNumber, 6); 
                break;

            case 'i': //int-formatted: +1 (xxx) yyy-wwuu note the spacing 
                return '+1 (' . substr($phoneNumber, 0, 3) . ') ' . substr($phoneNumber, 3, 3) . '-' . substr($phoneNumber, 6); 
                break;

            case 'c': //click2call: +1xxxyyywwuu 
                return '+1' . $phoneNumber; 
                break;

            case 'm': //mojo: tel:xxxyyywwuu 
                return 'tel:' . $phoneNumber; 
                break;
            
            default: //plivo: xxxyyywwuu
               return $phoneNumber;
                break;
        }
    }

    /*
     * Returns the complete Request URL
     */
    public static function requestUrl(){
        return URL::base().substr($_SERVER['REQUEST_URI'], 1, strlen($_SERVER['REQUEST_URI']));
    }

    /*
     This parses the UTM URL being passed
     @param string $requestUri - The Customer's URL entry: In this format: /landing9?utm_source=Facebook&utm_medium=Banner&utm_campaign=Reading"
     @return array
     */
    public static function parseUtmString($requestUri){
        // Initial values
        $utm_data = array('utm_source' => NULL, 'utm_medium' => NULL, 'utm_campaign' => NULL);

        // Parse the URL
        $extractRequestUri = parse_url($requestUri, PHP_URL_QUERY);
        // extract the parameters, with sampling 
        $utm_data_temp = array();
        parse_str($extractRequestUri, $utm_data_temp);
        $utm_data['utm_source'] = (isset($utm_data_temp['utm_source'])) ? $utm_data_temp['utm_source'] : NULL;
        $utm_data['utm_medium'] = (isset($utm_data_temp['utm_medium'])) ? $utm_data_temp['utm_medium'] : NULL;
        $utm_data['utm_campaign'] = (isset($utm_data_temp['utm_campaign'])) ? $utm_data_temp['utm_campaign'] : NULL;
        // array(3) { ["utm_source"]=> string(8) "Facebook" ["utm_medium"]=> string(6) "Banner" ["utm_campaign"]=> string(7) "Reading" }
        
        // decode (might not be necessary)
        array_walk($utm_data, function(&$val, $key){
            // url decode 
            $val = urldecode($val);
            // remove any spaces 
            $val = str_replace(' ', '', $val);
            // lowercase everything to make sure it matches to database values later on 
            //$val = strtolower($val);
            // remove .com, .net, .org etc from source 
            //$val = str_replace(array('.com', '.net', '.org'), '', $val);
        });
        // done array(3) { ["utm_source"]=> string(8) "facebook" ["utm_medium"]=> string(6) "banner" ["utm_campaign"]=> string(7) "reading" }
        return $utm_data;
    }

    // CSV download
    public static function force_csv_download($filename){
        $filename_base = basename($filename); 
        // put out headers
        header("Content-type: text/csv");
        header("Content-Disposition: attachment; filename=".$filename_base);
        header("Pragma: no-cache");
        header("Expires: 0");
        readfile($filename);
        return false;
    }

    /**
     * Retrieve the zodiac sign based on the given birth date
     * @param string/date $bDay - birth date to base the zodiac sign
     */
    public static function getZodiacSign($bDay) {

        $birthDate = strtotime(date('m/d', strtotime($bDay)));

        // if date is between Jan 1 to Jan 19 change the year
        // So that it will match for capricorn
        if ($birthDate >= strtotime('1/1') && $birthDate <= strtotime('1/19')) {
            $birthDate = strtotime('+1 year', strtotime(date('m/d', strtotime($bDay))));
        }

        if ($birthDate >= strtotime('3/21') && $birthDate <= strtotime('4/20')) {
            // Aries 3/21 - 4/20
            return 'Aries';
        } elseif ($birthDate >= strtotime('4/21') && $birthDate <= strtotime('5/21')) {
            // Taurus 4/21 - 5/21
            return 'Taurus';
        } elseif ($birthDate >= strtotime('5/22') && $birthDate <= strtotime('6/21')) {
            // Gemini 5/22 - 6/21
            return 'Gemini';
        } elseif ($birthDate >= strtotime('6/22') && $birthDate <= strtotime('7/22')) {
            // Cancer 6/22 - 7/22
            return 'Cancer';
        } elseif ($birthDate >= strtotime('7/23') && $birthDate <= strtotime('8/22')) {
            // Leo 7/23 - 8/22
            return 'Leo';
        } elseif ($birthDate >= strtotime('8/23') && $birthDate <= strtotime('9/22')) {
            // Virgo 8/23 - 9/22
            return 'Virgo';
        } elseif ($birthDate >= strtotime('9/23') && $birthDate <= strtotime('10/22')) {
            // Libra 9/23 - 10/22
            return 'Libra';
        } elseif ($birthDate >= strtotime('10/23') && $birthDate <= strtotime('11/21')) {
            // Scorpio 10/23 - 11/21
            return 'Scorpio';
        } elseif ($birthDate >= strtotime('11/22') && $birthDate <= strtotime('12/21')) {
            // Sagittarius 11/22 - 12/21
            return 'Sagittarius';
        } elseif ($birthDate >= strtotime('12/22') && $birthDate <= strtotime('+1 year', strtotime('1/19'))) {
            // Capricorn 12/22 - 1/19
            return 'Capricorn';
        } elseif ($birthDate >= strtotime('1/20') && $birthDate <= strtotime('2/19')) {
            // Aquarius 1/20 - 2/19
            return 'Aquarius';
        } elseif ($birthDate >= strtotime('2/20') && $birthDate <= strtotime('3/20')) {
            // Pisces 2/20 - 3/20
            return 'Pisces';
        }
    }

    /*
     * Returns an array of the horoscopes
     */
    public static function horoscopes(){
        $horoscopes = array(
            array(
                'sign' => 'aries',
                'from' => '3/21',
                'until' => '4/20'
            ),
            array(
                'sign' => 'taurus',
                'from' => '4/21',
                'until' => '5/21'
            ),
            array(
                'sign' => 'gemini',
                'from' => '5/22',
                'until' => '6/21'
            ),
            array(
                'sign' => 'cancer',
                'from' => '6/22',
                'until' => '7/22'
            ),
            array(
                'sign' => 'leo',
                'from' => '7/23',
                'until' => '8/22'
            ),
            array(
                'sign' => 'virgo',
                'from' => '8/23',
                'until' => '9/22'
            ),
            array(
                'sign' => 'libra',
                'from' => '9/23',
                'until' => '10/22'
            ),
            array(
                'sign' => 'scorpio',
                'from' => '10/23',
                'until' => '11/21'
            ),
            array(
                'sign' => 'sagittarius',
                'from' => '11/22',
                'until' => '12/21'
            ),
            array(
                'sign' => 'capricorn',
                'from' => '12/22',
                'until' => '1/19'
            ),
            array(
                'sign' => 'aquarius',
                'from' => '1/20',
                'until' => '2/19'
            ),
            array(
                'sign' => 'pisces',
                'from' => '2/20',
                'until' => '3/20'
            )
        );

        return $horoscopes;
    }

    /*
     * Returns the current horscope of the month and day
     */
    public static function getHoroscope(){
        // instantiate
        $horoscope = NULL;
        $y = date('Y');
        $curDate = strtotime('today');

        foreach(self::horoscopes() as $h){
            $from = strtotime($h['from'].'/'.$y);
            // should change year for better capture
            if($h['sign'] == 'capricorn' AND date('m') == 1){
                $from = strtotime($h['from'].'/'.($y-1));
            }
            // should change year for better capture
            $until = strtotime($h['until'].'/'.$y);
            if($h['sign'] == 'capricorn' AND date('m') == 12){
                $until = strtotime($h['until'].'/'.($y+1));
            }
            // let's get the sign
            if($curDate >= $from AND $curDate <= $until){
                $horoscope = $h['sign'];
                break;
            }
        }
        return $horoscope;
    }

    /*
     * Limits the words to show based from a string
     * @param string $string - String to limit
     * @param int $word_limit - Number of words to show
     * @param bool $no_html - Refers if HTML tags are allowed or not
     * @return [type] [description]
     */
    public static function limit_words($string, $word_limit, $no_html = true){
        $words = explode(" ",$string);
        $period = (count($words) > $word_limit) ? '...' : '.';
        if($no_html){
            return strip_tags(implode(" ",array_splice($words, 0, $word_limit))).$period;
        }
        return implode(" ",array_splice($words, 0, $word_limit)).$period;
    }

    /*
     * Limits the character to show depending on the number of characters on a string
     * @param string $string - String to convert
     * @param int $limit - limit of characters to show
     * @return [type] [description]
     */
    public static function limit_chars($string, $limit){
        if(strlen($string) > $limit){
            $words = explode(' ', $string);
            if(count($words) > 1){
                return $words[0].' '.substr($words[1], 0, 1).'.';
            }
            return substr($string, 0, 6).'...';
        }
        return $string;
    }

    public static function flatten(array $array) {
        $return = array();
        array_walk_recursive($array, function($a) use (&$return) { $return[] = $a;  });
        return $return;
    }
    /*
     * Common psyele's now()
     */
    public static function now(){
        return date('Y-m-d H:i:s');
    }

    /*
      * Strip weird symbols like \xEF\xBB\xBF
      */
    public static function stripChar($string){
        return iconv('UTF-8', 'ISO-8859-1//IGNORE', $string);
    }

    /*
     * WatchCat counter
     */
    public static function watchCatCounter(){
        $filename = '/watchcat-counter.txt';
        try{
          $f = @fopen($_SERVER['DOCUMENT_ROOT'].$filename, 'r+');
          $data = fread($f, filesize($_SERVER['DOCUMENT_ROOT'].$filename));
          if (false === $data) {
              $data = 1; //start from 1
          } else {
              $data++;
          }
          $f = fopen($_SERVER['DOCUMENT_ROOT'].$filename, 'w+');
          @fwrite($f, $data);
          fclose($f);

          return $data;

          }catch(Exception $e){
            $counter = 1;
            $f = @fopen($_SERVER['DOCUMENT_ROOT'].$filename, 'w+');
            @fwrite($f, $counter);//start counter from 1
            @fclose($f);
            Helper_Functions::watchCatCounter();
            return $counter;
          }
  }
}
