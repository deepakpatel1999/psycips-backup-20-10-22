<div class="banner">
	<div class="text_ads visible-xs">
		<div class="pull-right text-center">
			<div class="title">
				<div class="sm_marg_b"><img src="<?php echo URL::base(); ?>img/pop_logo.png" class="img-responsive" alt="Psychic Elements Logo" /></div>
				Call One of Our Handpicked Gifted Psychics Now For The Best Psychic Reading
			</div>
			<?php if($isLoggedIn){ ?>
				<a href="<?php echo URL::base(); ?>psychics" class="get_reading">Get a Reading</a>
			<?php } ?>
		</div>
		<div class="clearfix"></div>
	</div>

	<div class="main_content hidden-xs">
		<div class="text">Call One of Our Handpicked Gifted Psychics Now<br/>For The Best Psychic Reading</div>
		<?php if(!$isLoggedIn){ ?>
			<div class="intro_rate">20 Minutes for $20</div>
			<div class="offer">Offer for New Customers only</div>
		<?php } ?>
		<a href="<?php echo URL::base(); ?>intro-offer" class="get_reading">Get a Reading</a>
		<div class="trusty"><span class="heart"></span>Trusted by thousands of customers</div>
	</div>
</div>

<div class="dpm_ad visible-xs">
	<?php if(!$isLoggedIn){ ?>
		<div class="reading">Live Readings for just</div>
		<div class="dpm_text">20 Minutes for $20</div>
		<div class="dpm_small">New customers only</div>
		<a href="tel:<?php echo helper_functions::getPhoneNumber(); ?>" class="dpm_button">Get a Reading</a>
	<?php } ?>
	<div class="trusty"><span class="heart"></span>Trusted by thousands of customers</div>
</div>

<div class="middle_content">
	<div class="title">Why Choose Psychic Elements</div>
	<div class="reason">
		<img src="<?php echo URL::base(); ?>img/wpe_head.png" alt="Psychic Experts" />
		<div class="exp hidden-xs">Psychic Experts Hand<br/>Picked From Across the<br/>Country</div>
		<div class="exp visible-xs">Psychic Experts Hand Picked From Across the Country</div>
	</div>
	<div class="reason">
		<img src="<?php echo URL::base(); ?>img/wpe_heart.png" alt="Satisfied and Loyal Customers" />
		<div class="exp hidden-xs">Thousands of Satisfied &<br/>Loyal Customers</div>
		<div class="exp visible-xs">Thousands of Satisfied & Loyal Customers</div>
	</div>
	<!--
	<div class="reason">
		<img src="<?php echo URL::base(); ?>img/wpe_star.png" alt="Free Psychic Reading" />
		<div class="exp hidden-xs">IF IT IS NOT THE BEST<br/>psychic reading you've<br/>ever had, it's FREE.</div>
		<div class="exp visible-xs">IF IT IS NOT THE BEST psychic reading you've ever had, it's FREE.</div>
	</div>
	-->
	<div class="reason">
		<img src="<?php echo URL::base(); ?>img/wpe_lock.png" alt="Readings are Private and Confidential" />
		<div class="exp hidden-xs">All Readings are Private &<br/>Confidential</div>
		<div class="exp visible-xs">All Readings are Private &<br/>Confidential</div>
	</div>
</div>

<div class="middle_description">
	<div class="content">
		<div class="title">Handpicked Across US & Canada</div>
		<div class="main_title">Best Psychic Reading</div>
		<p>We all have that one thing happening in our lives that's occupying too much of our thoughts. Especially when you feel like there's nothing you can do. Or is there?</p>
		<p>Maybe you've done everything you possibly and rationally can. If you have, then it's time to give good old intuition a chance. Sometimes the answer is within our reach, but we need help with being able to see it. That's where Psychic Elements can help.</p>
		<a href="<?php echo URL::base(); ?>intro-offer" class="get_reading">Get a reading now</a>
	</div>
	<div class="clearfix"></div>
</div>

<div class="hp_boxes">
	<div class="box">
		<div class="title">Our Psychic Screening and Evaluation Processes</div>
		<p>Because we know how important trust is in our line of work, <a href="<?php echo URL::base(); ?>psychics">psychics online</a> who approach us go through a strict evaluation and screening process before we feature them on our website. Their profiles can tell you more about how they conduct readings, and what other clients' experiences with them are. Our hope, when you sign up, is that we help get the best psychic for you.</p>
	</div>
	<div class="box">
		<div class="title">Discounts, Promos, and Gifts the More You Call</div>
		<p>Even after you use our introductory promo, our regular rates are still competitive among other <a href="<?php echo URL::base(); ?>psychic-line">online psychic</a> services today. Feel free to see for yourself! On top of that, we are always working on new discounts, promos, and gifts just for staying with us and using our services. Make sure you're opted in our email updates, so you don't miss out. You can also check with our Customer Care if you qualify for any new offers.</p>
	</div>
	<div class="box">
		<div class="title">You are Our VIP</div>
		<p>Our introductory promo helps you ease into how our service and our psychic reading system works. Our satisfaction guarantee lets you have your money back if your first few minutes with an <a href="<?php echo URL::base(); ?>psychic-line">online psychic</a> doesn't make you happy. And if you ever have any questions about finding your way around, you can check out our FAQ, or talk to our Customer Care people either through online chat or phone.</p>
	</div>
	<div class="box">
		<div class="title">No-commitment signup and Transaction Processes</div>
		<p>When you sign up with us as a customer, we make sure that your card doesn't get charged until you've explicitly expressed your approval. What's more, you can sign up with us either as a member or a newsletter subscriber without paying for anything until you're ready.</p>
	</div>
	<div class="box">
		<div class="title">Newsletter and Horoscope Subscriptions</div>
		<p>We have a twice-weekly newsletter that comes out with our featured blog post and featured psychics of the week. These posts are about our day-to-day challenges, and how our psychics' intuitive insight can help illuminate better choices for you. You can also opt-in our daily horoscope, so you can prepare for what's ahead.</p>
	</div>
	<div class="box">
		<div class="title">Our Psychics' Abilities, Topics, and Tools</div>
		<p>Our psychics come with <a href="<?php echo URL::base(); ?>blog/psychic-abilities">different abilities</a> like clairvoyance, mediumship, and channeling. They are experts in a variety of topics, like <a href="<?php echo URL::base(); ?>love-psychics">love and relationships</a>, <a href="<?php echo URL::base(); ?>blog/career-psychics">career and money</a>, and destiny and your life's meaning. And they can use a variety of tools, like <a href="<?php echo URL::base(); ?>tarot-reading">tarot</a>, spirit guides, or astrology. If you choose, they can also use no tools at all.</p>
	</div>
	<div class="box">
		<div class="title">How a Phone Reading Can be Better</div>
		<p>A <a href="<?php echo URL::base(); ?>phone-psychic-readings">phone reading</a> can be better than a face-to-face reading simply because your psychic can better read your pure energy. They won't be distracted by your gestures or facial expressions. It's usually much easier to talk openly over the phone than in person. Most importantly, both you and the psychic can choose the environments where you want to have your reading, leading to greater comfort and openness.</p>
	</div>
	<div class="box">
		<div class="title">Are you Psychic?</div>
		<p>We acknowledge the intuitive abilities latent in everyone, and the fact that more and more people these days are waking up to their abilities. If you want to learn more about your abilities, you can check if we've written about them on the <a href="<?php echo URL::base(); ?>blog">blog</a>. If you have developed your abilities enough that people are already telling you to work as a psychic for a living, you may want to consider working with us.</p>
	</div>
	<div class="box">
		<div class="title">Keep in Touch We're Listening</div>
		<p>Add us up on your favorite social media! We post updates on the latest in the psychic industry, stories of how psychics helped change clients' lives for the better, and giveaways that could be your chance to score merchandise and free psychic readings. Share your thoughts with us on how we could be better for you - we are listening, and we know how good it feels when you are listened to and understood truly.</p>
	</div>
	<div class="clearfix"></div>

	<div class="note">Now, do you want to learn how you can change your life for the better, and achieve the happiness you deserve? We can help. Let us ease your worries. Breathe deeply and well, so your psychic can pick up the best of your energy. Get comfortable, and give us a call. The bright future you wish for is in your hands, and our psychics are waiting to help show you the way!</div>
</div>

<div class="intro_offer">
	<div class="offer">
		<div class="title">Introductory Offer</div>
		<div class="package">$20 for 20 minutes</div>
		<div class="clearfix"></div>
		<a href="<?php echo URL::base(); ?>intro-offer" class="get_reading">Get a Reading</a>
	</div>
</div>

<div class="major_buttons">
	<div class="button first"><a href="javascript:void(0);" class="home_psychic_filter" data-category="3">Career & Finance</a></div>
	<div class="button second"><a href="javascript:void(0);" class="home_psychic_filter" data-category="4">Destiny & Life Path</a></div>
	<div class="button third"><a href="javascript:void(0);" class="home_psychic_filter" data-category="1">Love & Relationship</a></div>
</div>
