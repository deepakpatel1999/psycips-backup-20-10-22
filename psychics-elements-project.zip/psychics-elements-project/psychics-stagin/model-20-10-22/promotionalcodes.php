<?php defined('SYSPATH') or die('No direct access allowed.');



/*

* This Model serves the Promotional Code Enum of the Nimda role

*

*/

class model_financials_promotionalcodes extends Model_Admin {

    // initialize the error handlers:

    public $pe_error_code = NULL;

    // getter

    public function lastError($showErrorCode = false){

        $error_string = '';

        switch ($this->pe_error_code) {

            case 'PE_PC_NOT_EXIST':

                $error_string = 'This code does not exist.';

                break;

            case 'PE_PC_NOT_ACTIVE':

                $error_string = 'This code is not active.';

                break;

            case 'PE_PC_EXPIRED':

                $error_string = 'This code has expired';

                break;

            case 'PE_PC_CAP_REACHED':

                $error_string = 'This code has reached its max cap.';

                break;

            case 'PE_PC_USED':

                $error_string = 'You already have used this code.';

                break;

            default:

                $error_string = 'Unknown Error has occured. :-/ ';

                break;

        }

        // should we show the raw error code?

        if($showErrorCode){

            $error_string = $error_string.' ('.$this->pe_error_code.')';

        }

        // nullify this for later use

        $this->pe_error_code = NULL;

        return $error_string;

    }

    ################

    #### CRUD ######

    ################



    /*

     * Adds a record to the promotionalCodes table

     * @param string $code - code

     * @param decimal $amount - amount of the code

     * @param int $minutes - minutes of the code

     * @param int $cap - limit of usage

     * @param date $expire_date - validity of the code

     * @param int $count - counter for the usage

     * @param int $active - If active or inactive

     */

    public function create($code, $amount, $minutes, $cap, $expire_date, $requiredPackage = NULL, $autoRedeem = NULL, $count = 0, $active = 1){

        // Query to add the record

        $sql = 'INSERT INTO promotionalCodes (code, amount, minutes, cap, expirationDate,  requiredPackage, autoRedeem, count, active) VALUES (:code, :amount, :minutes, :cap, :expirationDate, :requiredPackage, :autoRedeem, :count, :active)';

        DB::query(Database::INSERT, $sql)

            ->bind(':code', $code)

            ->bind(':amount', $amount)

            ->bind(':minutes', $minutes)

            ->bind(':cap', $cap)

            ->bind(':expirationDate', $expire_date)

            ->bind(':requiredPackage', $requiredPackage)

            ->bind(':autoRedeem', $autoRedeem)

            ->bind(':count', $count)

            ->bind(':active', $active)

            ->execute(Database::instance());

    }



    public function update($promotionalCodeId, $cap, $expire_date) {

        // Query to update the record

        $sql = 'UPDATE promotionalCodes SET cap = :cap, expirationDate = :expirationDate WHERE promotionalCodeId = :promotionalCodeId';

        DB::query(Database::INSERT, $sql)

            ->bind(':promotionalCodeId', $promotionalCodeId)

            ->bind(':cap', $cap)

            ->bind(':expirationDate', $expire_date)

            ->execute(Database::instance());

        

    }

    /*

     * Returns the row of the Code in the form of array

     * @param int $promotionalCodeId - ID of the Code

     */

    public function read($promotionalCodeId){

        // Query to get the row of the code by id

        $sql = 'SELECT * FROM promotionalCodes WHERE promotionalCodeId = :promotionalCodeId';

        return DB::query(Database::SELECT, $sql)->bind(':promotionalCodeId', $promotionalCodeId)->execute(Database::instance())->current();

    }



    public function changeStatus($promotionalCodeId){



        $sql = 'UPDATE promotionalCodes SET active = IF(active = 0, 1, 0) WHERE promotionalCodeId = :promotionalCodeId';

        DB::query(Database::UPDATE, $sql)

            ->bind(':promotionalCodeId', $promotionalCodeId)

            ->execute(Database::instance());



    }



    #################

    #### CRUD AUX ###

    #################



    // Method to get all codes

    public function all($active = NULL){

        // Query to return all codes

        $sql = 'SELECT * FROM promotionalCodes';

		if(!is_null($active)){

			$sql .= ' WHERE active = :active';

		}

		$sql .= ' ORDER BY promotionalCodeId ASC';

        return DB::query(Database::SELECT, $sql)->bind(':active', $active)->execute(Database::instance())->as_array();

    }

    

    /**

     * Returns an array of all purchase attempts made by a customer

     * @param  int $customerId customer identifier

     * @return array             array of payment objects

     */

    public function allByCustomer($customerId = NULL){

        $sql = 'SELECT * FROM appliedPromotions ap LEFT JOIN promotionalCodes pc ON (pc.promotionalCodeId = ap.promotionalCodeId) WHERE customerId=:customerId'; 

        $result = DB::query(Database::SELECT, $sql)->bind(':customerId', $customerId)->execute(Database::instance())->as_array(); 

        return $result;

    }



    public function allAppliedPromotions($start_date = null, $end_date = null){



        // Query to return all codes

        $sql = 'SELECT c.customerId, c.firstName, c.lastName, c.firstName custFirstName, c.lastName custLastName, pc.code, ap.createdAt, ap.amount, ap.minutes ';



        $sql .= ' FROM appliedPromotions ap 

            INNER JOIN customers c 

            ON c.customerId = ap.customerId 

            LEFT JOIN promotionalCodes pc 

            ON pc.promotionalCodeId = ap.promotionalCodeId WHERE 1=1 ';



        if (!is_null($start_date) && !is_null($end_date)) {

			$sql .= ' AND DATE(ap.createdAt) BETWEEN :start_date AND :end_date ';

        }

        if (is_null($start_date) && !is_null($end_date)) {

			$sql .= ' AND DATE(ap.createdAt) <= :end_date ';

        }

        if (!is_null($start_date) && is_null($end_date)) {

			$sql .= ' AND DATE(ap.createdAt) >= :start_date ';

        }



        $sql .= ' ORDER BY appliedPromotionId';



        return DB::query(Database::SELECT, $sql)

            ->bind(':start_date', $start_date)

            ->bind(':end_date', $end_date)

            ->execute(Database::instance())->as_array();

    }



    #########################

    #### Everything Else  ###

    #########################



    /*

     * Returns the row of the Code in the form of array

     * @param string $code - Code

     */

    public function getCodeByCode($code, $promotionalCodeId = 0){

        // Query to get the row of the code

        $sql = 'SELECT * FROM promotionalCodes WHERE code = :code';

		if($promotionalCodeId != 0){

			$sql .= ' AND promotionalCodeId != :promotionalCodeId';

		}

        return DB::query(Database::SELECT, $sql)->bind(':code', $code)->bind(':promotionalCodeId', $promotionalCodeId)->execute(Database::instance())->current();

    }



    /*

     * Returns the data of the applied promotion by a customer.

     * @param int $promoId - Promotional Code ID

     * @param int $customerId - Customer's ID

     * @return array

     */

    public function checkAppliedCode($customerId, $promotionalCodeId){

        $sql = 'SELECT * FROM appliedPromotions WHERE customerId = :customerId AND promotionalCodeId = :promotionalCodeId';

        return DB::query(Database::SELECT, $sql)->bind(':customerId', $customerId)->bind(':promotionalCodeId', $promotionalCodeId)->execute(Database::instance())->current();

    }



    public function checkValid($promo_code_object){

        // active at all?

        if($promo_code_object['active'] != 1){

            return false;

        }

        // has cap or cap reached

        if( $promo_code_object['cap'] > 0 AND ($promo_code_object['cap'] <= $promo_code_object['count']) ){

            return false; 

        }

        // check expiration date

        if( !is_null($promo_code_object['expirationDate']) ){

            if(strtotime($promo_code_object['expirationDate']) < strtotime(date('Y-m-d'))){

                return false;

            }

        }

        // otherwise

        return true;

    }



    /**

     * Returns all auto redeemable discounts from the database.

     * @param  boolean $include_session include the one in the session?

     * @return [type]                   [description]

     */

    public function allAutoRedeem($include_session = false){

        // prep response

        $discounts = array();

        // query db

        $discounts_db = DB::select()->from('promotionalCodes')->where('requiredPackage', '>', '0')->and_where('autoRedeem', '=', '1')->and_where('active', '=', '1')->order_by('promotionalCodeId', 'desc')->execute()->as_array();

        // do we have to check for things that are in session too?

        if($include_session){

            $_sess = Session::instance();

            $promo_code = $_sess->get('promo_code');

            $sql = 'SELECT * FROM promotionalCodes WHERE active = 1 AND (requiredPackage IS NOT NULL AND autoRedeem = 1 ) OR code = :code ORDER BY promotionalCodeId DESC';

            $discounts_db = DB::query(Database::SELECT, $sql)->bind(':code', $promo_code)->execute()->as_array();

        }

        // let's validate them

        if(count($discounts_db) > 0){

            foreach($discounts_db as $disc){

                // filter which are still valid

                if($this->checkValid($disc)) $discounts[] = $disc;

            }

        }

        // return filtered

        return $discounts;

    }



    /*

     * Returns all code entry promo code that has not been used yet by a customer.

     * @param int $customerId - Customer's ID

     * @param array $requiredPackages - The required packages

     * @return [type] [description]

     */

    public function allCodeEntry($customerId = NULL, $requiredPackages = array()){

        // query them

        $sql = 'SELECT * FROM promotionalCodes WHERE autoRedeem IS NULL';

        // required package

        if(count($requiredPackages) > 0){

            $sql .= ' AND (';

            $sqlOr = array();

            foreach($requiredPackages as $rp){

                $sqlOr[] = 'requiredPackage = "'.$rp.'"';

            }

            $sql .= implode(' OR ', $sqlOr).')';

        }

        // codes that have not used by the customer param

        if(!is_null($customerId)){

            $sql .= ' AND promotionalCodeId NOT IN (SELECT promotionalCodeId FROM appliedPromotions WHERE customerId = :customerId)';

        }

        return DB::query(Database::SELECT, $sql)->bind(':customerId', $customerId)->execute(Database::instance())->as_array();

    }



    /*

     * Returns the Promo Code that requires a package purchase and is not yet been used by the customer

     * @param int $customerId - Customer's ID

     * @param string $requiredPackage - Pre-named required package

     * @return [type] [description]

     */

    public function promoCodeRequiredPackage($customerId = NULL, $requiredPackage = NULL){

        $sql = 'SELECT * FROM promotionalCodes WHERE active = 1';

        // required package

        if(!is_null($requiredPackage)){

            $sql .= ' AND requiredPackage = :requiredPackage';

        }

        // codes that have not used by the customer param

        if(!is_null($customerId)){

            $sql .= ' AND promotionalCodeId NOT IN (SELECT promotionalCodeId FROM appliedPromotions WHERE customerId = :customerId)';

        }

        $result = DB::query(Database::SELECT, $sql)->bind(':requiredPackage', $requiredPackage)->bind(':customerId', $customerId)->execute(Database::instance())->current();

        // validate

        if(!is_null($result['promotionalCodeId'])){

            if($this->checkValid($result)){

                return $result;

            }

            return false;

        }

        return false;

    }



    /*

     * Returns all active and promo packages

     * @param string $prefix - The type of package to return

     * @return [type] [description]

     */

    public function promoPackages($package){

        $sql = 'SELECT * FROM promotionalCodes WHERE autoRedeem = 1 AND active = 1 AND requiredPackage = :package';

        $result = DB::query(Database::SELECT, $sql)->bind(':package', $package)->execute(Database::instance())->current();

        // validate
        return $result;
        if(!is_null($result['promotionalCodeId'])){

            if($this->checkValid($result)){

                return $result;

            }

            return false;

        }

        return false;

    }



    /**

     * Redeems a promotional code into the customers account. 

     * @param  int $me         redeemer, 0 = system, nimdaId / customerId

     * @param  int $customerId customer identifier

     * @param  int $code       the promo code identifier

     * @return mixed             true on success, various error codes

     */

    public function apply($me = NULL, $customerId = NULL, $promotionalCodeId = NULL){

        if(is_null($me) OR is_null($customerId) OR is_null($promotionalCodeId)){

            throw new Exception('Invalid invocation, apply.', 1);

        }

        // read it 

        $pc = $this->read($promotionalCodeId);

        // Check if positive:

        if(is_null($pc['promotionalCodeId'])){

            $this->pe_error_code = 'PE_PC_NOT_EXIST';

            return false;

        }

        // Check if active 

        if($pc['active'] != 1){

            $this->pe_error_code = 'PE_PC_NOT_ACTIVE';

            return false;

        }

        // Check if expired 

        $current_date = strtotime(date('Y-m-d'));

        $expirationDate = strtotime($pc['expirationDate']);

        if(!is_null($pc['expirationDate'])){

            if($current_date > $expirationDate) {

                $this->pe_error_code = 'PE_PC_EXPIRED';

                return false;

            }

        }

        // Check if cap reached - let's disable this for the time being so all customers can use it one time

        if($pc['cap'] > 0 AND ($pc['count'] >= $pc['cap']) ){

            $this->pe_error_code = 'PE_PC_CAP_REACHED';

            return false;

        }

        // Check if this is not auto redeem

        if($pc['autoRedeem'] != 1){

            // Customer should be able to use a promo code one time for the time being

            $checkAppliedCode = $this->checkAppliedCode($customerId, $promotionalCodeId);

            if(isset($checkAppliedCode['appliedPromotionId']) && !is_null($checkAppliedCode['appliedPromotionId'])){

                $this->pe_error_code = 'PE_PC_USED';

                return false;

            }

        }



        // Now that all checks are passed, let's actually "use" this code!

        // iterate the code count

        $sql = 'UPDATE promotionalCodes SET count = (count + 1) WHERE promotionalCodeId=:promotionalCodeId '; 

        DB::query(Database::UPDATE, $sql)->bind(':promotionalCodeId', $promotionalCodeId)->execute(Database::instance());

        // Log this into used promotions

        // appliedPromotionId | customerId | promotionalCodeId | amount | minutes | createdAt           | createdBy

        DB::insert('appliedPromotions', array('customerId', 'promotionalCodeId', 'amount', 'minutes', 'createdAt', 'createdBy'))

                                ->values(array($customerId, $promotionalCodeId, $pc['amount'], $pc['minutes'], helper_functions::now(), $me))->execute();

        // With this in hand we can top up the customer's account

        $model_customers = new model_users_customers;

        // Money

        if($pc['amount'] > 0){

            $model_customers->addBalance($me, $customerId, $pc['amount']);

        }

        // Minutes

        if($pc['minutes'] > 0){

            $seconds = $pc['minutes'] * 60;

            $model_customers->addDpmBalance($me, $customerId, $seconds);

        }

        return true;

    }



    /*

     * Returns true if the customer has already used up all free 5 minute promo avail on the system

     */

    public function freeMinuteClaim($customerId = NULL){

        if(is_null($customerId)){

            return false;

        }

        $sql = 'SELECT * FROM appliedPromotions WHERE promotionalCodeId IN (SELECT promotionalCodeId FROM promotionalCodes WHERE (amount = 5.00 OR minutes = 5.00) AND active = 1) AND customerId = :customerId';

        $result = DB::query(Database::SELECT, $sql)->bind(':customerId', $customerId)->execute(Database::instance())->as_array();

        if(count($result) > 0){

            return true;

        }

        return false;

    }

}

