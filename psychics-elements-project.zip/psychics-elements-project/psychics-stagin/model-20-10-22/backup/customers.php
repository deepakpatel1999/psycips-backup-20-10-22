<?php defined('SYSPATH') or die('No direct access allowed.');
//require_once __DIR__ . '/../../../../vendor/autoload.php';
require DOCROOT . 'vendor/autoload.php';
ini_set('memory_limit', '2G');
ini_set('max_execution_time', 500);
/**
 * All the crud functions, password / login functions , everything that has to do with customers are here.
 */
/*
Database documentation :
CREATE TABLE `customers` (
  `customerId` int(10) unsigned NOT NULL AUTO_INCREMENT, -- unique customer Id
  `firstName` varchar(50) DEFAULT NULL, -- customer firstname 
  `lastName` varchar(50) DEFAULT NULL, -- customer last name
  `cellphone` varchar(45) NOT NULL, -- customer cellphone ~~ This is the number we always call! ~~ must be unique
  `landphone` varchar(45) DEFAULT NULL, -- customer's second phone ~~ currently not used ~~
  `birthdate` date DEFAULT NULL, -- birthdate , pin is created from this, also used in verification 
  `email` varchar(128) NOT NULL, -- customer's email, must be unique
  `active` tinyint(1) NOT NULL DEFAULT '0', -- active flag. Inactive users cannot log in. 0 => inactive , 1 => active
  `archived` tinyint(4) DEFAULT '0', -- determines archived factor, not yet used 
  `password` varchar(164) NOT NULL DEFAULT '', -- sha1'd passwd 
  `PIN` varchar(45) NOT NULL, -- customer's pin , created based on bday
  `address` varchar(200) DEFAULT NULL, -- customers address (tbr)
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `zipCode` varchar(10) DEFAULT NULL,
  `country` int(10) DEFAULT NULL,
  `timezone` varchar(45) DEFAULT NULL, -- customers PHP value timezone 
  `balance` decimal(6,2) DEFAULT NULL, -- customer's balance, min is 0 , max is 10000
  `paid` decimal(8,2) NOT NULL DEFAULT '0.00', -- paid amount to customer (currently not used, tbr)
  `sendEmail` tinyint(1) NOT NULL DEFAULT '1', -- customer's receive promo flag , default 1 always 
  `sendCall` tinyint(1) NOT NULL DEFAULT '1', -- customer's receive call flag, always 1 
  `notes` varchar(512) DEFAULT '', -- customers notes, currently not used 
  `lastIP` varchar(45) NOT NULL, -- last IP of person modifying this account / logging into this account 
  `receivePromotions` tinyint(1) DEFAULT '0', -- flag to determine if customer is receiving promos or not ? (tbr)
  `createdAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00', -- timestamp of creation of this freakin account 
  `modifiedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, -- last modification of this account 
  `createdBy` int(10) NOT NULL, -- creator of account. 0 = system 
  `modifiedBy` int(10) NOT NULL, -- last modifier of the account, 0 = system, anything else is nimdaId
  `anetCimId` int(10) DEFAULT '0', -- Authorize.net profile Id. -1 denotes a VERY BAD THING! 
  `available` tinyint(1) DEFAULT '0', -- customer availability flag for the phone system, currently not used. 
  PRIMARY KEY (`customerId`),
  UNIQUE KEY `cellphone_UNIQUE` (`cellphone`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  KEY `password` (`password`),
  KEY `birthdate` (`birthdate`)
 */

class model_users_customers extends model_admin
{
    ################
    #### CRUD ######
    ################

    public function create($me, $firstName, $lastName, $email, $password, $cellphone, $landphone, $birthdate, $sendCall, $receivePromo, $address, $city, $state, $country, $zipCode, $timezone, $active = 1)
    {
        //hash it
        $password = sha1($password);
        $paid = 0; // until further notice
        $balance = 0; // until further notice
        $dpmsBalance = 0; // until further notice
        $lastIP = helper_functions::getIP();
        // create PIN
        $PIN = Helper_Functions::birthdate2pin($birthdate);
        $sendEmail = 1; // we send email to everyone.

        // Do the real work
        $sql = 'INSERT INTO customers (firstName, lastName, cellphone, landphone, birthdate, email, active, password, PIN, address, city, country, zipCode, state, balance, paid, sendEmail, sendCall, lastIP, timezone, receivePromotions, utm_url, utm_source, utm_campaign, utm_medium, utm_referer, createdAt, createdBy, modifiedBy) ';
        $sql .= ' VALUES          (:firstName, :lastName, :cellphone, :landphone, :birthdate, :email, :active, :password, :PIN, :address, :city, :country, :zipCode, :state, :balance, :paid, :sendEmail, :sendCall, :lastIP, :timezone, :receivedPromotions, :utm_url, :utm_source, :utm_campaign, :utm_medium, :utm_referer, NULL, :createdBy, :modifiedBy) ';

        $sess = Session::instance();

        // Tracking step 0; initiate the values
        $utm_url = $utm_source = $utm_campaign = $utm_medium = $utm_referer = NULL;

        // Tracking, step 1, check cookie (the easy way)
        if (!is_null(Cookie::get('utm_url')) and !empty(Cookie::get('utm_url'))) {
            // use the cookie for observation
            $utm_url = Cookie::get('utm_url');
            $utm_source = Cookie::get('utm_source');
            $utm_medium = Cookie::get('utm_medium');
            $utm_campaign = Cookie::get('utm_campaign');
            $utm_referer = Cookie::get('utm_referer');
        } elseif (!is_null($sess->get('utm_url')) and !empty($sess->get('utm_url'))) {
            // use session for these values
            $utm_url = $sess->get('utm_url');
            $utm_source = $sess->get('utm_source');
            $utm_medium = $sess->get('utm_medium');
            $utm_campaign = $sess->get('utm_campaign');
            $utm_referer = $sess->get('utm_referer');
            // delete the session vars non the less? nope
        }

        // Step 2. Organic tracking
        if (empty($utm_source) and empty($utm_medium) and empty($utm_campaign)) {
            // Let's see if we can check the referer only, for google.com, yahoo.com, and bing.com

            // Lets look into the cookie for utm_referer
            $utm_referer = NULL;
            $local_sess = Session::instance();

            // check cookie first
            if (!is_null(Cookie::get('utm_referer')) and !empty(Cookie::get('utm_referer'))) {
                // use the cookie for observation
                $utm_referer = Cookie::get('utm_referer');
            } elseif (!is_null($local_sess->get('utm_referer')) and !empty($local_sess->get('utm_referer'))) {
                // check session next
                $utm_referer = $local_sess->get('utm_referer');
            } else {
                // nope, we really don't have anything! byebye
                // return null;
            }

            // Now let's try google
            if (strpos($utm_referer, 'google.com') !== false) {
                $utm_source = 'google';
                $utm_campaign = 'organic';
                $utm_medium = 'search';
            }
            // Now let's try yahoo
            if (strpos($utm_referer, 'yahoo.com') !== false) {
                $utm_source = 'yahoo';
                $utm_campaign = 'organic';
                $utm_medium = 'search';
            }
            // Now let's try bing
            if (strpos($utm_referer, 'bing.com') !== false) {
                $utm_source = 'bing';
                $utm_campaign = 'organic';
                $utm_medium = 'search';
            }

        }

        // Step 3. what if is a callback?!
        $caller_to = NULL; // this will be used for Step 5.
        if ($me > 0) {
            // do a query on vocetis answers table
            $caller_from = '1' . $cellphone;
            $sql2 = 'SELECT vi.caller_to FROM vocetis_answers va RIGHT JOIN vocetis_incomings vi ON (va.incomingId = vi.incomingId) 
          WHERE (vi.hungup = 0 AND va.hungup = 0) OR (va.hungup = 1 AND va.hold =1)  
          AND va.nimdaId = :nimdaId AND vi.caller_from = :caller_from';
            $answer = DB::query(Database::SELECT, $sql2)->bind(':nimdaId', $me)->bind(':caller_from', $caller_from)->execute(Database::instance())->current();

            // validate the query
            if (!is_null($answer)) {
                $model_channels = new model_channels();
                $caller_to = $answer['caller_to'];
                // remove 1 from phone numbers.
                if (strlen($caller_to) == 11) {
                    $caller_to = substr($caller_to, 1);
                }
                // this is the phone number that these people have dialed to // verify by adrian.
                $utm_data = $model_channels->readByPhoneNumber($caller_to);
                // If there is a match phone number of UTM
                if (!is_null($utm_data)) {
                    $utm_url = $caller_to;
                    $utm_source = $utm_data['utm_source'];
                    $utm_campaign = $utm_data['utm_campaign'];
                    $utm_medium = $utm_data['utm_medium'];
                    $utm_referer = $utm_data['utm_name'];
                }
            }
            // done with phone lookup
        }

        $landing_url = 'fix this';
        // // Step 4. let's check landing url, or point of purchase
        // if(!is_null($sess->get('landing_url'))){
        //   // Parse the URL and get the query parameters only.
        //   $parseLandingUrl = parse_url($sess->get('landing_url'), PHP_URL_QUERY);
        //   // Check if there is a UTM with it...
        //   if(!is_null($parseLandingUrl)){
        //     $utmData = parse_str($parseLandingUrl, $data);

        //     // let's check the initial UTM vars...
        //     if(is_null($utm_source)){
        //       $utm_source = ( isset($data['utm_source']) ) ? $data['utm_source'] : NULL;
        //       $utm_campaign = ( isset($data['utm_campaign']) ) ? $data['utm_campaign'] : NULL;
        //       $utm_medium = ( isset($data['utm_medium']) ) ? $data['utm_medium'] : NULL;
        //     }
        //   }
        // }

        // lowercase then capitalize first letters the customer name
        $firstName = ucfirst(strtolower($firstName));
        $lastName = ucfirst(strtolower($lastName));

        $result = DB::query(Database::INSERT, $sql)
            ->bind(':firstName', $firstName)
            ->bind(':lastName', $lastName)
            ->bind(':cellphone', $cellphone)
            ->bind(':landphone', $landphone)
            ->bind(':birthdate', $birthdate)
            ->bind(':email', $email)
            ->bind(':active', $active)
            ->bind(':password', $password)
            ->bind(':PIN', $PIN)
            ->bind(':address', $address)
            ->bind(':city', $city)
            ->bind(':country', $country)
            ->bind(':zipCode', $zipCode)
            ->bind(':state', $state)
            ->bind(':balance', $balance)
            ->bind(':paid', $paid)
            ->bind(':sendEmail', $sendEmail)
            ->bind(':sendCall', $sendCall)
            ->bind(':lastIP', $lastIP)
            ->bind(':timezone', $timezone)
            ->bind(':receivedPromotions', $receivePromo)
            ->bind(':utm_url', $utm_url)
            ->bind(':utm_source', $utm_source)
            ->bind(':utm_campaign', $utm_campaign)
            ->bind(':utm_medium', $utm_medium)
            ->bind(':utm_referer', $utm_referer)
            ->bind(':createdBy', $me)
            ->bind(':modifiedBy', $me)
            ->execute(Database::instance());
        // Sanity check
        $customerId = $result[0];

        // was everything done correctly?
        if ($result[0] <= 0) {
            throw new Exception("failed to add new customer.", 1);
        }

        // Now that they have registered, let's remove them from preCustomers.
        DB::update('preCustomers')->set(array('registered' => 1))->where('email', '=', $email)->execute();

        // Add initial customer IP
        $this->createIPAddress($customerId, $lastIP, $me);
        // Add initial phone number to associated phone numbers
        $this->createPhoneNumber($customerId, $cellphone);
        // Add initial email to associated emails
        $this->createEmail($customerId, $email);

        // Let's try to communicate with Authorize.net first, and come up with a CIM id:
        $config = Kohana::$config->load('config');
        $anetCimId = NULL;

        // All customers should be forcefully registered with anet
        // load the classes
        require_once Kohana::find_file('anet_php_sdk', 'AuthorizeNet');
        $request = new AuthorizeNetCIM;
        // echo Kohana::find_file('anet_php_sdk', 'AuthorizeNet'); die;
        
        // Create new customer profile
        $customerProfile = new AuthorizeNetCustomer;
        // $methods = get_class_methods($customerProfile);
        // print_r($methods); die;
        $customerProfile->description = $firstName . ' ' . $lastName;
        $customerProfile->merchantCustomerId = $customerId;
        $customerProfile->email = $email;
        // Send the command.
        
        $response = $request->createCustomerProfile($customerProfile);
        if ($response->isOk()) {
            // Very important note! Anet doesn't check for duplicate records! damn it
            $anetCimId = $response->getCustomerProfileId();
        } else {
            // Here we should probably error out
            $anetCimId = -1;
            throw new Exception("failed to register customer with anet", 1);
        }
        // Now we need to update the database to reference this number
        $sql = 'UPDATE customers SET anetCimId = :anetCimId WHERE customerId = :customerId';
        $result = DB::query(Database::UPDATE, $sql)->bind(':anetCimId', $anetCimId)->bind(':customerId', $customerId)->execute(Database::instance());

        // Done.
        return $customerId;
    }

    public function readForGSheetAll($limit = NULL)
    {
        $sql = 'SELECT c.email, 
             c.firstName, 
             c.lastName, 
             c.customerId, 
             IFNULL(c.cellphone, \'\') as cellphone,  
             c.active, 
             balance, 
             dpmsBalance, 
             address, 
             city, 
             c.createdAt, 
             lastLogin, 
             lastIP, 
             c.birthdate, ';
        // add tier logic
        $sql .= ' (SELECT COUNT(paymentId) FROM payments p WHERE p.success = 1 AND p.customerId = c.customerId ) AS raw_tier, anetCimId, c.receivePromotions, ccaOnFile, validIdOnFile, ';
        // coupons used and count
        $sql .= ' GROUP_CONCAT( IFNULL(pc.code, \'\')) AS coupons_used, COUNT(pc.code) AS coupon_count, ';
        // total spent
        $sql .= ' (SELECT SUM(amount) FROM payments p WHERE p.customerId = c.customerId AND p.success = 1) AS total_spent, ';
        // last purchase date
        $sql .= ' (SELECT p.createdAt FROM payments p WHERE p.customerId = c.customerId AND p.success = 1 ORDER BY p.createdAt DESC LIMIT 1 ) AS lastPurchasedDate, ';

        // if it is for the customers data report
//             if ($cd) {
        $sql .= ' timezone, state, country, c.createdAt, IFNULL(utm_url, \'\') as utm_url, utm_source, utm_campaign, utm_medium, utm_referer, c.inactiveReason, ';
        // total payout to psychics
        $sql .= ' (SELECT (sum(introPayout) + sum(normalPayout)) FROM callbacks cb WHERE cb.customerId = c.customerId AND lastStatus = "session_ended") AS total_payout, ';
        // total orders
        $sql .= ' (SELECT COUNT(callbackId) FROM callbacks cb WHERE cb.customerId = c.customerId) AS orders_count, ';
        // 1st purchase date
        $sql .= ' (SELECT p.createdAt FROM payments p WHERE p.customerId = c.customerId AND p.success = 1 ORDER BY p.createdAt ASC LIMIT 1) AS firstPurchasedDate, ';
        // 2nd purchase date
        $sql .= ' (SELECT p.createdAt FROM payments p WHERE p.customerId = c.customerId AND p.success = 1 ORDER BY p.createdAt ASC LIMIT 1, 1) AS secondPurchasedDate, ';
        // 1st reading duration
        $sql .= ' (SELECT duration FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" ORDER BY cb.createdAt ASC LIMIT 1) AS firstReadingDuration, ';
        // 2nd reading duration
        $sql .= ' (SELECT duration FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" ORDER BY cb.createdAt ASC LIMIT 1, 1) AS secondReadingDuration, ';
        // max reading duration
        $sql .= ' (SELECT duration FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" ORDER BY cb.duration DESC LIMIT 1) AS maxReadingDuration, ';
        // total reading duration
        $sql .= ' (SELECT SUM(duration) FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended") AS totalReadingDuration, ';
        // first reading date time
        $sql .= ' (SELECT cb.scheduledTime FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" ORDER BY cb.scheduledTime ASC LIMIT 1) AS firstReadingDT, ';
        // second reading date time
        $sql .= ' (SELECT cb.scheduledTime FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" ORDER BY cb.scheduledTime ASC LIMIT 1, 1) AS secondReadingDT, ';
        // last reading date time
        $sql .= ' (SELECT cb.scheduledTime FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" ORDER BY cb.scheduledTime DESC LIMIT 1) AS lastReadingDT, ';
        // first order date
        $sql .= ' (SELECT cb.createdAt FROM callbacks cb WHERE cb.customerId = c.customerId ORDER BY cb.createdAt ASC LIMIT 1) AS firstOrderDate, ';
        // last order date
        $sql .= ' (SELECT cb.createdAt FROM callbacks cb WHERE cb.customerId = c.customerId ORDER BY cb.createdAt DESC LIMIT 1) AS lastOrderDate, ';
        // total minutes of reading
        $sql .= ' (SELECT SUM(duration) FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended") AS total_minutes, ';
        // number of readings
        $sql .= ' (SELECT COUNT(callbackId) FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended") AS readings_count, ';
        // number of days with readings
        $sql .= ' (SELECT COUNT(DISTINCT(DATE(scheduledTime))) FROM callbacks WHERE customerId = c.customerId AND lastStatus = "session_ended") AS days_with_reading, ';
        // number of days with multimple readings
        $sql .= ' (SELECT COUNT(DISTINCT(DATE(scheduledTime))) FROM callbacks cb WHERE (SELECT COUNT(cba.scheduledTime) FROM callbacks cba WHERE cba.customerId = cb.customerId and cba.lastStatus = "session_ended" AND DATE(cba.scheduledTime) = DATE(cb.scheduledTime)) > 1 AND cb.customerId = c.customerId AND lastStatus = "session_ended") AS days_with_more_reading, ';
        // number of recharges
        $sql .= ' (SELECT COUNT(rechargeId) FROM recharges r WHERE r.customerId = c.customerId) AS recharges_count, ';
        // initial psychic
        $sql .= ' (SELECT CONCAT(nickName,"||",p.psychicId) FROM callbacks cb LEFT JOIN psychics p ON p.psychicId = cb.psychicId WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" ORDER BY cb.createdAt ASC LIMIT 1) AS initialPsychic, ';
        // last psychic
        $sql .= ' (SELECT CONCAT(nickName,"||",p.psychicId) FROM callbacks cb LEFT JOIN psychics p ON p.psychicId = cb.psychicId WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" ORDER BY cb.createdAt DESC LIMIT 1) AS lastPsychic, ';
        // first rating DT
        $sql .= ' IFNULL(
                    (SELECT cb.modifiedAt FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" AND rating IS NOT NULL ORDER BY cb.modifiedAt ASC LIMIT 1), 
                    \'\') AS firstRatingDT, ';
        // first rating value
        $sql .= ' IFNULL(
                    (SELECT cb.rating FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" AND rating IS NOT NULL ORDER BY cb.modifiedAt ASC LIMIT 1), 
                    \'\') AS firstRatingValue, ';
        // last rating DT
        $sql .= ' IFNULL(
                    (SELECT cb.modifiedAt FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" AND rating IS NOT NULL ORDER BY cb.modifiedAt DESC LIMIT 1), 
                    \'\') AS lastRatingDT, ';
        // last rating Value
        $sql .= ' IFNULL(
                    (SELECT cb.rating FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" AND rating IS NOT NULL ORDER BY cb.modifiedAt DESC LIMIT 1), 
                    \'\') AS lastRatingValue, ';
        // avg rating value
        $sql .= ' IFNULL(
                    (SELECT AVG(cb.rating) FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" AND rating IS NOT NULL),
                    \'\') AS avgRatingValue, ';
        // ratings count
        $sql .= ' IFNULL(
                    (SELECT COUNT(cb.callbackId) FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" AND rating IS NOT NULL), 
                    \'\') AS ratings_count, ';
//             }

        // total payments
        $sql .= ' (SELECT COUNT(p.paymentId) FROM payments p WHERE p.customerId = c.customerId AND p.success = 1) AS total_payments ';
        $sql .= ' FROM customers c ';
        $sql .= ' LEFT JOIN appliedPromotions ap ON (ap.customerId = c.customerId) ';
        $sql .= ' LEFT JOIN promotionalCodes pc ON (pc.promotionalCodeId = ap.promotionalCodeId) ';
        $sql .= ' WHERE archived = 0 ';

        $sql .= ' GROUP BY c.customerId ORDER BY c.createdAt ASC';

        if (!is_null($limit)) {
            $sql .= ' LIMIT ' . $limit;
        }


        // newsletter subscribers
        $nsql = 'SELECT customerEmail, createdAt FROM newsletterSubscribers WHERE status = 1';
        $ns = DB::query(Database::SELECT, $nsql)->execute(Database::instance())->as_array();
        // horoscope subscribers
        $hsql = 'SELECT customerEmail, type, createdAt FROM horoscopeSubscribers WHERE status = 1';
        $hs = DB::query(Database::SELECT, $hsql)->execute(Database::instance())->as_array();

        $customers_iterator = DB::query(Database::SELECT, $sql)->bind(':limit', $limit)->execute(Database::instance());

        // prep the results
        $customers = array();
        foreach ($customers_iterator as $cust_data) {
            $cust_data['tier'] = $this->tierLogic($cust_data['raw_tier']);
            // if customer data is required
                // at risk date
                $riskDate = NULL;
                // let's say the customer only had one order
                if (!is_null($cust_data['lastOrderDate']) and strpos($cust_data['lastOrderDate'], '0000-00-00') === false) {
                    $lastOrderDT = new DateTime($cust_data['lastOrderDate']);
                    // If customer only has 1 order date,  at risk date should be 395 days after first order date as per Arash
                    $riskDate = date('Y-m-d', strtotime('+395 Days', strtotime($cust_data['lastOrderDate'])));
                }
                // if there are more
                if ($cust_data['orders_count'] > 1) {
                    // validate
                    if (!is_null($cust_data['firstOrderDate']) and strpos($cust_data['firstOrderDate'], '0000-00-00') === false and !is_null($cust_data['lastOrderDate']) and strpos($cust_data['lastOrderDate'], '0000-00-00') === false) {
                        // get last order and first order
                        $dateDiff = date_diff(date_create($cust_data['lastOrderDate']), date_create($cust_data['firstOrderDate']));
                        $readingsCount = $cust_data['readings_count'] - 1;
                        // let's check
                        if ($dateDiff !== false and $readingsCount > 0) {
                            // new at risk date
                            $avgDaysBetweenOrders = $dateDiff->days / $readingsCount;
                            // let's compute the risk date now
                            $daysToLastOrder = ceil(1.25 * $avgDaysBetweenOrders);
                            // risk date
                            $riskDate = date('Y-m-d', strtotime('+' . $daysToLastOrder . ' Days', strtotime($cust_data['lastOrderDate'])));
                        }
                    }
                }
                $cust_data['atRiskDate'] = $riskDate;
                // subscriptions group
                $subscriptionsGroup = [];
                // newsletter subscription
                $cust_data['newsletterSubscribed'] = NULL;
                $cust_data['newsletterSubscribedDate'] = NULL;
                if (count($ns) > 0) {
                    // validate and tag true if it exists
                    $ns_key = array_search($cust_data['email'], array_column($ns, 'customerEmail'));
                    if ($ns_key !== false) {
                        // subscription group
                        $subscriptionsGroup[] = 'Newsletter with updates and special offers';
                        // newsletter flag
                        $cust_data['newsletterSubscribed'] = TRUE;
                        $cust_data['newsletterSubscribedDate'] = $ns[$ns_key]['createdAt'];
                    }
                }
                // horoscope subscription
                $cust_data['horoscopeSubscribed'] = NULL;
                $cust_data['horoscopeSubscribedDate'] = NULL;
                $cust_data['horoscopeType'] = NULL;
                if (count($hs) > 0) {
                    // validate and tag true with type if it exists
                    $hs_key = array_search($cust_data['email'], array_column($hs, 'customerEmail'));
                    if ($hs_key !== false) {
                        // subscription group
                        if (is_null($hs[$hs_key]['type']) or strlen($hs[$hs_key]['type']) == 0) {
                            if (is_null($subscriptionsGroup)) $subscriptionsGroup[] = 'Daily Horoscopes';
                        } else {
                            if (is_null($subscriptionsGroup)) $subscriptionsGroup[] = 'Weekly Horoscopes';
                        }
                        // horoscope flag
                        $cust_data['horoscopeSubscribed'] = TRUE;
                        $cust_data['horoscopeType'] = $hs[$hs_key]['type'];
                        $cust_data['horoscopeSubscribedDate'] = $hs[$hs_key]['createdAt'];
                    }
                }
                // subscriptions group
                $cust_data['subscriptionsGroup'] = $subscriptionsGroup;
                // avg amount for call
                $cust_data['avgAmountPerCall'] = ($cust_data['readings_count'] > 0) ? (number_format(($cust_data['total_minutes'] / $cust_data['readings_count']), 2)) : '0.00';
            $customers[] = $cust_data;
        }
        return $customers;
    }

    public function readForGSheet()
    {
        $sql = "SELECT email,  
                        firstName, 
                        lastName, 
                        customerId,
                        IFNULL(cellphone, ''),  
                        IFNULL(landphone,''), 
                        IFNULL(active,''), 
                        IFNULL(inactiveReason,''), 
                        IFNULL(PIN,''), 
                        IFNULL(birthdate,''), 
                        IFNULL(address,''), 
                        IFNULL(city,''), 
                        IFNULL(state,''), 
                        IFNULL(zipCode,''), 
                        IFNULL(country,''), 
                        IFNULL(timezone,''), 
                        IFNULL(createdAt,''), 
                        IFNULL(createdBy,''), 
                        IFNULL(lastLogin,''), 
                        IFNULL(balance,''), 
                        IFNULL(dpmsBalance,''), 
                        IFNULL(anetCimId,''), 
                        IFNULL(receivePromotions,''), 
                        IFNULL(ccaOnFile,''), 
                        IFNULL(validIdOnFile,''), 
                        IFNULL(utm_url,''), 
                        IFNULL(utm_source,''), 
                        IFNULL(utm_campaign,''), 
                        IFNULL(utm_medium,''), 
                        IFNULL(lastIP,'') 
                        FROM customers WHERE archived = 0 LIMIT 2";
        $results = DB::query(Database::SELECT, $sql)->execute(Database::instance())->as_array();
        foreach ($results as $key => $result) {
            $results[$key] = array_values($result);
        }

        return $results;
    }

    /**
     * Retrives information from the database based on id.
     * @param int $psychicId the id, null = error
     * @return array          psychic information
     */
    public function read($customerId = NULL)
    {
        if (is_null($customerId)) {
            throw new Exception("bad customer id", 1);
        }
        // need to check customerId
        $sql = 'SELECT customerId, firstName, lastName, cellphone, landphone, email, active, inactiveReason, PIN, birthdate, address, city, state, zipCode, country, timezone, createdAt, createdBy, lastLogin, balance, dpmsBalance, anetCimId, receivePromotions, ccaOnFile, validIdOnFile, utm_url, utm_source, utm_campaign, utm_medium, lastIP, takeTierNextPlan FROM customers WHERE customerId = :customerId AND archived = 0';
        $result = DB::query(Database::SELECT, $sql)->bind(':customerId', $customerId)->execute(Database::instance())->current();
        // if we don't have anything ...
        if (is_null($result)) return null;
        // we need to get the customer's tier and attach it

        $result['tier'] = $this->getCurrentTier($customerId);
        // print_r($result['tier']); die;
        $result['totalSpent'] = $this->getTotalSpent($customerId);
        $result['totalTransactionCount'] = $this->getTotalTransactionCount($customerId);
        $result['lastPurchaseDate'] = $this->getLastPurchaseDate($customerId);
        $result['phoneNumbers'] = $this->readPhoneNumberByCustomer($customerId);
        $result['emails'] = $this->readEmailByCustomer($customerId);
        return $result;
    }

    /**
     * Retrives password information from the database based on id.
     * @param int $customerId the id, null = error
     * @return array          customer password
     */
    public function getPassword($customerId = NULL)
    {
        if (is_null($customerId)) {
            throw new Exception("bad customer id", 1);
        }
        $sql = 'SELECT password FROM customers WHERE customerId = :customerId';
        return DB::query(Database::SELECT, $sql)->bind(':customerId', $customerId)->execute(Database::instance())->current();
    }

    /*
     * Creates an instance record of Customer IP
     * @param int $customerId
     * @param string $ip
     * @param int $createdBy
     */
    public function createIPAddress($customerId, $ip, $createdBy)
    {
        $sql = 'INSERT INTO customerIPs (customerId, ip, createdBy) VALUES (:customerId, :ip, :createdBy)';
        $result = DB::query(Database::INSERT, $sql)
            ->bind(':customerId', $customerId)
            ->bind(':ip', $ip)
            ->bind(':createdBy', $createdBy)
            ->execute(Database::instance());

        if ($result) {
            return $result[0];
        }
        return false;
    }

    /*
     * Returns all IP addresses of a Customer
     */
    public function ips($customerId)
    {
        $sql = 'SELECT * FROM customerIPs WHERE customerId = :customerId ORDER BY createdAt DESC';
        return DB::query(Database::SELECT, $sql)->bind(':customerId', $customerId)->execute(Database::instance())->as_array();
    }

    /**
     * Adds an entry to a customer's email list
     * @param customerId - the customerId
     * @param email - email to add
     * @param createdBy - user who added phone number
     */
    public function createEmail($customerId, $email)
    {

        // check for duplicate phone number first
        if ($this->readEmail($email)) return false;

        $sql = 'INSERT INTO customerEmails (customerId, email, createdBy) VALUES (:customerId, :email, :createdBy)';

        $sess = Session::instance();
        $createdBy = is_null($sess->get('nimdaId')) ? 0 : $sess->get('nimdaId');

        $result = DB::query(Database::INSERT, $sql)
            ->bind(':customerId', $customerId)
            ->bind(':email', $email)
            ->bind(':createdBy', $createdBy)
            ->execute(Database::instance());

        if ($result) {
            return $result[0];
        } else {
            return false;
        }
    }

    /**
     * Returns all Customer associated emails
     * @param int $customerId - Customer's ID
     * @return [type] [array]
     */
    public function getCustomerEmails($customerId)
    {
        $sql = 'SELECT email FROM customerEmails WHERE customerId = :customerId';
        return DB::query(Database::SELECT, $sql)->bind(':customerId', $customerId)->execute()->as_array();
    }

    /**
     * Adds an entry to a customer's phone number list
     * @param customerId - the customerId
     * @param phoneNumber - phone number to add
     * @param createdBy - user who added phone number
     */
    public function createPhoneNumber($customerId, $phoneNumber)
    {

        // check for duplicate phone number first
        if ($this->readPhoneNumber($phoneNumber)) return false;

        $sql = 'INSERT INTO customerPhoneNumbers (customerId, phoneNumber, createdBy) VALUES (:customerId, :phoneNumber, :createdBy)';

        // remove all non numeric characters from phoneNumber
        $phoneNumber = helper_functions::phoneCleanUp($phoneNumber);

        $sess = Session::instance();
        $createdBy = is_null($sess->get('nimdaId')) ? 0 : $sess->get('nimdaId');

        $result = DB::query(Database::INSERT, $sql)
            ->bind(':customerId', $customerId)
            ->bind(':phoneNumber', $phoneNumber)
            ->bind(':createdBy', $createdBy)
            ->execute(Database::instance());

        if ($result) {
            return $result[0];
        } else {
            return false;
        }
    }

    /**
     * Get a phone number from the phone number list
     * This is used for checking duplicates
     * @param phoneNumber - phone number to check
     */
    public function readEmail($email)
    {
        $sql = 'SELECT COUNT(*) cnt FROM customerEmails WHERE email = :email';

        $result = DB::query(Database::SELECT, $sql)
            ->bind(':email', $email)
            ->execute(Database::instance())
            ->current();

        return ($result['cnt'] > 0) ? true : false;
    }

    /**
     * Get a phone number from the phone number list
     * This is used for checking duplicates
     * @param phoneNumber - phone number to check
     */
    public function readPhoneNumber($phoneNumber)
    {
        $sql = 'SELECT COUNT(*) cnt FROM customerPhoneNumbers WHERE phoneNumber = :phoneNumber';

        // remove all non numeric characters from phoneNumber
        $phoneNumber = helper_functions::phoneCleanUp($phoneNumber);

        $result = DB::query(Database::SELECT, $sql)
            ->bind(':phoneNumber', $phoneNumber)
            ->execute(Database::instance())
            ->current();

        return ($result['cnt'] > 0) ? true : false;
    }

    /*
     * Return all Customer's Associated Phone Numbers
     * @param int $customerId - Customer's ID
     * @return [type] [description]
     */
    public function getCustomerPhoneNumbers($customerId)
    {
        $sql = 'SELECT phoneNumber FROM customerPhoneNumbers WHERE customerId = :customerId';
        return DB::query(Database::SELECT, $sql)->bind(':customerId', $customerId)->execute(Database::instance())->as_array();
    }

    /**
     * Get the emails associated with a customer
     * @param customerId - customer whose phone numbers will be retrieved
     */
    public function readEmailByCustomer($customerId)
    {
        $sql = 'SELECT email FROM customerEmails WHERE customerId = :customerId';

        $result = DB::query(Database::SELECT, $sql)
            ->bind(':customerId', $customerId)
            ->execute(Database::instance())
            ->as_array();

        return $result;

    }

    /**
     * Get the phone numbers associated with a customer
     * @param customerId - customer whose phone numbers will be retrieved
     */
    public function readPhoneNumberByCustomer($customerId)
    {
        $sql = 'SELECT phoneNumber FROM customerPhoneNumbers WHERE customerId = :customerId';

        $result = DB::query(Database::SELECT, $sql)
            ->bind(':customerId', $customerId)
            ->execute(Database::instance())
            ->as_array();

        return $result;

    }

    /**
     * Checks for various properties of a customer and displays them nicely. Such as: has a cc, has paid anything, has had a reading, etc
     * @param  [type] $customerId [description]
     * @return [type]             [description]
     */
    public function getBitState($customerId, $humanReadable = false)
    {
        // setup the general array
        $resp = array('active' => 0, 'hasPaymentMethod' => 0, 'hasPayment' => 0, 'hasCall' => 0, 'newNotes' => 0);
        // let's see if their account is active.
        $customer = $this->read($customerId);
        $resp['active'] = $customer['active'];
        // Let's see if they have a payment method on file.
        $pm_model = new model_financials_paymentmethods();
        $pms = $pm_model->allByCustomer($customerId);
        if (count($pms) > 0) {
            $resp['hasPaymentMethod'] = 1;
        }
        // let's see if they have a successful payment.
        $p_model = new model_financials_payments();
        $ps = $p_model->allByCustomer($customerId);
        foreach ($ps as $p) {
            if ($p['success'] == 1) {
                $resp['hasPayment'] = 1;
                // one is enough
                break;
            }
        }
        // do they have a successful call.
        $c_model = new model_calls_callbacks();
        $calls = $c_model->allBy($customerId);
        foreach ($calls as $call) {
            if ((int)$call['attempted'] == 1 and (strtotime($call['scheduledTime']) <= time()) and $call['lastStatus'] == 'session_ended') {
                $resp['hasCall'] = 1;
            }
        }

        // do they have a notes;
        $notes = $this->notes($customerId, NULL);
        if (count($notes) > 0) {
            $resp['newNotes'] = 1;
        }

        // convert to human readable
        if ($humanReadable) {
            $resp_human = ($resp['active']) ? '<div class="bitstate_ico phone active" title="Active"></div>' : '<div class="bitstate_ico phone inactive" title="Inactive"></div>';
            $resp_human .= ($resp['hasPaymentMethod']) ? '<div class="bitstate_ico credit_card active" title="Good Credit Card"></div>' : '<div class="bitstate_ico credit_card inactive" title="No Credit Card"></div>';
            $resp_human .= ($resp['hasPayment']) ? '<div class="bitstate_ico payment active" title="Had Payments"></div>' : '<div class="bitstate_ico payment inactive" title="No Payments"></div>';
            $resp_human .= ($resp['hasCall']) ? '<div class="bitstate_ico call active" title="Had Calls"></div>' : '<div class="bitstate_ico call inactive" title="No Calls"></div>';
            $resp_human .= ($resp['newNotes']) ? '<div class="bitstate_ico note active" title="Has notes"></div>' : '<div class="bitstate_ico note inactive" title="No notes"></div>';
            return $resp_human;
        }
        // no? okay
        return $resp;
    }
   // method for chnage status when we select checkbox as a regular price on listing page

    public function getNextTierPlan($customerId=null)
    {
        $sql = 'SELECT customerId, takeTierNextPlan FROM customers WHERE customerId = :customerId AND takeTierNextPlan = 1 '; 
        $result = DB::query(Database::SELECT, $sql)->bind(':customerId', $customerId)->execute(Database::instance())->current();
       if($result){
            return 9;
       }else{
         return false;
       }
    }
    /**
     * Validate existing customer email based on $email where email = $email AND customerId != $customerId
     * Update information from the database based on id
     * @params for customer information
     * @return bool(true) if success
     */
    public function update($customerId, $firstname, $lastname, $email, $phone, $birthdate, $timezone, $address, $city, $state, $zipcode, $country, $active, $inactiveReason, $receivePromotions)
    {
//        Minion_Task::factory(array('task' => 'syncsheet'))->execute();
        $sql = 'SELECT customerId, email FROM customers WHERE email = :email AND customerId != :customerId';
        $check = DB::query(Database::SELECT, $sql)
            ->bind(':email', $email)
            ->bind(':customerId', $customerId)
            ->execute(Database::instance())->count();

        if ($check == 0) {
            $sql = 'UPDATE customers SET firstname = :firstname, lastname = :lastname, email = :email, cellphone = :cellphone, birthdate = :birthdate, ';
            $sql .= ' timezone = :timezone, address = :address, city = :city, state = :state, zipcode = :zipcode, country = :country, active = :active, inactiveReason = :inactiveReason, receivePromotions = :receivePromotions';
            $sql .= ' WHERE customerId = :customerId';
            $result = DB::query(Database::UPDATE, $sql)
                ->bind(':birthdate', $birthdate)
                ->bind(':timezone', $timezone)
                ->bind(':cellphone', $phone)
                ->bind(':email', $email)
                ->bind(':lastname', $lastname)
                ->bind(':firstname', $firstname)
                ->bind(':address', $address)
                ->bind(':city', $city)
                ->bind(':state', $state)
                ->bind(':zipcode', $zipcode)
                ->bind(':country', $country)
                ->bind(':customerId', $customerId)
                ->bind(':active', $active)
                ->bind(':inactiveReason', $inactiveReason)
                ->bind(':receivePromotions', $receivePromotions)
                ->execute(Database::instance());

            // Add phone number to associated phone numbers if it changed
            $this->createPhoneNumber($customerId, $phone);
            return true;
        }


        return false;
    }

    /**
     * Validate if current password is correct
     * Update password from the database based on id if current password is correct and new password matches to confirm password
     * @params for customer current and new password
     * @return bool(true) if success
     */
    public function update_password($customerId, $current, $new)
    {
        $new_password = sha1($new);

        if (is_null($current)) {

            $sql = 'UPDATE customers SET password = :password WHERE customerId = :customerId';
            DB::query(Database::UPDATE, $sql)->bind(':password', $new_password)->bind(':customerId', $customerId)->execute(Database::instance());
            return true;

        } else {
            $current_password = sha1($current);

            $sql = 'SELECT customerId, password FROM customers WHERE password = :password AND customerId = :customerId';
            $check = DB::query(Database::SELECT, $sql)
                ->bind(':password', $current_password)
                ->bind(':customerId', $customerId)
                ->execute(Database::instance())->count();

            if ($check == 1) {
                $sql = 'UPDATE customers SET password = :password WHERE customerId = :customerId';
                $result = DB::query(Database::UPDATE, $sql)
                    ->bind(':password', $new_password)
                    ->bind(':customerId', $customerId)
                    ->execute(Database::instance());
                return true;
            }

        }

        return false;
    }

    /**
     *  Changes the PIN of the customer
     */
    public function change_pin($customerId, $pin)
    {

        $sql = 'UPDATE customers SET PIN = :PIN WHERE customerId = :customerId';
        DB::query(Database::UPDATE, $sql)->bind(':PIN', $pin)->bind(':customerId', $customerId)->execute(Database::instance());
        return true;
    }

    /**
     * Backs up customer data then deletes a customer data permanently.
     * @param  [type] $customerId    [description]
     * @param  [type] $modifiedBy [description]
     * @return [type]             [description]
     */
    public function delete($customerId, $modifiedBy = 0)
    {
        // Update the DB
        /*$sql = 'UPDATE customers SET active = 0, archived = 1, modifiedBy = :modifiedBy WHERE customerId = :customerId';
        DB::query(Database::UPDATE, $sql)->bind(':customerId', $customerId)->bind(':modifiedBy', $modifiedBy)->execute(Database::instance());*/

        // All Data
        $data = array();

        // Customer Info
        $data['info'] = $this->read($customerId);

        // Billing Logs
        $sqlBillingLogs = 'SELECT * FROM billingLogs WHERE callbackId IN (SELECT callbackId FROM callbacks WHERE customerId = :customerId)';
        $data['billingLogs'] = DB::query(Database::SELECT, $sqlBillingLogs)->bind(':customerId', $customerId)->execute(Database::instance())->as_array();

        // Callbacks
        $sqlCallbacks = 'SELECT * FROM callbacks WHERE customerId = :customerId';
        $data['callbacks'] = DB::query(Database::SELECT, $sqlCallbacks)->bind(':customerId', $customerId)->execute(Database::instance())->as_array();

        // Payments
        $sqlPayments = 'SELECT * FROM payments WHERE customerId = :customerId';
        $data['payments'] = DB::query(Database::SELECT, $sqlPayments)->bind(':customerId', $customerId)->execute(Database::instance())->as_array();

        // Balance Adjustments
        $sqlBalanceAdjustments = 'SELECT * FROM balanceAdjustments WHERE customerId = :customerId';
        $data['balanceAdjustments'] = DB::query(Database::SELECT, $sqlBalanceAdjustments)->bind(':customerId', $customerId)->execute(Database::instance())->as_array();

        // DPMS Balance Adjustments
        $sqlDPMSBalanceAdjustments = 'SELECT * FROM dpmsBalanceAdjustments WHERE customerId = :customerId';
        $data['dpmsBalanceAdjustments'] = DB::query(Database::SELECT, $sqlDPMSBalanceAdjustments)->bind(':customerId', $customerId)->execute(Database::instance())->as_array();

        // Applied Promotions
        $sqlAppliedPromotions = 'SELECT * FROM appliedPromotions WHERE customerId = :customerId';
        $data['appliedPromotions'] = DB::query(Database::SELECT, $sqlAppliedPromotions)->bind(':customerId', $customerId)->execute(Database::instance())->as_array();

        // Payment Methods
        $sqlPaymentMethods = 'SELECT * FROM paymentMethods WHERE customerId = :customerId';
        $data['paymentMethods'] = DB::query(Database::SELECT, $sqlPaymentMethods)->bind(':customerId', $customerId)->execute(Database::instance())->as_array();

        // Notes
        $sqlNotes = 'SELECT * FROM customerNotes WHERE customerId = :customerId';
        $data['customerNotes'] = DB::query(Database::SELECT, $sqlNotes)->bind(':customerId', $customerId)->execute(Database::instance())->as_array();

        // Associated Phone Numbers
        $sqlPhoneNumbers = 'SELECT * FROM customerPhoneNumbers WHERE customerId = :customerId';
        $data['phoneNumbers'] = DB::query(Database::SELECT, $sqlPhoneNumbers)->bind(':customerId', $customerId)->execute(Database::instance())->as_array();

        // Associated Emails
        $sqlEmails = 'SELECT * FROM customerEmails WHERE customerId = :customerId';
        $data['emails'] = DB::query(Database::SELECT, $sqlEmails)->bind(':customerId', $customerId)->execute(Database::instance())->as_array();

        $data = json_encode($data);

        // Insert into the deletedCustomers table first the customer data for back up
        $sql = 'INSERT INTO deletedCustomers (customerId, data, createdBy) VALUES(:customerId, :data, :createdBy)';
        DB::query(Database::INSERT, $sql)
            ->bind(':customerId', $customerId)
            ->bind(':data', $data)
            ->bind(':createdBy', $modifiedBy)
            ->execute(Database::instance());

        // then delete all...
        $sql = 'DELETE FROM billingLogs WHERE callbackId IN (SELECT callbackId FROM callbacks WHERE customerId = :customerId);';
        DB::query(Database::DELETE, $sql)->bind(':customerId', $customerId)->execute(Database::instance());

        $sql = 'DELETE FROM callbacks WHERE customerId = :customerId';
        DB::query(Database::DELETE, $sql)->bind(':customerId', $customerId)->execute(Database::instance());

        $sql = 'DELETE FROM payments WHERE customerId = :customerId';
        DB::query(Database::DELETE, $sql)->bind(':customerId', $customerId)->execute(Database::instance());

        $sql = 'DELETE FROM balanceAdjustments WHERE customerId = :customerId';
        DB::query(Database::DELETE, $sql)->bind(':customerId', $customerId)->execute(Database::instance());

        $sql = 'DELETE FROM dpmsBalanceAdjustments WHERE customerId = :customerId';
        DB::query(Database::DELETE, $sql)->bind(':customerId', $customerId)->execute(Database::instance());

        $sql = 'DELETE FROM appliedPromotions WHERE customerId = :customerId';
        DB::query(Database::DELETE, $sql)->bind(':customerId', $customerId)->execute(Database::instance());

        $sql = 'DELETE FROM paymentMethods WHERE customerId = :customerId';
        DB::query(Database::DELETE, $sql)->bind(':customerId', $customerId)->execute(Database::instance());

        $sql = 'DELETE FROM customerPhoneNumbers WHERE customerId = :customerId';
        DB::query(Database::DELETE, $sql)->bind(':customerId', $customerId)->execute(Database::instance());

        $sql = 'DELETE FROM customerEmails WHERE customerId = :customerId';
        DB::query(Database::DELETE, $sql)->bind(':customerId', $customerId)->execute(Database::instance());

        $sql = 'DELETE FROM customerNotes WHERE customerId = :customerId';
        DB::query(Database::DELETE, $sql)->bind(':customerId', $customerId)->execute(Database::instance());

        $sql = 'DELETE FROM customers WHERE customerId = :customerId';
        DB::query(Database::DELETE, $sql)->bind(':customerId', $customerId)->execute(Database::instance());
    }

    /**
     * Activates a user by setting their active flag to 1
     * @param  [type] $customerId    [description]
     * @param  [type] $modifiedBy [description]
     * @return [type]             [description]
     */
    public function activate($customerId, $modifiedBy)
    {
        // Update the DB
        $sql = 'UPDATE customers SET active = 1, modifiedBy = :modifiedBy WHERE customerId = :customerId';
        DB::query(Database::UPDATE, $sql)->bind(':customerId', $customerId)->bind(':modifiedBy', $modifiedBy)->execute(Database::instance());
    }

    /**
     * De-activates a user by setting their active flag to 0.
     * @param  [type] $customerId    [description]
     * @param  [type] $modifiedBy [description]
     * @return [type]             [description]
     */
    public function deactivate($customerId, $modifiedBy)
    {
        // Update the DB
        $sql = 'UPDATE customers SET active = 0, modifiedBy = :modifiedBy WHERE customerId = :customerId';
        DB::query(Database::UPDATE, $sql)->bind(':customerId', $customerId)->bind(':modifiedBy', $modifiedBy)->execute(Database::instance());
    }

    /**
     * Calculates current customer tier based on their previous purchases and payments.
     * @param  [type] $customerId [description]
     * @param  [type] $paymentId If present, exclude this paymentId
     * @return [type]             [description]
     */
    public function getCurrentTier($customerId, $paymentId = NULL)
    {
        // Method one, bind tier to the amount of
        $sql = 'SELECT COUNT(*) AS num FROM payments WHERE customerId = :customerId AND success = 1 '; 
         // should add AND refunded = 0
        // $sql = 'SELECT COUNT(*) AS num FROM payments p INNER JOIN customers c ON p.customerId = c.customerId WHERE p.customerId = :p.customerId  AND c.customerId = :c.customerId OR success = 1 OR c.takeTierNextPlan = 1'; 
        if (!is_null($paymentId)) {
            $sql .= ' AND paymentId != :paymentId';
        }
        
        // $num = DB::query(Database::SELECT, $sql)->bind(':p.customerId', $customerId)->bind(':c.customerId', $customerId)->bind(':paymentId', $paymentId)->execute(Database::instance())->current(); 
        $num = DB::query(Database::SELECT, $sql)->bind(':customerId', $customerId)->bind(':paymentId', $paymentId)->execute(Database::instance())->current();

        // Method one, check the plan is regular or not 
         $sql1 = 'SELECT COUNT(*) AS num1 FROM customers WHERE customerId = :customerId AND takeTierNextPlan = 1 '; 
         $num1 = DB::query(Database::SELECT, $sql1)->bind(':customerId', $customerId)->bind(':paymentId', $paymentId)->execute(Database::instance())->current();
         $num = $num['num'];

         if($num1['num1'] != 0){
            $num = $num1['num1'];
         }
        return $this->tierLogic($num);
    }

    private function tierLogic($num_payments)
    {
        // Here is our Tier logic
        // If they don't have any purchases with us, their are new customers and tier is 1
        if ($num_payments < 1) {
            return 1;
        }
        // // One successful purchase results in second sale story
        if ($num_payments == 1) {
            // As of March 2nd, 2015 tier 2 is removed and we consider them full
            return 9;
        }
        // Other than this is considered a normal tier
        return 9;
    }

    /* Get the Customer's total spent */
    public function getTotalSpent($customerId)
    {
        $sql = 'SELECT SUM(amount) as total_spent FROM payments WHERE customerId = :customerId AND success = 1';
        $total = DB::query(Database::SELECT, $sql)->bind(':customerId', $customerId)->execute(Database::instance())->current();
        if (is_null($total['total_spent'])) {
            return '0.00';
        }
        return $total['total_spent'];
    }

    /* Get the Customer's total transaction count */
    public function getTotalTransactionCount($customerId)
    {
        $sql = 'SELECT COUNT(paymentId) as total_transaction_count FROM payments WHERE customerId = :customerId AND success = 1';
        $total = DB::query(Database::SELECT, $sql)->bind(':customerId', $customerId)->execute(Database::instance())->current();
        if (is_null($total['total_transaction_count']) or $total['total_transaction_count'] < 1) {
            return 0;
        }
        return $total['total_transaction_count'];
    }

    /* Get the Customer's last purchase date */
    public function getLastPurchaseDate($customerId)
    {
        $sql = 'SELECT createdAt FROM payments WHERE success = 1 AND customerId = :customerId ORDER BY createdAt DESC LIMIT 1';
        $result = DB::query(Database::SELECT, $sql)->bind(':customerId', $customerId)->execute(Database::instance())->current();
        if ($result && $result['createdAt'] && !is_null($result['createdAt'])) {
            return $result['createdAt'];
        }
        return false;
    }

    #################
    #### CRUD AUX ###
    #################

    /*
     * Returns a list of all non-deleted customers
     * @param int $limit     limit of customers to show, null means all
     * @param int $offset    used in conjuction with limit
     * @param int $count     returns the number of records regardless of LIMIT
     *
     */
    public function all($limit = NULL, $offset = NULL, &$count = NULL, $cd = false, $date = NULL, $active = true, $receivePromotions = true)
    {
        $sql = 'SELECT c.customerId, c.firstName, c.lastName, c.email, cellphone, c.active, balance, dpmsBalance, address, city, c.createdAt, lastLogin, lastIP, c.birthdate, ';
        // add tier logic
        $sql .= ' (SELECT COUNT(paymentId) FROM payments p WHERE p.success = 1 AND p.customerId = c.customerId ) AS raw_tier, anetCimId, c.receivePromotions, ccaOnFile, validIdOnFile, ';
        // coupons used and count
        $sql .= ' GROUP_CONCAT(pc.code) AS coupons_used, COUNT(pc.code) AS coupon_count, ';
        // total spent
        $sql .= ' (SELECT SUM(amount) FROM payments p WHERE p.customerId = c.customerId AND p.success = 1) AS total_spent, ';
        // last purchase date
        $sql .= ' (SELECT p.createdAt FROM payments p WHERE p.customerId = c.customerId AND p.success = 1 ORDER BY p.createdAt DESC LIMIT 1 ) AS lastPurchasedDate, ';

        // if it is for the customers data report
        if ($cd) {
            $sql .= ' timezone, state, country, c.createdAt, utm_url, utm_source, utm_campaign, utm_medium, utm_referer, c.inactiveReason, ';
            // total payout to psychics
            $sql .= ' (SELECT (sum(introPayout) + sum(normalPayout)) FROM callbacks cb WHERE cb.customerId = c.customerId AND lastStatus = "session_ended") AS total_payout, ';
            // total orders
            $sql .= ' (SELECT COUNT(callbackId) FROM callbacks cb WHERE cb.customerId = c.customerId) AS orders_count, ';
            // 1st purchase date
            $sql .= ' (SELECT p.createdAt FROM payments p WHERE p.customerId = c.customerId AND p.success = 1 ORDER BY p.createdAt ASC LIMIT 1) AS firstPurchasedDate, ';
            // 2nd purchase date
            $sql .= ' (SELECT p.createdAt FROM payments p WHERE p.customerId = c.customerId AND p.success = 1 ORDER BY p.createdAt ASC LIMIT 1, 1) AS secondPurchasedDate, ';
            // 1st reading duration
            $sql .= ' (SELECT duration FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" ORDER BY cb.createdAt ASC LIMIT 1) AS firstReadingDuration, ';
            // 2nd reading duration
            $sql .= ' (SELECT duration FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" ORDER BY cb.createdAt ASC LIMIT 1, 1) AS secondReadingDuration, ';
            // max reading duration
            $sql .= ' (SELECT duration FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" ORDER BY cb.duration DESC LIMIT 1) AS maxReadingDuration, ';
            // total reading duration
            $sql .= ' (SELECT SUM(duration) FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended") AS totalReadingDuration, ';
            // first reading date time
            $sql .= ' (SELECT cb.scheduledTime FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" ORDER BY cb.scheduledTime ASC LIMIT 1) AS firstReadingDT, ';
            // second reading date time
            $sql .= ' (SELECT cb.scheduledTime FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" ORDER BY cb.scheduledTime ASC LIMIT 1, 1) AS secondReadingDT, ';
            // last reading date time
            $sql .= ' (SELECT cb.scheduledTime FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" ORDER BY cb.scheduledTime DESC LIMIT 1) AS lastReadingDT, ';
            // first order date
            $sql .= ' (SELECT cb.createdAt FROM callbacks cb WHERE cb.customerId = c.customerId ORDER BY cb.createdAt ASC LIMIT 1) AS firstOrderDate, ';
            // last order date
            $sql .= ' (SELECT cb.createdAt FROM callbacks cb WHERE cb.customerId = c.customerId ORDER BY cb.createdAt DESC LIMIT 1) AS lastOrderDate, ';
            // total minutes of reading
            $sql .= ' (SELECT SUM(duration) FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended") AS total_minutes, ';
            // number of readings
            $sql .= ' (SELECT COUNT(callbackId) FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended") AS readings_count, ';
            // number of days with readings
            $sql .= ' (SELECT COUNT(DISTINCT(DATE(scheduledTime))) FROM callbacks WHERE customerId = c.customerId AND lastStatus = "session_ended") AS days_with_reading, ';
            // number of days with multimple readings
            $sql .= ' (SELECT COUNT(DISTINCT(DATE(scheduledTime))) FROM callbacks cb WHERE (SELECT COUNT(cba.scheduledTime) FROM callbacks cba WHERE cba.customerId = cb.customerId and cba.lastStatus = "session_ended" AND DATE(cba.scheduledTime) = DATE(cb.scheduledTime)) > 1 AND cb.customerId = c.customerId AND lastStatus = "session_ended") AS days_with_more_reading, ';
            // number of recharges
            $sql .= ' (SELECT COUNT(rechargeId) FROM recharges r WHERE r.customerId = c.customerId) AS recharges_count, ';
            // initial psychic
            $sql .= ' (SELECT CONCAT(nickName,"||",p.psychicId) FROM callbacks cb LEFT JOIN psychics p ON p.psychicId = cb.psychicId WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" ORDER BY cb.createdAt ASC LIMIT 1) AS initialPsychic, ';
            // last psychic
            $sql .= ' (SELECT CONCAT(nickName,"||",p.psychicId) FROM callbacks cb LEFT JOIN psychics p ON p.psychicId = cb.psychicId WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" ORDER BY cb.createdAt DESC LIMIT 1) AS lastPsychic, ';
            // first rating DT
            // $sql .= ' (SELECT  IFNULL(c.cellphone, \'\')cb.modifiedAt FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" AND rating IS NOT NULL ORDER BY cb.modifiedAt ASC LIMIT 1) AS firstRatingDT, ';

             $sql .= ' (SELECT  cb.rating FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" AND rating IS NOT NULL ORDER BY cb.modifiedAt ASC LIMIT 1) AS firstRatingDT, ';
            // first rating value
            $sql .= ' (SELECT cb.rating FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" AND rating IS NOT NULL ORDER BY cb.modifiedAt ASC LIMIT 1) AS firstRatingValue, ';
            // last rating DT
            $sql .= ' (SELECT cb.modifiedAt FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" AND rating IS NOT NULL ORDER BY cb.modifiedAt DESC LIMIT 1) AS lastRatingDT, ';
            // last rating Value
            $sql .= ' (SELECT cb.rating FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" AND rating IS NOT NULL ORDER BY cb.modifiedAt DESC LIMIT 1) AS lastRatingValue, ';
            // avg rating value
            $sql .= ' (SELECT AVG(cb.rating) FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" AND rating IS NOT NULL) AS avgRatingValue, ';
            // ratings count
            $sql .= ' (SELECT COUNT(cb.callbackId) FROM callbacks cb WHERE cb.customerId = c.customerId AND cb.lastStatus = "session_ended" AND rating IS NOT NULL) AS ratings_count, ';
        }

        // total payments
        $sql .= ' (SELECT COUNT(p.paymentId) FROM payments p WHERE p.customerId = c.customerId AND p.success = 1) AS total_payments ';
        $sql .= ' FROM customers c ';
        $sql .= ' LEFT JOIN appliedPromotions ap ON (ap.customerId = c.customerId) ';
        $sql .= ' LEFT JOIN promotionalCodes pc ON (pc.promotionalCodeId = ap.promotionalCodeId) ';
        $sql .= ' WHERE archived = 0 ';
       
        if ($active == false) {
            $rp = ($receivePromotions == false) ? ' OR c.receivePromotions = 0' : '';
            $sql .= ' AND (c.active = 0' . $rp . ') ';
        }

        if (!is_null($date)) {
            $sql .= ' AND (DATE(c.createdAt) >= "' . $date . '" OR DATE(c.modifiedAt) >= "' . $date . '") ';
        }

        $sql .= ' GROUP BY c.customerId ORDER BY c.createdAt DESC';

        if (!is_null($limit)) {
            $sql .= ' LIMIT ' . $limit;
        }

        if (!is_null($offset)) {
            $sql .= ', ' . $offset;
        }

        // newsletter subscribers
        $nsql = 'SELECT customerEmail, createdAt FROM newsletterSubscribers WHERE status = 1';
        $ns = DB::query(Database::SELECT, $nsql)->execute(Database::instance())->as_array();
        // horoscope subscribers
        $hsql = 'SELECT customerEmail, type, createdAt FROM horoscopeSubscribers WHERE status = 1';
        $hs = DB::query(Database::SELECT, $hsql)->execute(Database::instance())->as_array();

        $customers_iterator = DB::query(Database::SELECT, $sql)->bind(':limit', $limit)->execute(Database::instance());
        // prep the results
        $customers = array();
        foreach ($customers_iterator as $cust_data) {
            $cust_data['tier'] = $this->tierLogic($cust_data['raw_tier']);
            // if customer data is required
            if ($cd) {
                // at risk date
                $riskDate = NULL;
                // let's say the customer only had one order
                if (!is_null($cust_data['lastOrderDate']) and strpos($cust_data['lastOrderDate'], '0000-00-00') === false) {
                    $lastOrderDT = new DateTime($cust_data['lastOrderDate']);
                    // If customer only has 1 order date,  at risk date should be 395 days after first order date as per Arash
                    $riskDate = date('Y-m-d', strtotime('+395 Days', strtotime($cust_data['lastOrderDate'])));
                }
                // if there are more
                if ($cust_data['orders_count'] > 1) {
                    // validate
                    if (!is_null($cust_data['firstOrderDate']) and strpos($cust_data['firstOrderDate'], '0000-00-00') === false and !is_null($cust_data['lastOrderDate']) and strpos($cust_data['lastOrderDate'], '0000-00-00') === false) {
                        // get last order and first order
                        $dateDiff = date_diff(date_create($cust_data['lastOrderDate']), date_create($cust_data['firstOrderDate']));
                        $readingsCount = $cust_data['readings_count'] - 1;
                        // let's check
                        if ($dateDiff !== false and $readingsCount > 0) {
                            // new at risk date
                            $avgDaysBetweenOrders = $dateDiff->days / $readingsCount;
                            // let's compute the risk date now
                            $daysToLastOrder = ceil(1.25 * $avgDaysBetweenOrders);
                            // risk date
                            $riskDate = date('Y-m-d', strtotime('+' . $daysToLastOrder . ' Days', strtotime($cust_data['lastOrderDate'])));
                        }
                    }
                }
                $cust_data['atRiskDate'] = $riskDate;
                // subscriptions group
                $subscriptionsGroup = [];
                // newsletter subscription
                $cust_data['newsletterSubscribed'] = NULL;
                $cust_data['newsletterSubscribedDate'] = NULL;
                if (count($ns) > 0) {
                    // validate and tag true if it exists
                    $ns_key = array_search($cust_data['email'], array_column($ns, 'customerEmail'));
                    if ($ns_key !== false) {
                        // subscription group
                        $subscriptionsGroup[] = 'Newsletter with updates and special offers';
                        // newsletter flag
                        $cust_data['newsletterSubscribed'] = TRUE;
                        $cust_data['newsletterSubscribedDate'] = $ns[$ns_key]['createdAt'];
                    }
                }
                // horoscope subscription
                $cust_data['horoscopeSubscribed'] = NULL;
                $cust_data['horoscopeSubscribedDate'] = NULL;
                $cust_data['horoscopeType'] = NULL;
                if (count($hs) > 0) {
                    // validate and tag true with type if it exists
                    $hs_key = array_search($cust_data['email'], array_column($hs, 'customerEmail'));
                    if ($hs_key !== false) {
                        // subscription group
                        if (is_null($hs[$hs_key]['type']) or strlen($hs[$hs_key]['type']) == 0) {
                            if (is_null($subscriptionsGroup)) $subscriptionsGroup[] = 'Daily Horoscopes';
                        } else {
                            if (is_null($subscriptionsGroup)) $subscriptionsGroup[] = 'Weekly Horoscopes';
                        }
                        // horoscope flag
                        $cust_data['horoscopeSubscribed'] = TRUE;
                        $cust_data['horoscopeType'] = $hs[$hs_key]['type'];
                        $cust_data['horoscopeSubscribedDate'] = $hs[$hs_key]['createdAt'];
                    }
                }
                // subscriptions group
                $cust_data['subscriptionsGroup'] = $subscriptionsGroup;
                // avg amount for call
                $cust_data['avgAmountPerCall'] = ($cust_data['readings_count'] > 0) ? (number_format(($cust_data['total_minutes'] / $cust_data['readings_count']), 2)) : '0.00';
            }
            $customers[] = $cust_data;
        }

        $count = DB::query(Database::SELECT, 'SELECT COUNT(*) c FROM customers WHERE archived = 0')->execute(Database::instance())->current();
        $count = is_null($count['c']) ? 0 : $count['c'];
        return $customers;
    }


    /**
     * Grabs a customer from the DB using the uniq phone number
     * @param string $cellphone cellphone number
     * @param int $customerId - Customer's ID
     * @return [type]            [description]
     */
    public function getCustomerByCellphone($cellphone = NULL, $customerId = NULL)
    {
        if (is_null($cellphone)) {
            die('Code error in getCustomerByCellphone function.');
        }
        // need to check cellphone
        $sql = 'SELECT customerId FROM customerPhoneNumbers WHERE phoneNumber = :cellphone';
        // check for other's number instead if customerId is not null
        if (!is_null($customerId)) {
            $sql .= ' AND customerId != :customerId';
        }
        $c = DB::query(Database::SELECT, $sql)->bind(':cellphone', $cellphone)->bind(':customerId', $customerId)->execute(Database::instance())->current();
        return (is_null($c)) ? NULL : $this->read($c['customerId']);
    }

    /*
     * Grabs customers from the DB using the unique cellphone number
     * @param string $cellphone - Cellphone number
     * @param int $customerId - Customer's ID
     * @return [type] [description]
     */
    public function getCustomersPrimaryCellphone($cellphone = NULL, $customerId = NULL)
    {
        $sql = 'SELECT customerId FROM customers WHERE cellphone = :cellphone';
        if (!is_null($customerId)) {
            $sql .= ' AND customerId != :customerId';
        }
        $result = DB::query(Database::SELECT, $sql)->bind(':cellphone', $cellphone)->bind(':customerId', $customerId)->execute(Database::instance())->as_array();
        if (count($result) > 0) {
            return $result;
        }
        return NULL;
    }

    /**
     * Grabs customers from the DB using the uniq email address
     * @param string $email cellphone number
     * @param int $customerId - Customer's ID
     * @return [type]            [description]
     */
    public function getCustomersPrimaryEamil($email = NULL, $customerId = NULL)
    {
        $sql = 'SELECT customerId FROM customers WHERE email = :email';
        if (!is_null($customerId)) {
            $sql .= ' AND customerId != :customerId';
        }
        $result = DB::query(Database::SELECT, $sql)->bind(':email', $email)->bind(':customerId', $customerId)->execute(Database::instance())->as_array();
        if (count($result) > 0) {
            return $result;
        }
        return NULL;
    }

    /**
     * Replaces Customer Main Number with an Assoc one
     * @param int $customerId - Customer's ID
     * @param string $cellphone - New Main Cellphone Number
     * @return [type]            [description]
     */
    public function switchCustomerPhone($customerId, $cellphone)
    {
        // check primary numbers
        if (!is_null($this->getCustomersPrimaryCellphone($cellphone, $customerId))) {
            return false;
        }
        // check associated numbers
        if (!is_null($this->getCustomerByCellphone($cellphone, $customerId))) {
            return false;
        }
        $sql = 'UPDATE customers SET cellphone = :cellphone WHERE customerId = :customerId';
        DB::query(Database::UPDATE, $sql)->bind(':cellphone', $cellphone)->bind(':customerId', $customerId)->execute(Database::instance());
        return true;
    }

    /**
     * Replaces Customer Main Email with an Assoc one
     * @param int $customerId - Customer's ID
     * @param string $email - New Main Email Address
     * @return [type]            [description]
     */
    public function switchCustomerEmail($customerId, $email)
    {
        // check primary numbers
        if (!is_null($this->getCustomersPrimaryEamil($email, $customerId))) {
            return false;
        }
        // check associated numbers
        if (!is_null($this->getCustomerByEmail($email, $customerId))) {
            return false;
        }
        $sql = 'UPDATE customers SET email = :email WHERE customerId = :customerId';
        DB::query(Database::UPDATE, $sql)->bind(':email', $email)->bind(':customerId', $customerId)->execute(Database::instance());
        return true;
    }

    /*
     * Retrieve a customer's record based from email
     * @param string $email - Customer email
     * @return [type] [description]
     */
    public function getCustomerByEmail($email, $customerId = NULL)
    {
        // need to check cellphone
        $sql = 'SELECT customerId FROM customers WHERE email = :email AND active = 1';
        $c = DB::query(Database::SELECT, $sql)->bind(':email', $email)->execute(Database::instance())->current();
        if (is_null($c)) {

            $sql = 'SELECT customerId FROM customerEmails WHERE email = :email ';
            if (!is_null($customerId)) {
                $sql .= ' AND customerId != :customerId';
            }
            $c = DB::query(Database::SELECT, $sql)->bind(':email', $email)->bind(':customerId', $customerId)->execute(Database::instance())->current();
            return (is_null($c)) ? NULL : $this->read($c['customerId']);

        } else {
            return $this->read($c['customerId']);
        }
    }

    /**
     * Checks that if a customer exist in the system
     * @param string $customerId customerId
     * @return int            number. If greater than zero means a success.
     */
    public function customerIdExists($customerId)
    {
        $sql = 'SELECT COUNT(*) AS c FROM customers WHERE customerId = :customerId';
        $c = DB::query(Database::SELECT, $sql)
            ->bind(':customerId', $customerId)
            ->execute(Database::instance())->current();

        return ($c['c'] > 0) ? true : false; // true or false
    }

    /**
     * Checks that if a customer exist in the system, keyed by email address
     * @param string $email customer email
     * @return int            number. If greater than zero means a success.
     */
    public function emailExists($email)
    {
        $sql = 'SELECT COUNT(*) AS c FROM customers WHERE email = :email';
        $c = DB::query(Database::SELECT, $sql)
            ->bind(':email', $email)
            ->execute(Database::instance())->current();

        return ($c['c'] > 0) ? true : false; // true or false
    }


    /**
     * Checks that if a customer exist in the system, keyed by cellphone or email address
     * @param string $email customer email
     * @param string $cellphone customer cellphone / primary phone
     * @return int            number. If greater than zero means a success.
     */
    public function exists($email, $cellphone, $customerId = NULL)
    {
        $sql = 'SELECT COUNT(*) AS c FROM customers WHERE';
        if (!is_null($customerId)) {
            $sql .= ' ((SELECT count(*) FROM customerEmails WHERE email = :email AND customerId != :customerId) > 0 OR email = :email OR (SELECT count(*) FROM customerPhoneNumbers WHERE phoneNumber = :cellphone AND customerId != :customerId) > 0 OR cellphone = :cellphone) AND customerId != :customerId';
        } else {
            $sql .= ' ((SELECT count(*) FROM customerEmails WHERE email = :email) > 0 OR email = :email OR (SELECT count(*) FROM customerPhoneNumbers WHERE phoneNumber = :cellphone) > 0 OR cellphone = :cellphone)';
        }
        $c = DB::query(Database::SELECT, $sql)->bind(':email', $email)->bind(':cellphone', $cellphone)->bind(':customerId', $customerId)->execute(Database::instance())->current();

        return ($c['c'] > 0) ? true : false; // true or false
    }

    ################
    #### Login   ###
    ################

    /*
     * Validation of email and password if has a match on the customers table
     * @param string $email - email of the customer
     * @param string $password - password of the customer
     */
    public function checkAuth($email = NULL, $password = NULL)
    {
        // validate this
        if (is_null($email) or is_null($password)) {
            return -2;
        }
        // encrypt the passwd
        $password = sha1($password);
        // Check against the database
        $sql = 'SELECT customerId FROM customers WHERE email=:email AND password=:password';
        $c = DB::query(Database::SELECT, $sql)->bind(':email', $email)->bind(':password', $password)->execute(Database::instance())->current();

        /*if(!is_null($c)){
          $lastIP = helper_functions::getIP();
          $sql = 'UPDATE customers SET lastIP = :lastIP WHERE customerId = :customerId';
          DB::query(Database::UPDATE, $sql)->bind(':lastIP', $lastIP)->bind(':customerId', $c['customerId'])->execute(Database::instance());
        }*/
        // done
        return (is_null($c)) ? NULL : $this->read($c['customerId']);
    }

    /*
     * Set the Session variables for the customer that will be logged in
     */
    public function doLogin($customer = NULL)
    {
        // security check
        $trace = debug_backtrace();
        array_shift($trace);
        $caller = array_shift($trace);
        $calling_method = $caller['function'];
        if (!in_array($calling_method, array('action_register', 'action_login'))) {
            //throw new Exception('We cant let u use this function :)' . $calling_method, 1);
        }
        // sanity cheeck
        if (is_null($customer) or is_null($customer['customerId'])) {
            throw new Exception("Requesting to login a non-customer!", 1);
        }

        // Fire up the session
        $sess = Session::instance();

        // setup the session values
        $sess->set('customerId', (int)$customer['customerId'])
            ->set('email', $customer['email'])
            ->set('active', 1)
            ->set('firstName', $customer['firstName'])
            ->set('lastName', $customer['lastName'])
            ->set('balance', $customer['balance'])
            ->set('dpmsBalance', $customer['dpmsBalance'])
            ->set('timezone', $customer['timezone'])
            ->set('tier', (int)$customer['tier']);

        // Stamp Last Login
        $this->stampLastLogin($customer['customerId']);

        // register IP address
        $lastIP = helper_functions::getIP();
        $this->createIPAddress((int)$customer['customerId'], $lastIP, (int)$customer['customerId']);

        // apply last IP on customer record
        $sql = 'UPDATE customers SET lastIP = :lastIP WHERE customerId = :customerId';
        DB::query(Database::UPDATE, $sql)->bind(':lastIP', $lastIP)->bind(':customerId', $customer['customerId'])->execute(Database::instance());

        return false;
    }

    ##################
    ### Last Login ###
    ##################
    /*
     * Updates a Customer's Last Login
     * @param int $customerId - Customer's ID
     */
    public function stampLastLogin($customerId)
    {
        $sql = 'UPDATE customers SET lastLogin = NOW() WHERE customerId = :customerId';
        DB::query(Database::UPDATE, $sql)->bind(':customerId', $customerId)->execute(Database::instance());
    }

    /*
     * Set customer Password
     * @param int $customerId - Customer's ID
     */
    public function customerSetPassword($customerId = NULL)
    {
        if (is_null($customerId)) {
            throw new Exception('cant find customer', 1);
        }
        // load up model
        $about_model = new model_pages_about();

        $customer = $this->read($customerId);

        // Prepare the email body
        $resetPasswordLink = URL::base() . 'customers/resetpw/' . strtotime(date('Y-m-d')) . $customer['customerId'];
        $resetPasswordView = View::factory('customers/email_reset_password');
        $resetPasswordView->set('name', $customer['firstName'])->set('fromNimda', true)->set('link', $resetPasswordLink);
        // Send email
        helper_functions::sendEmail($customer['email'], 'Set your password for www.psychicelements.com!', $resetPasswordView->render());
        // Save it on the communicationLog
        $about_model->create($customer['customerId'], 'no-reply@psychicelements.com', $customer['email'], $customer['cellphone'], $customer['firstName'], $resetPasswordView->render());
    }

    ###########################
    #### Financial & Money  ###
    ###########################

    /**
     * Adds a balance to user's account.
     * @param int $me id of who modified the account, default 0, system
     * @param int $customerId customer Id
     * @param int $amount dollar amount
     */
    public function addBalance($me, $customerId, $amount)
    {
        // check the customer's balance
        $customer = $this->read($customerId);
        if (!is_null($customer) and $amount > 0.00) {
            // add to notes
            $note = 'Added/Subtracted $' . $amount . ' from the current balance of $' . $customer['balance'];
            $this->addNote($customer['customerId'], $note, 'regular', 0, $me);
        }

        $sql = 'UPDATE customers SET balance = (balance + :balance), modifiedBy = :modifiedBy WHERE customerId = :customerId';
        $result = DB::query(Database::UPDATE, $sql)
            ->bind(':balance', $amount)
            ->bind(':modifiedBy', $me)
            ->bind(':customerId', $customerId)
            ->execute(Database::instance());

        // let's re-fetch the customer data
        $re_customer = $this->read($customerId);

        if (!is_null($re_customer)) {
            if ($re_customer['balance'] < 0) {
                $body = 'Hi CSR,<br/><br/>';
                $body .= 'Customer ' . $re_customer['firstName'] . ' ' . $re_customer['lastName'] . '(' . $re_customer['customerId'] . ') obtained a negative balance.<br/>';
                $body .= 'Customer\'s current balance is $' . $re_customer['balance'] . ' and ' . $re_customer['dpmsBalance'] . ' minutes.</br/>';
                $body .= 'Please check the customer\'s last transaction(Recharge, Booked Call / Appointment, Manage Payments).<br/><br/>';
                $body .= 'Kindly contact Dev Team if in need of assistance.';
                // email agents
                @helper_functions::emailAdmins('[Negative Balance] A customer obtained a negative balance.', $body);
            }
        }

        return true;
    }

    /**
     * Deducts balance from custoemr account. If force is true, allow for negative balances.
     * @param  [type]  $me         [description]
     * @param  [type]  $customerId [description]
     * @param  [type]  $amount     [description]
     * @param boolean $force [description]
     * @return [type]              [description]
     */
    public function deductBalance($me, $customerId, $amount, $force = false)
    {
        // Let's see if we can deduct the balance at all
        $c = $this->read($customerId);
        $current_balance = $c['balance'];
        // are we allowing negative values?
        if ($force) {
            return $this->addBalance($me, $customerId, (-1) * $amount);
        } else {
            if ($current_balance - $amount >= 0) {
                return $this->addBalance($me, $customerId, (-1) * $amount);
            } else {
                // we cant deduct , insufficient funds
                return false;
            }
        }
    }

    /*
     * Adds Seconds to DPM Balance
     * @param int $me - ID of the Account that has made the modification
     * @param int $customerId - Customer ID
     * @param int $seconds - Number of Seconds to add
     */
    public function addDpmBalance($me, $customerId, $seconds)
    {
        $customer = $this->read($customerId);
        if (!is_null($customer) and $seconds > 0) {
            // add to notes
            $note = 'Added/Subtracted ' . $seconds . 's from the current DPMS balance of ' . $customer['dpmsBalance'] . 's';
            $this->addNote($customer['customerId'], $note, 'regular', 0, $me);
        }

        $sql = 'UPDATE customers SET dpmsBalance = (dpmsBalance + :dpmsBalance), modifiedBy = :modifiedBy WHERE customerId = :customerId';
        $result = DB::query(Database::INSERT, $sql)
            ->bind(':dpmsBalance', $seconds)
            ->bind(':modifiedBy', $me)
            ->bind(':customerId', $customerId)
            ->execute(Database::instance());

        // re-fetch the customer data
        $re_customer = $this->read($customerId);
        if (!is_null($re_customer)) {
            if ($re_customer['dpmsBalance'] < 0) {
                $body = 'Hi CSR,<br/><br/>';
                $body .= 'Customer ' . $re_customer['firstName'] . ' ' . $re_customer['lastName'] . '(' . $re_customer['customerId'] . ') obtained a negative balance.<br/>';
                $body .= 'Customer\'s current balance is $' . $re_customer['balance'] . ' and ' . $re_customer['dpmsBalance'] . ' minutes.</br/>';
                $body .= 'Please check the customer\'s last transaction(Recharge, Booked Call / Appointment, Manage Payments).<br/><br/>';
                $body .= 'Kindly contact Dev Team if in need of assistance.';
                // email agents
                @helper_functions::emailAdmins('[Negative Balance] A customer obtained a negative balance.', $body);
            }
        }

        return true;
    }

    /*
     * Adds Seconds to DPM Balance
     * @param int $me - ID of the Account that has made the modification
     * @param int $customerId - Customer ID
     * @param int $minutes - Number of Minutes to Deduct
     */
    public function deductDpmBalance($me, $customerId, $minutes, $force = false)
    {
        // Let's see if we can deduct the balance at all
        $c = $this->read($customerId);
        $seconds = $minutes * 60;
        $current_balance = $c['dpmsBalance'];
        // Are we forcing negative balances
        if ($force) {
            return $this->addDpmBalance($me, $customerId, (-1) * $seconds);
        } else {
            if ($current_balance - $seconds >= 0) {
                return $this->addDpmBalance($me, $customerId, (-1) * $seconds);
            } else {
                // we cant deduct , insufficient funds
                return false;
            }
        }
    }

    /**
     * Adds a time balance to user's account.
     * @param int $me id of who modified the account, default 0, system
     * @param int $customerId customer Id
     * @param int $seconds time amount in seconds
     */
    public function addBalanceDPMS($me, $customerId, $seconds)
    {
        $customer = $this->read($customerId);
        // add note
        if (!is_null($customer) and $seconds > 0) {
            $note = 'Added/Subtracted ' . $seconds . 's from current DPMS balance of ' . $customer['dpmsBalance'] . 's';
            $this->addNote($customer['customerId'], $note, 'regular', 0, $me);
        }
        // do the updating
        $sql = 'UPDATE customers SET dpmsBalance = (dpmsBalance + :dpmsBalance), modifiedBy = :modifiedBy WHERE customerId = :customerId';
        $result = DB::query(Database::UPDATE, $sql)
            ->bind(':dpmsBalance', $seconds)
            ->bind(':modifiedBy', $me)
            ->bind(':customerId', $customerId)
            ->execute(Database::instance());

        // re-fetch the customer data
        $re_customer = $this->read($customerId);
        if (!is_null($re_customer)) {
            if ($re_customer['dpmsBalance'] < 0) {
                $body = 'Hi CSR,<br/><br/>';
                $body .= 'Customer ' . $re_customer['firstName'] . ' ' . $re_customer['lastName'] . '(' . $re_customer['customerId'] . ') obtained a negative balance.<br/>';
                $body .= 'Customer\'s current balance is $' . $re_customer['balance'] . ' and ' . $re_customer['dpmsBalance'] . ' minutes.</br/>';
                $body .= 'Please check the customer\'s last transaction(Recharge, Booked Call / Appointment, Manage Payments).<br/><br/>';
                $body .= 'Kindly contact Dev Team if in need of assistance.';
                // email agents
                @helper_functions::emailAdmins('[Negative Balance] A customer obtained a negative balance.', $body);
            }
        }
        return true;
    }

    /**
     * Deduct a time balance from a user's account
     * @param  [type] $me         [description]
     * @param  [type] $customerId [description]
     * @param  [type] $seconds    time to take out
     * @return [type]             [description]
     */
    public function deductBalanceDPMS($me, $customerId, $seconds)
    {
        // Let's see if we can deduct the balance at all
        $c = $this->read($customerId);
        $current_dpmsBalance = $c['dpmsBalance'];
        if ($current_dpmsBalance - $seconds >= 0) {
            return $this->addBalanceDPMS($me, $customerId, (-1) * $seconds);
        } else {
            // we cant deduct , insufficient funds
            return false;
        }
    }

    /**
     * Returns a sorted, verified array of payments, balance adjustments, refunds, dpmsbalance adjustments for the customer
     * @param  [type] $customerId [description]
     * @return [type]             [description]
     */
    public function allFinancialData($customerId)
    {
        $results = array();
        // init models
        $model_payments = new model_financials_payments();
        $model_promotionalcodes = new model_financials_promotionalcodes();
        $model_balanceadjustments = new model_financials_adjustments();
        $model_callbacks = new model_calls_callbacks();

        // Payments first
        $payments = $model_payments->allByCustomer($customerId);
        foreach ($payments as $p) {
            $p['hr_type'] = 'payment';
            // human readable content:
            $p['hr_success'] = $p['success'] == 1 ? 'Success' : 'Failure';
            // amount should always be negative for a payment
            $p['hr_amount'] = '+ $' . number_format($p['amount'], 2);
            // it's quite stupid, but we should look into recharges to see if this pertains to taht as well. the time vicinity is the key
            $sql = 'SELECT * FROM recharges WHERE customerId = :customerId AND amountBilled = :amountBilled AND createdAt = :createdAt';
            $recharge_match = DB::query(Database::SELECT, $sql)->bind(':customerId', $customerId)->bind(':amountBilled', $p['amount'])->bind(':createdAt', $p['createdAt'])->execute()->current();
            if (!is_null($recharge_match)) {
                $p['reason'] .= ' this is probably a recharge ';
            }
            $results[] = $p;
        }

        // Follow by promo codes redeemed
        $promos = $model_promotionalcodes->allByCustomer($customerId);
        foreach ($promos as $pr) {
            $pr['hr_type'] = 'promo';
            // human readable content
            $pr['hr_success'] = 'Success';
            if ($pr['amount'] > 0.00) {
                $pr['hr_amount'] = '+ $' . $pr['amount'];
            }
            if ($pr['minutes'] > 0.00) {
                $pr['hr_amount'] = '+ ' . $pr['minutes'] . ' min';
            }
            // If something mysterious happens...
            if ($pr['minutes'] == 0.00 and $pr['amount'] == 0.00) {
                $pr['hr_amount'] = NULL;
            }
            $results[] = $pr;
        }

        // Now let's go balance adjustments
        $balance_adjustments = $model_balanceadjustments->allBalanceByCustomer($customerId);
        foreach ($balance_adjustments as $ba) {
            $ba['hr_type'] = 'balance_adjust';
            // human readable content
            $ba['hr_success'] = 'Success';
            // amount is decided with it's own sign and the way we show it is totally stupid
            $ba['hr_amount'] = $ba['signed'] . ' $' . number_format($ba['amount'] - $ba['previousBalance'], 2);
            $results[] = $ba;
        }

        // At the end DPMS adjustments
        $dpms_adjustmnets = $model_balanceadjustments->allDpmsByCustomer($customerId);
        foreach ($dpms_adjustmnets as $da) {
            $da['hr_type'] = 'dpms_adjust';
            // human readable content
            $da['hr_success'] = 'Success';
            // amount is decided with it's own sign
            $da['hr_amount'] = $da['signed'] . ' ' . number_format($da['amount'], 2) . ' min';
            $results[] = $da;
        }

        // Now I want the calls
        $calls = $model_callbacks->allBy($customerId);
        foreach ($calls as $call) {
            // Skip the fails
            if ($call['lastStatus'] !== 'session_ended') {
                continue;
            }
            // Backup this record for further use as indicator
            $call_back = $call;
            // tagging
            $call['hr_type'] = 'call (' . $call['callbackId'] . ')';
            $call['hr_success'] = 'Billed';
            // was the callback billed?
            if ($call['paymentId'] == 0 and $call['refunded'] == 0) {
                $call['hr_success'] = 'Deducted on Balance';
            }
            // refunded
            if ($call['refunded'] == 1) {
                $call['hr_success'] = 'Refund to Account';
                $call['reason'] = $call['hr_success'];
            }
            $call['hr_amount'] = NULL;
            // if refunded, should always be a + sign for the amount
            if ($call['refunded'] == 1) {
                $call['hr_amount'] .= '+ $' . number_format($call['amountDebited'], 2);
                if ($call['dpmsDebited'] > 0.00) {
                    $call['hr_amount'] .= ' & ' . number_format(($call['dpmsDebited'] / 60), 2) . ' min';
                }
            } else {
                if ($call['amountDebited'] > 0.00) {
                    $call['hr_amount'] .= '- $' . number_format($call['amountDebited'], 2);
                    // more tags
                    if ($call['dpmsDebited'] > 0.00) {
                        $call['hr_amount'] .= ' & ';
                    }
                }
                if ($call['dpmsDebited'] > 0.00) {
                    $call['hr_amount'] .= '- ' . number_format(($call['dpmsDebited'] / 60), 2) . ' min';
                }
            }
            // Let's add the duration on top of the scheduled time, gives a more accurate datetime
            if ($call['appointmentId'] > 0) {
                $call['createdAt'] = $call['modifiedAt'];
            } else {
                $createdAt = date_create($call['createdAt']);
                date_add($createdAt, date_interval_create_from_date_string($call['duration'] . ' seconds'));
                $call['createdAt'] = date_format($createdAt, 'Y-m-d H:i:s');
            }
            // expose this
            $results[] = $call;
            // Let's work on the indicator
            $call_back['hr_type'] = 'call_start';
            $call_back['hr_success'] = 'call_start';
            $call_back['hr_amount'] = NULL;
            $results[] = $call_back;
        }


        // Sort them by date happening
        usort($results, function ($a, $b) {
            return strtotime($b['createdAt']) - strtotime($a['createdAt']);
        });
        return $results;
    }


    #########################
    #### Everything Else  ###
    #########################

    /*
     * Updates the Customer's info from the AJAX request. Serves the Email, Password and Phone Number fields
     * @param int $customerId   customer ID
     * @param string $field     field of the post
     * @param string $value     value
     */
    public function updateInfo($customerId, $field, $value)
    {
        $value = $field == 'password' ? sha1($value) : $value;

        $sql = 'UPDATE customers SET :field = :value WHERE customerId = :customerId';
        DB::query(Database::UPDATE, $sql)->bind(':field', $field)->bind(':value', $value)->bind(':customerId', $customerId)->execute(Database::instance());
    }

    /*
     * Updates the Customer's birthdate from the AJAX request.
     * @param int $customerId   customer ID
     * @param string $birthdate     birthday value
     */
    public function updateBirthdate($customerId, $birthdate)
    {
        $sql = 'UPDATE customers SET birthdate = :birthdate WHERE customerId = :customerId';
        DB::query(Database::UPDATE, $sql)->bind(':birthdate', $birthdate)->bind(':customerId', $customerId)->execute(Database::instance());
    }

    public function logPurchase($landing_url, $referrer, $response_code, $selected_package, $psychicId, $appointmentId, $firstName, $lastName, $cellphone, $email, $customerId = NULL, $paymentMethodId = NULL, $paymentId = NULL, $callbackId = NULL)
    {
        // i need the ip
        $ipaddress = Helper_Functions::getIP();
        $appointmentId = null;
        // prep the query
        $sql = 'INSERT INTO purchaseLogs (landing_url, referrer, ipaddress, response_code, selected_package, psychicId, firstName, lastName, cellphone, email, customerId, paymentMethodId, paymentId, callbackId, createdAt) ';
        $sql .= '                VALUES (:landing_url, :referrer, :ipaddress, :response_code, :selected_package, :psychicId, :firstName, :lastName, :cellphone, :email, :customerId, :paymentMethodId, :paymentId, :callbackId, NULL)';
        DB::query(Database::INSERT, $sql)
            ->bind(':landing_url', $landing_url)
            ->bind(':referrer', $referrer)
            ->bind(':ipaddress', $ipaddress)
            ->bind(':selected_package', $selected_package)
            ->bind(':response_code', $response_code)
            ->bind(':psychicId', $psychicId)
            ->bind(':appointmentId', $appointmentId)
            ->bind(':firstName', $firstName)
            ->bind(':lastName', $lastName)
            ->bind(':cellphone', $cellphone)
            ->bind(':email', $email)
            ->bind(':customerId', $customerId)
            ->bind(':paymentMethodId', $paymentMethodId)
            ->bind(':paymentId', $paymentId)
            ->bind(':callbackId', $callbackId)
            ->execute(Database::instance());
    }

    /*
     * Inserts new customer balance adjustment
     * @param int $customerId - Customer's ID
     * @param int $nimdaId - Nimda's ID
     * @param float $previousDPMSBalance - Customer's Previous DPMs Balance
     * @param string $signed - Operation used
     * @param float $newBalance - Customer's Adjusted Balance
     * @param text $reason - Reason for adjusting the balance
     */
    public function logAdjustBalance($customerId, $nimdaId, $previousBalance, $signed, $newBalance, $reason)
    {
        $customer = $this->read($customerId);
        $now = date('Y-m-d H:i:s');

        // Insert Balance Adjustment log
        $sql = 'INSERT INTO balanceAdjustments (customerId, nimdaId, previousBalance, signed, amount, reason, createdAt, createdBy) VALUES(:customerId, :nimdaId, :previousBalance, :signed, :amount, :reason, :createdAt, :createdBy)';
        DB::query(Database::INSERT, $sql)
            ->bind(':customerId', $customer['customerId'])
            ->bind(':nimdaId', $nimdaId)
            ->bind(':previousBalance', $previousBalance)
            ->bind(':signed', $signed)
            ->bind(':amount', $newBalance)
            ->bind(':reason', $reason)
            ->bind(':createdAt', $now)
            ->bind(':createdBy', $nimdaId)
            ->execute(Database::instance());
    }

    /*
     * Inserts new customer DPM balance adjustment
     * @param int $customerId - Customer's ID
     * @param int $nimdaId - Nimda's ID
     * @param float $previousDPMSBalance - Customer's Previous DPMs Balance
     * @param string $signed - Operation used
     * @param float $newBalance - Customer's Adjusted DPM Balance
     * @param text $reason - Reason for adjusting the balance
     */
    public function logAdjustDpmBalance($customerId, $nimdaId, $previousDPMSBalance, $signed, $newBalance, $reason)
    {
        $customer = $this->read($customerId);
        $now = date('Y-m-d H:i:s');

        // Insert Balance Adjustment log
        $sql = 'INSERT INTO dpmsBalanceAdjustments (customerId, nimdaId, previousDPMSBalance, signed, adjustedSeconds, reason, createdAt, createdBy) VALUES(:customerId, :nimdaId, :previousDPMSBalance, :signed, :adjustedSeconds, :reason, :createdAt, :createdBy)';
        DB::query(Database::INSERT, $sql)
            ->bind(':customerId', $customer['customerId'])
            ->bind(':nimdaId', $nimdaId)
            ->bind(':previousDPMSBalance', $previousDPMSBalance)
            ->bind(':signed', $signed)
            ->bind(':adjustedSeconds', $newBalance)
            ->bind(':reason', $reason)
            ->bind(':createdAt', $now)
            ->bind(':createdBy', $nimdaId)
            ->execute(Database::instance());
    }

    /*
     * Returns the list of all Adjustment balance
     * @param int $limit - Limit of records to show
     */
    public function balanceAdjustments($limit = 0)
    {
        $sql = 'SELECT cu.firstName AS cusFirstName, cu.lastName AS cusLastName, n.firstName AS nimdaFirstName, n.lastName AS nimdaLastName, ba.balanceAdjustmentId, ba.previousBalance, ba.signed, ba.amount, ba.reason, ba.createdAt FROM balanceAdjustments ba';
        $sql .= ' INNER JOIN customers cu ON cu.customerId = ba.customerId';
        // $sql .= ' INNER JOIN csrs c ON c.csrId=ba.csrId';
        $sql .= ' INNER JOIN nimdas n ON n.nimdaId=ba.nimdaId';
        $sql .= ' ORDER BY ba.createdAt DESC';
        if ($limit > 0) {
            $sql .= ' LIMIT :limit';
        }
        return DB::query(Database::SELECT, $sql)->bind(':limit', $limit)->execute(Database::instance())->as_array();
    }

    /*
     * Returns the list of all DPMS Adjustment balance
     * @param int $limit - Limit of records to show
     */
    public function dpmsBalanceAdjustments($limit = 0)
    {
        $sql = 'SELECT cu.firstName AS cusFirstName, cu.lastName AS cusLastName, n.firstName AS nimdaFirstName, n.lastName AS nimdaLastName, dba.dpmsBalanceAdjustmentId, dba.previousDPMSBalance, dba.signed, dba.adjustedSeconds, dba.reason, dba.createdAt FROM dpmsBalanceAdjustments dba';
        $sql .= ' INNER JOIN customers cu ON cu.customerId = dba.customerId';
        // $sql .= ' INNER JOIN csrs c ON c.csrId=ba.csrId';
        $sql .= ' INNER JOIN nimdas n ON n.nimdaId=dba.nimdaId';
        $sql .= ' ORDER BY dba.createdAt DESC';
        if ($limit > 0) {
            $sql .= ' LIMIT :limit';
        }
        return DB::query(Database::SELECT, $sql)->bind(':limit', $limit)->execute(Database::instance())->as_array();
    }

    /*
     * Returns Customer's notes
     * @param int $customerId - Customer's ID
     * @param int $category - Category of the Note
     * @param bool $read - select read notes, unread notes, or all notes
     */
    public function notes($customerId, $category)
    {

        $sql = 'SELECT cn.*, n.firstName AS nimda FROM customerNotes cn INNER JOIN nimdas n ON n.nimdaId = cn.createdBy WHERE cn.customerId = :customerId ';
        switch ($category) {
            case 'important':
                $sql .= ' AND important = 1 ';
                break;
            case 'cca':
                $sql .= ' AND category = :category ';
                break;
        }
        $sql .= 'ORDER BY cn.createdAt DESC';

        return DB::query(Database::SELECT, $sql)
            ->bind(':customerId', $customerId)
            ->bind(':category', $category)
            ->execute(Database::instance())
            ->as_array();
    }

    /*
     * Inserts a customer note
     * @param int $customerId - Customer's ID
     * @param text $note - Note
     * @param string $category - Category of the Note
     * @param int $important - Important tag
     * @param int $createdBy - Nimda ID
     */
    public function addNote($customerId, $note, $category, $important, $createdBy)
    {
        $createdAt = date('Y-m-d H:i:s');
        $sql = 'INSERT INTO customerNotes (customerId, note, category, important, createdBy, createdAt) VALUES (:customerId, :note, :category, :important, :createdBy, :createdAt)';
        DB::query(Database::INSERT, $sql)
            ->bind(':customerId', $customerId)
            ->bind(':note', $note)
            ->bind(':category', $category)
            ->bind(':important', $important)
            ->bind(':createdBy', $createdBy)
            ->bind(':createdAt', $createdAt)
            ->execute(Database::instance());
    }

    /*
     * Marks the Note if important or not
     * @param int $noteId - Customer Note ID
     * @param int $important - Marks the important column of a note
     * @param int $me - Nimda ID
     */
    public function markNote($noteId, $important, $me)
    {
        $sql = 'UPDATE customerNotes SET important = :important, modifiedBy = :modifiedBy WHERE customerNoteId = :noteId';
        DB::query(Database::UPDATE, $sql)->bind(':important', $important)->bind(':noteId', $noteId)->bind(':modifiedBy', $modifiedBy)->execute(Database::instance());
    }

    public function logPreCustomer($firstName, $lastName, $cellphone, $birthdate, $email, $landingPage, $packageMinutes, $psychicId)
    {
        // table definition:
        /*
         CREATE TABLE `preCustomers` (
          `preCustomerId` int(10) unsigned NOT NULL AUTO_INCREMENT,
          `firstName` varchar(50) DEFAULT NULL,
          `lastName` varchar(50) DEFAULT NULL,
          `cellphone` varchar(45) DEFAULT NULL,
          `birthdate` date DEFAULT NULL,
          `email` varchar(128) NOT NULL,
          `landingPage` varchar(128) NOT NULL,
          `packageMinutes` decimal(4,2) DEFAULT NULL,
          `psychicId` int(10) DEFAULT NULL,
          `createdAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
          `createdBy` int(10) NOT NULL,
          `registered` tinyint(1) DEFAULT '0',
          PRIMARY KEY (`preCustomerId`)
        )
         */
        $sql = 'INSERT INTO preCustomers (firstName, lastName, cellphone, birthdate, email, landingPage, packageMinutes, psychicId, createdAt, createdBy) ';
        $sql .= '               VALUES (:firstName, :lastName, :cellphone, :birthdate, :email, :landingPage, :packageMinutes, :psychicId, NULL, -1)';
        DB::query(Database::INSERT, $sql)
            ->bind(':firstName', $firstName)
            ->bind(':lastName', $lastName)
            ->bind(':cellphone', $cellphone)
            ->bind(':birthdate', $birthdate)
            ->bind(':email', $email)
            ->bind(':landingPage', $landingPage)
            ->bind(':packageMinutes', $packageMinutes)
            ->bind(':psychicId', $psychicId)
            ->execute(Database::instance());
    }

    public function negativeBalance()
    {
        $sql = 'SELECT * FROM customers WHERE (balance < 0 OR dpmsBalance < 0)';
        return DB::query(Database::SELECT, $sql)
            ->execute(Database::instance());
    }

    /*
    Checks for matches according to key indexes of the given array parameter
    @param array $fields - Fields with values that will check for duplicate values on the customers table
    @param int $customerId - The customer ID not to include on the validation
    @param bool $forNimda - If the validation is from Nimda
    */
    public function duplicateMatches($fields, $customerId = 0, $fromNimda = false)
    {
        $sql = 'SELECT * FROM customers WHERE';
        $count = 1;
        $sql .= ' (firstName = :firstName OR lastName = :lastName)';
        $sql .= ' AND birthdate = :birthdate';
        if ($customerId != 0) {
            $sql .= ' AND customerId != :customerId';
        }
        $records = DB::query(Database::SELECT, $sql)
            ->bind(':firstName', $fields['firstName'])
            ->bind(':lastName', $fields['lastName'])
            ->bind(':birthdate', $fields['birthdate'])
            ->bind(':customerId', $customerId)
            ->execute(Database::instance())->as_array();

        if (count($records) > 0) {
            $_sess = Session::instance();
            // prepare the body
            if ($fromNimda) {
                $body = 'Hello,<br/><br/>';
                $body .= 'A customer has been created on Nimda that has similar Name and/or Birth date.<br/><br/>';
                $body .= '<b>Registered Customer</b>: ' . $fields['firstName'] . ' ' . $fields['lastName'] . '(' . $customerId . '), Birth date: ' . date('M d, Y', strtotime($fields['birthdate'])) . '<br/>';
                $body .= '<b>Registered By</b>: ' . $_sess->get('firstName') . '(' . $_sess->get('nimdaId') . ')<br/><br/>';
                // email title
                $emailTitle = '[Similar Account] A Customer has been created that has similar values with other customers';
            } else {
                $body = 'Hello CSR,<br/><br/>';
                $body .= 'A customer registered that has similar Name and/or Birth date.<br/><br/>';
                $body .= '<b>Registered</b>: ' . $fields['firstName'] . ' ' . $fields['lastName'] . '(' . $customerId . '), Birth date: ' . date('M d, Y', strtotime($fields['birthdate'])) . '<br/><br/>';
                // email title
                $emailTitle = '[Similar Account] A Customer just registered that has similar values with other customers';
            }
            $body .= '<b>Found matched accounts:</b><br/>';
            foreach ($records as $r) {
                $body .= $r['firstName'] . ' ' . $r['lastName'] . '(' . $r['customerId'] . '), Birth date: ' . date('M d, Y', strtotime($r['birthdate'])) . '<br/>';
            }
            $body .= '<br/><br/>Kindly check.<br/><br/>Thank you!';
            // email the CS
            helper_functions::emailAdmins($emailTitle, $body);
        }
    }

    /*
    Checks all customer with similar address
    @param string $address - Address of a customer
    */
    public function getByAddress($address = NULL)
    {
        if (is_null($address)) {
            return false;
        }
        $sql = 'SELECT customerId FROM customers WHERE address = :address';
        $record = DB::query(Database::SELECT, $sql)->bind(':address', $address)->execute(Database::instance())->as_array();
        // validate
        if (count($record) > 0) {
            return true;
        }
        return false;
    }

    /*
    Unsubscribes a Customer from the newsletter.
    @param string $email - Email of the customer
    */
    public function unsubscribeToNewsletter($data)
    {
        $customer = $this->getCustomerByEmail($data['email']);
        // validate
        if (!is_null($customer)) {
            // update
            $sql = 'UPDATE customers SET receivePromotions = 0 WHERE customerId = :customerId';
            DB::query(Database::UPDATE, $sql)->bind(':customerId', $customer['customerId'])->execute(Database::instance());
            // delete from newsletter subscribers table
            $sql = 'DELETE FROM newsletterSubscribers WHERE customerEmail = :customerEmail';
            DB::query(Database::DELETE, $sql)->bind(':customerEmail', $customer['email'])->execute(Database::instance());
            // log this
            $str = '[' . date('M d, Y - h:ia') . '] - Unsubscribed' . PHP_EOL;
            $str .= var_export($data, true) . PHP_EOL;
            file_put_contents(APPPATH . 'logs/mailchimp.log', $str, FILE_APPEND);
        }
    }

    /*
     * Updates CC Authorization field of a customer
     * @param int $customerId - Customer's ID
     * @param int $ccaOnFile - CC Authorization value
     */
    public function updateCcaOnFile($customerId = NULL, $ccaOnFile = 0)
    {
        if (is_null($customerId)) {
            return false;
        }
        // update customer record
        $sql = 'UPDATE customers SET ccaOnFile = :ccaOnFile WHERE customerId = :customerId';
        DB::query(Database::UPDATE, $sql)->bind(':ccaOnFile', $ccaOnFile)->bind(':customerId', $customerId)->execute(Database::instance());
    }

    /*
     * Updates Valid ID field of a customer
     * @param int $customerId - Customer's ID
     * @param int $validIdOnFile - Valid ID on File value
     */
    public function updateValidIdOnFile($customerId = NULL, $validIdOnFile = 0)
    {
        if (is_null($customerId)) {
            return false;
        }
        // update customer record
        $sql = 'UPDATE customers SET validIdOnFile = :validIdOnFile WHERE customerId = :customerId';
        DB::query(Database::UPDATE, $sql)->bind(':validIdOnFile', $validIdOnFile)->bind(':customerId', $customerId)->execute(Database::instance());
    }
    /*
     * Updates Valid ID field of a customer
     * @param int $customerId - Customer's ID
     * @param int $validIdOnFile - change to next plan
     */
    public function updateTakeTierNextPlan($customerId = NULL, $takeTierNextPlan = 0)
    {
        if (is_null($customerId)) {
            return false;
        }
        // update customer record
        $sql = 'UPDATE customers SET takeTierNextPlan = :takeTierNextPlan WHERE customerId = :customerId';
        DB::query(Database::UPDATE, $sql)->bind(':takeTierNextPlan', $takeTierNextPlan)->bind(':customerId', $customerId)->execute(Database::instance());
    }
    /*
     * Returns list from pre Customers table according to campaign
     * @param int $offset - record index to start showing
     * @param int $limit - number of records to show
     * @param bool $registered - get all the registered/non-registered/both
     * preCustomer records
     * @return array - List of customers
     */
    public function allPreCustomers($registered = null, $limit = 0, $offset = 0)
    {

        $sql = 'SELECT preCustomerId, firstName, lastName, birthdate, 
            cellphone, email, createdAt FROM preCustomers WHERE 1=1 ';

        if (!is_null($registered)) {
            if ($registered) {
                $sql .= ' AND registered = 1';
            } else {
                $sql .= ' AND registered = 0';
            }
        }

        if ($limit > 0) {
            $sql .= ' LIMIT ' . $offset . ', ' . $limit;
        }

        return DB::query(Database::SELECT, $sql)
            ->execute(Database::instance())
            ->as_array();
    }

    /*
     * Returns list from Campaign Customers table according to campaign
     * @param string $campaign - Which campaign list to show
     * @param int $offset - record index to start showing
     * @param int $limit - number of records to show
     * @return array - List of customers
     */
    public function allCampaignCustomers($campaign = NULL, $offset = 0, $limit = 0)
    {
        $sql = 'SELECT * FROM campaignCustomers';
        if (!is_null($campaign)) {
            $sql .= ' WHERE type = :campaign';
        }
        if ($limit > 0) {
            $sql .= ' LIMIT ' . $offset . ', ' . $limit;
        }
        return DB::query(Database::SELECT, $sql)->bind(':campaign', $campaign)->bind(':offset', $offset)->bind(':limit', $limit)->execute(Database::instance())->as_array();
    }

    /*
     * This is for the Campaign Customer checker
     * @param string $campaign - The Campaign the customer has signed up
     * @param string $email - The customer's email
     * @return [type] [description]
     */
    public function verifyCampaignCustomer($campaign, $email)
    {
        $sql = 'SELECT * FROM campaignCustomers WHERE type = :campaign AND email = :email';
        $result = DB::query(Database::SELECT, $sql)->bind(':campaign', $campaign)->bind(':email', $email)->execute(Database::instance())->as_array();
        if (count($result) > 0) {
            return true;
        }
        return false;
    }

    /*
     * This is for the Campaign Customer adder
     * @return [type] [description]
     */
    public function createCampaignCustomer($firstName, $email, $birthDay, $campaign)
    {
        $now = date('Y-m-d H:i:s');
        $sql = 'INSERT INTO campaignCustomers (firstName, email, birthdate, type, createdAt)';
        $sql .= ' VALUES(:firstName, :email, :birthdate, :type, :createdAt)';
        $result = DB::query(Database::INSERT, $sql)
            ->bind(':firstName', $firstName)
            ->bind(':email', $email)
            ->bind(':birthdate', $birthDay)
            ->bind(':type', $campaign)
            ->bind(':createdAt', $now)
            ->execute(Database::instance());
        // return campaignCustomerId
        return $result[0];
    }

    public function newsletterSubscription($emails = NULL, $status)
    {
        if (!is_null($emails)) {
            // tag receive promotions
            $unsubscribeCustomers = 'UPDATE customers SET receivePromotions = :status WHERE email IN (' . $emails . ')';
            DB::query(Database::UPDATE, $unsubscribeCustomers)
                ->bind(':status', $status)
                ->execute(Database::instance());

            // delete from newsletter subscriptions
            $unsubscribeNewsletters = 'UPDATE newsletterSubscribers SET status = :status WHERE customerEmail IN (' . $emails . ')';
            DB::query(Database::UPDATE, $unsubscribeNewsletters)
                ->bind(':status', $status)
                ->execute(Database::instance());

            // delete from horoscope subscription
            $unsubscribeHoroscopes = 'UPDATE horoscopeSubscribers SET status = :status WHERE customerEmail IN (' . $emails . ')';
            DB::query(Database::UPDATE, $unsubscribeHoroscopes)
                ->bind(':status', $status)
                ->execute(Database::instance());
        }
    }

    public function incomingsBalanceAdjustments($customerId, $start, $end, $nimdaId, $sign = '+')
    {
        $sql = 'SELECT SUM(amount) AS amount FROM balanceAdjustments WHERE customerId = :customerId AND createdAt BETWEEN :start AND :end AND nimdaId = :nimdaId AND signed = :sign';
        return DB::query(Database::SELECT, $sql)
            ->bind(':customerId', $customerId)
            ->bind(':start', $start)
            ->bind(':end', $end)
            ->bind(':nimdaId', $nimdaId)
            ->bind(':sign', $sign)
            ->execute(Database::instance())->current();
    }

    public function incomingsDpmsBalanceAdjustments($customerId, $start, $end, $nimdaId, $sign = '+')
    {
        $sql = 'SELECT SUM(adjustedSeconds) AS seconds FROM dpmsBalanceAdjustments WHERE customerId = :customerId AND createdAt BETWEEN :start AND :end AND nimdaId = :nimdaId AND signed = :sign';
        return DB::query(Database::SELECT, $sql)
            ->bind(':customerId', $customerId)
            ->bind(':start', $start)
            ->bind(':end', $end)
            ->bind(':nimdaId', $nimdaId)
            ->bind(':sign', $sign)
            ->execute(Database::instance())->current();
    }
}

